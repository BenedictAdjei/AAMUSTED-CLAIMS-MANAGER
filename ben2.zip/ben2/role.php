<!DOCTYPE html>

<html lang="en">
    
<head>
        <?php include 'controller/php_inc/setup_inc_code.php' ?>
        <?php include 'inc/meta_inc.php' ?>
        <!-- base css -->
        <?php include 'inc/styles_inc.php' ?>
</head>
    <body class="mod-bg-1 ">
        <!-- DOC: script to save and load page settings -->
        <script>
    
            /**
             *	This script should be placed right after the body tag for fast execution 
            *	Note: the script is written in pure javascript and does not depend on thirdparty library
            **/
            'use strict';

            var classHolder = document.getElementsByTagName("BODY")[0],
                /** 
                 * Load from localstorage
                 **/
                themeSettings = (localStorage.getItem('themeSettings')) ? JSON.parse(localStorage.getItem('themeSettings')) :
                {},
                themeURL = themeSettings.themeURL || '',
                themeOptions = themeSettings.themeOptions || '';
            /** 
             * Load theme options
             **/
            if (themeSettings.themeOptions)
            {
                classHolder.className = themeSettings.themeOptions;
                console.log("%c✔ Theme settings loaded", "color: #148f32");
            }
            else
            {
                console.log("Heads up! Theme settings is empty or does not exist, loading default settings...");
            }
            if (themeSettings.themeURL && !document.getElementById('mytheme'))
            {
                var cssfile = document.createElement('link');
                cssfile.id = 'mytheme';
                cssfile.rel = 'stylesheet';
                cssfile.href = themeURL;
                document.getElementsByTagName('head')[0].appendChild(cssfile);
            }
            /** 
             * Save to localstorage 
             **/
            var saveSettings = function()
            {
                themeSettings.themeOptions = String(classHolder.className).split(/[^\w-]+/).filter(function(item)
                {
                    return /^(nav|header|mod|display)-/i.test(item);
                }).join(' ');
                if (document.getElementById('mytheme'))
                {
                    themeSettings.themeURL = document.getElementById('mytheme').getAttribute("href");
                };
                localStorage.setItem('themeSettings', JSON.stringify(themeSettings));
            }
            /** 
             * Reset settings
             **/
            var resetSettings = function()
            {
                localStorage.setItem("themeSettings", "");
            }

        </script>
        <!-- BEGIN Page Wrapper -->
        <div class="page-wrapper">
            <div class="page-inner">
                <!-- BEGIN Left Aside -->
                <?php include 'inc/aside_inc.php' ?>
                <!-- END Left Aside -->
                <div class="page-content-wrapper">
                    <!-- BEGIN Page Header -->
                    <?php include 'inc/header_inc.php' ?>    
                    <!-- END Page Header -->
                    <!-- BEGIN Page Content -->
                    <!-- the #js-page-content id is needed for some plugins to initialize -->
                    <main id="js-page-content" role="main" class="page-content">
                        <ol class="breadcrumb page-breadcrumb"> 
                            <li class="breadcrumb-item"><a href="javascript:void(0);">FlairTech Admin</a></li>
                            <li class="breadcrumb-item">Roles</li>
                            <li class="position-absolute pos-top pos-right d-none d-sm-block"><span class="js-get-date"></span></li>
                        </ol>
                        <div class="subheader">
                            <h1 class="subheader-title">
                                <i class='subheader-icon fal fa-table'></i> Roles <span class='fw-300'></span> 
                                
                            </h1>
                        </div>
                        
                        <div class="row">
                            <div class="col-xl-12">
                                <div id="panel-1" class="panel">
                                    <div class="panel-hdr">
                                        <h2>
                                        Manage Roles
                                        </h2>
                                        
                                    </div>
                                    <div class="panel-container show">
                                        <div class="panel-content">
                                            
                                        <div class="row">
                                                <div class="col-xl-12">
                                                    <!-- datatable start -->
                                                    <table id="dt-basic-example" class="table table-bordered table-hover table-striped w-100"></table>
                                                    <!-- datatable end -->
                                                </div>
                                            
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </main>
                    <!-- this overlay is activated only when mobile menu is triggered -->
                    <div class="page-content-overlay" data-action="toggle" data-class="mobile-nav-on"></div> <!-- END Page Content -->
                    <!-- BEGIN Page Footer -->
                <?php include 'inc/footer_inc.php' ?>
                    
        <!-- END Page Settings -->
        
        <!-- base vendor bundle: 
            DOC: if you remove pace.js from core please note on Internet Explorer some CSS animations may execute before a page is fully loaded, resulting 'jump' animations 
                        + pace.js (recommended)
                        + jquery.js (core)
                        + jquery-ui-cust.js (core)
                        + popper.js (core)
                        + bootstrap.js (core)
                        + slimscroll.js (extension)
                        + app.navigation.js (core)
                        + ba-throttle-debounce.js (core)
                        + waves.js (extension)
                        + AmgTech panels.js (extension)
                        + src/../jquery-snippets.js (core) -->
        <script src="js/vendors.bundle.js"></script>
        <script src="js/app.bundle.js"></script>
        <!-- datatble responsive bundle contains: 
    + jquery.dataTables.js
    + dataTables.bootstrap4.js
    + dataTables.autofill.js							
    + dataTables.buttons.js
    + buttons.bootstrap4.js
    + buttons.html5.js
    + buttons.print.js
    + buttons.colVis.js
    + dataTables.colreorder.js							
    + dataTables.fixedcolumns.js							
    + dataTables.fixedheader.js						
    + dataTables.keytable.js						
    + dataTables.responsive.js							
    + dataTables.rowgroup.js							
    + dataTables.rowreorder.js							
    + dataTables.scroller.js							
    + dataTables.select.js							
    + datatables.styles.app.js
    + datatables.styles.buttons.app.js -->
        <script src="js/datagrid/datatables/datatables2.bundle.js"></script>
        <script src="js/notifications/sweetalert2/sweetalert2.bundle.js"></script>
        <script>
            $(document).ready(function()
            {
                
                /* 
                NOTES:
                    
                    Column id
                    ---------------------------------------------------
                    Please always keep in mind that DataTable framework allows two different kinds of "rows": Arrays and Objects. In first case columns are indexed through integers; in second case columns are indexed by their attribute name. Usually JSON's use the Object approach, but we cannot be sure.


                    Row key
                    ---------------------------------------------------
                    There is no default key in the table. Inside your callback functions, probably you will need a row key to build URL's, in that case you can get them from the rowdata parameter.


                COLUMN DEFINITIONS:

                    title = "string" - title name on table header th and on form labels
                    ---------------------------------------------------
                    id = "string" - id assigned to imput element when editing/adding in modal
                    ---------------------------------------------------
                    data = "string"  - data name from the dataset
                    ---------------------------------------------------
                    type = "text" | "select" | "hidden" | "readonly"  - Type of HTML input to be shown.
                    ---------------------------------------------------
                    hoverMsg = "some msg" - The message will appear as a tooltip over the input field.
                    ---------------------------------------------------
                    pattern = r.e.  - If type is "input", the typed text will be matched against given regular expression, before submit.
                    ---------------------------------------------------
                    msg = "some string" - An error message that is displayed in case pattern is not matched. Set HTML "data-errorMsg" attribute.
                    ---------------------------------------------------
                    maxLength = integer - If type is "input", set HTML "maxlength" attribute.
                    ---------------------------------------------------
                    options = ["a", "b", "c"] - If type is "select", the options that shall be presented.
                    ---------------------------------------------------
                    select2 = {} - If type is "select", enable a select2 component. Select2 jQuery plugin must be linked. More select2 configuration options may be passed within the array.
                    ---------------------------------------------------
                    datepicker = {} - If type is "text", enable a datepicker component. jQuery-UI plugin must be linked. More datepicker configuration options may be passed within the array.
                    ---------------------------------------------------
                    multiple = true | false - Set HTML "multiple" attribute (for use with select2).
                    ---------------------------------------------------
                    unique = true | false - Ensure that no two rows have the same value. The check is performed client side, not server side. Set HTML "data-unique" attribute. (Probably there's some issue with this).
                    ---------------------------------------------------
                    uniqueMsg = "some string" - An error message that is displayed when the unique constraint is not respected. Set HTML "data-uniqueMsg" attribute.
                    ---------------------------------------------------
                    special = "any string" - Set HTML "data-special" attribute (don't know what's that needed for).
                    ---------------------------------------------------
                    defaultValue = "any string" - Adds a default value when adding a row
                    ---------------------------------------------------
                */


                // Event Lot
                var events = $("#app-eventlog");
                var roles = [<?php echo $all_roles ?>];
                // Column Definitions
                var columnSet = [
                {
                    title: "RowId",
                    id: "role_id",
                    data: "role_id",
                    placeholderMsg: "Server Generated ID",
                    "visible": false,
                    "searchable": false,
                    type: "hidden"
                },
                {
                    title: "Role",
                    id: "role_name",
                    data: "role_name",
                    placeholderMsg: "Role",
                    type: "text",
                    unique: true,
                    uniqueMsg: "User already in exist"
                }
                
            ]

                //Get domain
                var BaseUrl = window.location.origin;
                /* start data table */
                var myTable = $('#dt-basic-example').dataTable(
                {
                    /* check datatable buttons page for more info on how this DOM structure works */
                    dom: "<'row mb-3'<'col-sm-12 col-md-6 d-flex align-items-center justify-content-start'f><'col-sm-12 col-md-6 d-flex align-items-center justify-content-end'B>>" +
                        "<'row'<'col-sm-12'tr>>" +
                        "<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
                    ajax: "controller/user_code.php?r=",
                    columns: columnSet,
                    /* selecting multiple rows will not work */
                    select: 'single',
                    /* altEditor at work */
                    altEditor: true,
                    responsive: true,
                    /* buttons uses classes from bootstrap, see buttons page for more details */
                    buttons: [
                    {
                        extend: 'selected',
                        text: '<i class="fal fa-times mr-1"></i> Delete',
                        name: 'delete',
                        className: 'btn-primary btn-sm mr-1'
                    },
                    {
                        extend: 'selected',
                        text: '<i class="fal fa-edit mr-1"></i> Edit',
                        name: 'edit',
                        className: 'btn-primary btn-sm mr-1'
                    },
                    {
                        text: '<i class="fal fa-plus mr-1"></i> Add',
                        name: 'add',
                        className: 'btn-success btn-sm mr-1'
                    },
                    {
                        text: '<i class="fal fa-sync mr-1"></i> Refresh',
                        name: 'refresh',
                        className: 'btn-primary btn-sm'
                    }],
                    columnDefs: [
                    {
                        
                    }
                    ],
                    /* default callback for insertion: mock webservice, always success */
                    onAddRow: function(dt, rowdata, success, error)
                    {
                        var myFormData = new FormData();
                        myFormData.append('role_name',rowdata.role_name);
                        myFormData.append('add_role','');
                        rowdata['role_id'] = '';
                        success(rowdata);
                        
                        $.ajax({
                            url: 'controller/user_code.php',
                            type: 'POST',
                            processData: false, // important
                            contentType: false, // important
                            dataType : 'json',
                            data: myFormData,
                            beforeSend:function(res){
                            },
                            complete:function(res){
                            },
                            success:function(res){
                                Swal.fire(
                                {
                                    type: "success",
                                    title: "Add Successful",
                                    showConfirmButton: false,
                                    timer: 2500
                                });
                            },
                            error:function(res){
                            console.log(res);
                            }
                        });
                        

                        // demo only below:
                        events.prepend('<p class="text-success fw-500">' + JSON.stringify(rowdata, null, 4) + '</p>');
                    },
                    onEditRow: function(dt, rowdata, success, error)
                    {
                        success(rowdata);
                        var myFormData = new FormData();
                        myFormData.append('role_id',rowdata.role_id);
                        myFormData.append('role_name',rowdata.role_name);
                        myFormData.append('edit_role','');
                        success(rowdata);
                        console.log(myFormData);
                        $.ajax({
                            url: 'controller/user_code.php',
                            type: 'POST',
                            processData: false, // important
                            contentType: false, // important
                            dataType : 'json',
                            data: myFormData,
                            beforeSend:function(res){
                                // console.log(e);
                            },
                            complete:function(res){
                            },
                            success:function(res){
                                Swal.fire(
                                    {
                                        type: "success",
                                        title: "Edit Successful",
                                        showConfirmButton: false,
                                        timer: 2500
                                    });
                            },
                            error:function(res){
                            console.log(res);
                            }
                        });

                        // demo only below:
                        events.prepend('<p class="text-info fw-500">' + JSON.stringify(rowdata, null, 4) + '</p>');
                    },
                    onDeleteRow: function(dt, rowdata, success, error)
                    {
                        Swal.fire(
                        {
                            type: "success",
                            title: "Delete Successful",
                            showConfirmButton: false,
                            timer: 2500
                        });
                        success(rowdata);
                        console.log(rowdata);
                        var role_id = rowdata.role_id;
                        $.post('controller/user_code.php?del_role='+role_id,function(del_res){
                                    Swal.fire(
                                    {
                                        type: "success",
                                        title: "Delete Successful",
                                        showConfirmButton: false,
                                        timer: 2500
                                    });
                        });
                    

                        // demo only below:
                        events.prepend('<p class="text-danger fw-500">' + JSON.stringify(rowdata, null, 4) + '</p>');
                    },
                });

            });

        </script>
    </body>

</html>
