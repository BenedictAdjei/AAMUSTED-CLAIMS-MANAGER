<!DOCTYPE html>

<html lang="en">
    
<head>
        <?php include 'controller/php_inc/setup_inc_code.php' ?>
        <?php include 'inc/meta_inc.php' ?>
        <!-- base css -->
        <?php include 'inc/styles_inc.php' ?>
        
</head>
    <body class="mod-bg-3 ">
        <!-- DOC: script to save and load page settings -->
        <script>
    
            /**
             *	This script should be placed right after the body tag for fast execution 
            *	Note: the script is written in pure javascript and does not depend on thirdparty library
            **/
            'use strict';

            var classHolder = document.getElementsByTagName("BODY")[0],
                /** 
                 * Load from localstorage
                 **/
                themeSettings = (localStorage.getItem('themeSettings')) ? JSON.parse(localStorage.getItem('themeSettings')) :
                {},
                themeURL = themeSettings.themeURL || '',
                themeOptions = themeSettings.themeOptions || '';
            /** 
             * Load theme options
             **/
            if (themeSettings.themeOptions)
            {
                classHolder.className = themeSettings.themeOptions;
                console.log("%c✔ Theme settings loaded", "color: #148f32");
            }
            else
            {
                console.log("Heads up! Theme settings is empty or does not exist, loading default settings...");
            }
            if (themeSettings.themeURL && !document.getElementById('mytheme'))
            {
                var cssfile = document.createElement('link');
                cssfile.id = 'mytheme';
                cssfile.rel = 'stylesheet';
                cssfile.href = themeURL;
                document.getElementsByTagName('head')[0].appendChild(cssfile);
            }
            /** 
             * Save to localstorage 
             **/
            var saveSettings = function()
            {
                themeSettings.themeOptions = String(classHolder.className).split(/[^\w-]+/).filter(function(item)
                {
                    return /^(nav|header|mod|display)-/i.test(item);
                }).join(' ');
                if (document.getElementById('mytheme'))
                {
                    themeSettings.themeURL = document.getElementById('mytheme').getAttribute("href");
                };
                localStorage.setItem('themeSettings', JSON.stringify(themeSettings));
            }
            /** 
             * Reset settings
             **/
            var resetSettings = function()
            {
                localStorage.setItem("themeSettings", "");
            }

        </script>
        <!-- BEGIN Page Wrapper -->
        <div class="page-wrapper">
            <div class="page-inner">
                <!-- BEGIN Left Aside -->
                <?php include 'inc/aside_inc.php' ?>
                <!-- END Left Aside -->
                <div class="page-content-wrapper">
                    <!-- BEGIN Page Header -->
                    <?php include 'inc/header_inc.php' ?>    
                    <!-- END Page Header -->
                    <!-- BEGIN Page Content -->
                    <!-- the #js-page-content id is needed for some plugins to initialize -->
                    <main id="js-page-content" role="main" class="page-content">
                        <ol class="breadcrumb page-breadcrumb"> 
                            <li class="breadcrumb-item"><a href="javascript:void(0);">FlairTech Admin</a></li>
                            <li class="breadcrumb-item">Add Claim</li>
                            <li class="breadcrumb-item">Extra Teaching Load Claim</li>
                            <li class="position-absolute pos-top pos-right d-none d-sm-block"><span class="js-get-date"></span></li>
                        </ol>
                        <div class="subheader">
                            <h1 class="subheader-title">
                                <i class='subheader-icon fal fa-table'></i>Extra Teaching Load/Examination Setup <span class='fw-300'></span> 
                                
                            </h1>
                        </div>
                        
                        <div class="row">
                            <div class="col-xl-12">
                                <div id="panel-1" class="panel">
                                    <div class="panel-hdr">
                                        <h2>
                                        Manage Claim
                                        </h2>
                                       
                                    </div>
                                    <div class="panel-container show">
                                        <div class="panel-content">
                                            
                                        <div class="row">
                                                <div class="col-xl-12">
                                                    <!-- datatable start -->
                                                    <table id="dt-basic-example" class="table table-bordered table-hover table-striped w-100"></table>
                                                    <!-- datatable end -->
                                                </div>
                                            
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </main>
                    <!-- this overlay is activated only when mobile menu is triggered -->
                    <div class="page-content-overlay" data-action="toggle" data-class="mobile-nav-on"></div> <!-- END Page Content -->
                    <!-- BEGIN Page Footer -->
                <?php include 'inc/footer_inc.php' ?>
                    
        <!-- END Page Settings -->
        
        <!-- base vendor bundle: 
            DOC: if you remove pace.js from core please note on Internet Explorer some CSS animations may execute before a page is fully loaded, resulting 'jump' animations 
                        + pace.js (recommended)
                        + jquery.js (core)
                        + jquery-ui-cust.js (core)
                        + popper.js (core)
                        + bootstrap.js (core)
                        + slimscroll.js (extension)
                        + app.navigation.js (core)
                        + ba-throttle-debounce.js (core)
                        + waves.js (extension)
                        + FlairTech panels.js (extension)
                        + src/../jquery-snippets.js (core) -->
        <!-- <script src="js/jquery.min.js"></script> -->
        <script src="js/vendors.bundle.js"></script>
        <script src="js/app.bundle.js"></script>
        <!-- datatble responsive bundle contains: 
    + jquery.dataTables.js
    + dataTables.bootstrap4.js
    + dataTables.autofill.js							
    + dataTables.buttons.js
    + buttons.bootstrap4.js
    + buttons.html5.js
    + buttons.print.js
    + buttons.colVis.js
    + dataTables.colreorder.js							
    + dataTables.fixedcolumns.js							
    + dataTables.fixedheader.js						
    + dataTables.keytable.js						
    + dataTables.responsive.js							
    + dataTables.rowgroup.js							
    + dataTables.rowreorder.js							
    + dataTables.scroller.js							
    + dataTables.select.js							
    + datatables.styles.app.js
    + datatables.styles.buttons.app.js -->
    
    
        <script src="js/select2.bundle.js"></script>
        <script src="js/datagrid/datatables/datatables.bundle.js"></script>
        <script src="js/notifications/sweetalert2/sweetalert2.bundle.js"></script>
        
        <script>
            $(document).ready(function()
            {
                var user_id = '<?php echo $_SESSION['user_id'] ?>';
                /* 
                NOTES:
                  Column id
                    ---------------------------------------------------
                    Please always keep in mind that DataTable framework allows two different kinds of "rows": Arrays and Objects. In first case columns are indexed through integers; in second case columns are indexed by their attribute name. Usually JSON's use the Object approach, but we cannot be sure.


                    Row key
                    ---------------------------------------------------
                    There is no default key in the table. Inside your callback functions, probably you will need a row key to build URL's, in that case you can get them from the rowdata parameter.


                COLUMN DEFINITIONS:

                    title = "string" - title name on table header th and on form labels
                    ---------------------------------------------------
                    id = "string" - id assigned to imput element when editing/adding in modal
                    ---------------------------------------------------
                    data = "string"  - data name from the dataset
                    ---------------------------------------------------
                    type = "text" | "select" | "hidden" | "readonly"  - Type of HTML input to be shown.
                    ---------------------------------------------------
                    hoverMsg = "some msg" - The message will appear as a tooltip over the input field.
                    ---------------------------------------------------
                    pattern = r.e.  - If type is "input", the typed text will be matched against given regular expression, before submit.
                    ---------------------------------------------------
                    msg = "some string" - An error message that is displayed in case pattern is not matched. Set HTML "data-errorMsg" attribute.
                    ---------------------------------------------------
                    maxLength = integer - If type is "input", set HTML "maxlength" attribute.
                    ---------------------------------------------------
                    options = ["a", "b", "c"] - If type is "select", the options that shall be presented.
                    ---------------------------------------------------
                    select2 = {} - If type is "select", enable a select2 component. Select2 jQuery plugin must be linked. More select2 configuration options may be passed within the array.
                    ---------------------------------------------------
                    datepicker = {} - If type is "text", enable a datepicker component. jQuery-UI plugin must be linked. More datepicker configuration options may be passed within the array.
                    ---------------------------------------------------
                    multiple = true | false - Set HTML "multiple" attribute (for use with select2).
                    ---------------------------------------------------
                    unique = true | false - Ensure that no two rows have the same value. The check is performed client side, not server side. Set HTML "data-unique" attribute. (Probably there's some issue with this).
                    ---------------------------------------------------
                    uniqueMsg = "some string" - An error message that is displayed when the unique constraint is not respected. Set HTML "data-uniqueMsg" attribute.
                    ---------------------------------------------------
                    special = "any string" - Set HTML "data-special" attribute (don't know what's that needed for).
                    ---------------------------------------------------
                    defaultValue = "any string" - Adds a default value when adding a row
                    ---------------------------------------------------
                */


                // Event Lot
                
                
                var all_academic_years = [<?php echo $all_academic_years ?>];
                var all_degrees = [<?php echo $all_degrees ?>];
                var all_claim_types = [<?php echo $all_claim_types ?>];
                var events = $("#app-eventlog");
                // Column Definitions
                var columnSet = [
                {
                    title: "RowId",
                    id: "extra_tch_claim_id",
                    data: "extra_tch_claim_id",
                    placeholderMsg: "Server Generated ID",
                    "visible": false,
                    "searchable": false,
                    type: "hidden"
                },    
                {
                    title: "Academic Year",
                    id: "academic_year",
                    data: "academic_year",
                    placeholderMsg: "Academic Year",
                    type: "select",
                    "options":
                    all_academic_years
                },
                {
                    title: "Claim Type",
                    id: "claim_type",
                    data: "claim_type",
                    placeholderMsg: "claim type",
                    type: "select",
                    "options":
                    all_claim_types
                },
                {
                    title: "Degree Supervised",
                    id: "degree",
                    data: "degree",
                    placeholderMsg: "Degree Supervised",
                    type: "select",
                    "options":
                    all_degrees
                },
                {
                    title: "Student Index Number",
                    id: "stud_id",
                    data: "stud_id",
                    placeholderMsg: "Index Number of Student",
                    type: "text"
                    
                },
                {
                    title: "Project Title",
                    id: "project_title",
                    data: "project_title",
                    placeholderMsg: "Title of Thesis/Long Essay",
                    type: "textarea",
                    
                },
                {
                    title: "Status",
                    id: "status",
                    data: "status",
                    "visible": true,
                    
                    
                },
                
            ]

                //Get domain
                var BaseUrl = window.location.origin;
                /* start data table */
                var myTable = $('#dt-basic-example').dataTable(
                {
                    /* check datatable buttons page for more info on how this DOM structure works */
                    dom: "<'row mb-3'<'col-sm-12 col-md-6 d-flex align-items-center justify-content-start'f><'col-sm-12 col-md-6 d-flex align-items-center justify-content-end'B>>" +
                        "<'row'<'col-sm-12'tr>>" +
                        "<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
                    ajax: "controller/internal_claim_code.php?::=",
                    columns: columnSet,
                    /* selecting multiple rows will not work */
                    select: 'single',
                    /* altEditor at work */
                    altEditor: true,
                    responsive: true,
                    /* buttons uses classes from bootstrap, see buttons page for more details */
                    buttons: [
                    {
                        extend: 'selected',
                        text: '<i class="fal fa-times mr-1"></i> Delete',
                        name: 'delete',
                        className: 'btn-danger btn-sm mr-1'
                    },
                    {
                        extend: 'selected',
                        text: '<i class="fal fa-edit mr-1"></i> Edit',
                        name: 'edit',
                        className: 'btn-warning btn-sm mr-1'
                    },
                    {
                        text: '<i class="fal fa-plus mr-1"></i> Add',
                        name: 'add',
                        className: 'btn-success btn-sm mr-1'
                    },
                    {
                        text: '<i class="fal fa-sync mr-1"></i> Refresh',
                        name: 'refresh',
                        className: 'btn-primary btn-sm'
                    }],
                    columnDefs: [
                    {
                        // targets: 3,
                        // render: function(data, type, full, meta)
                        // {
                        //     return '<img src="../images/user/'+data+'" style="width:300px;height:auto" class="img img-responsive ">';
                            
                        // },
                    }
                    ],
                    /* default callback for insertion: mock webservice, always success */
                    onAddRow: function(dt, rowdata, success, error)
                    {
                        
                        var myFormData = new FormData();
                        myFormData.append('academic_yr',rowdata.academic_year);
                        myFormData.append('claim_type',rowdata.claim_type);
                        myFormData.append('degree',rowdata.degree);
                        myFormData.append('stud_id',rowdata.stud_id);
                        myFormData.append('project_title',rowdata.project_title);
                        myFormData.append('user_id',user_id);
                        myFormData.append('add_claim','');
                        rowdata['internal_claim_id'] = '';
                        success(rowdata);
                        
                        $.ajax({
                            url: 'controller/internal_claim_code.php',
                            type: 'POST',
                            processData: false, // important
                            contentType: false, // important
                            dataType : 'json',
                            data: myFormData,
                            beforeSend:function(res){
                            },
                            complete:function(res){
                            },
                            success:function(res){
                                Swal.fire(
                                {
                                    type: "success",
                                    title: "Add Successful",
                                    showConfirmButton: false,
                                    timer: 2500
                                });
                            },
                            error:function(res){
                            console.log(res);
                            }
                        });
                        

                        // demo only below:
                        events.prepend('<p class="text-success fw-500">' + JSON.stringify(rowdata, null, 4) + '</p>');
                    },
                    onEditRow: function(dt, rowdata, success, error)
                    {
                        success(rowdata);
                        var myFormData = new FormData();
                        myFormData.append('semester',rowdata.semester);
                        myFormData.append('course_title',rowdata.course_title);
                        myFormData.append('total_scripts_marked',rowdata.total_scripts_marked);
                        myFormData.append('degree',rowdata.degree);               
                        myFormData.append('user_id',rowdata.user_id);
                        myFormData.append('edit_claim','');
                        success(rowdata);
                        
                        $.ajax({
                            url: 'controller/excess_code.php',
                            type: 'POST',
                            processData: false, // important
                            contentType: false, // important
                            dataType : 'json',
                            data: myFormData,
                            beforeSend:function(res){
                                // console.log(e);
                            },
                            complete:function(res){
                            },
                            success:function(res){
                                Swal.fire(
                                    {
                                        type: "success",
                                        title: "Edit Successful",
                                        showConfirmButton: false,
                                        timer: 2500
                                    });
                            },
                            error:function(res){
                            console.log(res);
                            }
                        });

                        // demo only below:
                        events.prepend('<p class="text-info fw-500">' + JSON.stringify(rowdata, null, 4) + '</p>');
                    },
                    onDeleteRow: function(dt, rowdata, success, error)
                    {
                        Swal.fire(
                        {
                            type: "success",
                            title: "Delete Successful",
                            showConfirmButton: false,
                            timer: 2500
                        });
                        
                        
                        var ex_id = rowdata.ex_id;
                        $.post('controller/excess_code.php?del='+ex_id,function(del_res){
                                    var response = JSON.parse(del_res);
                                    console.log(response);
                                    if(response.message =="success"){
                                        Swal.fire(
                                    {
                                        type: "success",
                                        title: "Delete Successful",
                                        showConfirmButton: false,
                                        timer: 2500
                                    });
                                    success(rowdata);
                                    }else if(response.message =="fail"){
                                        Swal.fire(
                                    {
                                        type: "warning",
                                        title: "Delete Unsuccessful!",
                                        showConfirmButton: false,
                                        timer: 2500
                                    });
                                    }else{
                                        Swal.fire(
                                    {
                                        type: "warning",
                                        title: "Server Error",
                                        showConfirmButton: false,
                                        timer: 2500
                                    });
                                    }
                        });
                    

                        // demo only below:
                        events.prepend('<p class="text-danger fw-500">' + JSON.stringify(rowdata, null, 4) + '</p>');
                    },
                });
                

            });

        </script>
    </body>

</html>
