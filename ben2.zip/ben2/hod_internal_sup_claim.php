<!DOCTYPE html>

<html lang="en">
    
<head>
        <?php include 'controller/php_inc/setup_inc_code.php' ?>
        <?php include 'inc/meta_inc.php' ?>
        <!-- base css -->
        <?php include 'inc/styles_inc.php' ?>
        
</head>
    <body class="mod-bg-3 ">
        <!-- DOC: script to save and load page settings -->
        <script>
    
            /**
             *	This script should be placed right after the body tag for fast execution 
            *	Note: the script is written in pure javascript and does not depend on thirdparty library
            **/
            'use strict';

            var classHolder = document.getElementsByTagName("BODY")[0],
                /** 
                 * Load from localstorage
                 **/
                themeSettings = (localStorage.getItem('themeSettings')) ? JSON.parse(localStorage.getItem('themeSettings')) :
                {},
                themeURL = themeSettings.themeURL || '',
                themeOptions = themeSettings.themeOptions || '';
            /** 
             * Load theme options
             **/
            if (themeSettings.themeOptions)
            {
                classHolder.className = themeSettings.themeOptions;
                console.log("%c✔ Theme settings loaded", "color: #148f32");
            }
            else
            {
                console.log("Heads up! Theme settings is empty or does not exist, loading default settings...");
            }
            if (themeSettings.themeURL && !document.getElementById('mytheme'))
            {
                var cssfile = document.createElement('link');
                cssfile.id = 'mytheme';
                cssfile.rel = 'stylesheet';
                cssfile.href = themeURL;
                document.getElementsByTagName('head')[0].appendChild(cssfile);
            }
            /** 
             * Save to localstorage 
             **/
            var saveSettings = function()
            {
                themeSettings.themeOptions = String(classHolder.className).split(/[^\w-]+/).filter(function(item)
                {
                    return /^(nav|header|mod|display)-/i.test(item);
                }).join(' ');
                if (document.getElementById('mytheme'))
                {
                    themeSettings.themeURL = document.getElementById('mytheme').getAttribute("href");
                };
                localStorage.setItem('themeSettings', JSON.stringify(themeSettings));
            }
            /** 
             * Reset settings
             **/
            var resetSettings = function()
            {
                localStorage.setItem("themeSettings", "");
            }

        </script>
        <!-- BEGIN Page Wrapper -->
        <div class="page-wrapper">
            <div class="page-inner">
                <!-- BEGIN Left Aside -->
                <?php include 'inc/aside_inc.php' ?>
                <!-- END Left Aside -->
                <div class="page-content-wrapper">
                    <!-- BEGIN Page Header -->
                    <?php include 'inc/header_inc.php' ?>    
                    <!-- END Page Header -->
                    <!-- BEGIN Page Content -->
                    <!-- the #js-page-content id is needed for some plugins to initialize -->
                    <main id="js-page-content" role="main" class="page-content">
                        <ol class="breadcrumb page-breadcrumb"> 
                            <li class="breadcrumb-item"><a href="javascript:void(0);">FlairTech Admin</a></li>
                            <li class="breadcrumb-item">Add Claim</li>
                            <li class="breadcrumb-item">Internal Supervision Claim</li>
                            <li class="position-absolute pos-top pos-right d-none d-sm-block"><span class="js-get-date"></span></li>
                        </ol>
                        <div class="subheader">
                            <h1 class="subheader-title">
                                <i class='subheader-icon fal fa-table'></i> Internal Supervision/Examination Setup <span class='fw-300'></span> 
                                
                            </h1>
                        </div>
                        
                        <div class="row">
                            <div class="col-xl-12">
                                <div id="panel-1" class="panel">
                                    <div class="panel-hdr">
                                        <h2>
                                        Manage Claim
                                        </h2>
                                       
                                    </div>
                                    <div class="panel-container show">
                                        <div class="panel-content">
                                             <div class="row">
                                                <div class="col-xl-12">
                                                <div class="form-group">
                                                <div class="input-group">
                                                    <select class="select2 form-control w-30" id="user_search" aria-label="usertype" required>
                                                        <option value="" selected="">Select Tutor</option>
                                                        <?php foreach($users as $user): ?>
                                                            <option value="<?php echo $user['user_id'] ?>"><?php echo $user['staff_id'] ?> | <?php echo $user['name'] ?> | <?php echo $user['dept_name'] ?></option>
                                                        <?php endforeach ?>
                                                        
                                                    </select>
                                                    <div class="input-group-append input-group-prepend">
                                                        <span class="input-group-text">
                                                            <i class="fal fa-exchange fs-xl"></i>
                                                        </span>
                                                    </div>
                                                    <select class="custom-select" id="academic_year_search" aria-label="usertype">
                                                        <option value="" selected="">Select Academic Year</option>
                                                        <?php foreach($academic_years as $a_year): ?>
                                                            <option value="<?php echo $a_year['academic_year_id'] ?>"><?php echo $a_year['academic_year'] ?></option>
                                                        <?php endforeach ?>
                                                        
                                                    </select>
                                                    <div class="input-group-append input-group-prepend">
                                                        <span class="input-group-text">
                                                            <i class="fal fa-exchange fs-xl"></i>
                                                        </span>
                                                    </div>
                                                    <select class="custom-select" id="claim_type_search" aria-label="usertype">
                                                        <option value="" selected="">Select Claim Type</option>
                                                        <?php foreach($claim_types as $claim_type): ?>
                                                            <option value="<?php echo $claim_type['claim_type_id'] ?>"><?php echo $claim_type['claim_type'] ?></option>
                                                        <?php endforeach ?>
                                                    </select>
                                                    <select class="custom-select" id="degree_search" aria-label="usertype">
                                                        <option value="" selected="">Select Degree</option>
                                                        <?php foreach($degrees as $degree): ?>
                                                            <option value="<?php echo $degree['degree_id'] ?>"><?php echo $degree['degree'] ?></option>
                                                        <?php endforeach ?>
                                                    </select>
                                                    <div class="input-group-append">
                                                        <button type="button" class="btn btn-success shadow-0" id="btn_search"><i class="fal fa-search fs-xl"></i> Search</button>
                                                        
                                                    </div>
                                                </div>
                                                
                                            </div>


                                            <div class="result hide">
                                                
                                            </div>
                                        <div class="row">
                                                <div class="col-xl-12">
                                                    <!-- datatable start -->
                                                    <table id="dt-basic-example" class="table table-bordered table-hover table-striped w-100"></table>
                                                    <!-- datatable end -->
                                                </div>
                                            
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </main>
                    <!-- this overlay is activated only when mobile menu is triggered -->
                    <div class="page-content-overlay" data-action="toggle" data-class="mobile-nav-on"></div> <!-- END Page Content -->
                    <!-- BEGIN Page Footer -->
                <?php include 'inc/footer_inc.php' ?>
                    
        <!-- END Page Settings -->
        
        <!-- base vendor bundle: 
            DOC: if you remove pace.js from core please note on Internet Explorer some CSS animations may execute before a page is fully loaded, resulting 'jump' animations 
                        + pace.js (recommended)
                        + jquery.js (core)
                        + jquery-ui-cust.js (core)
                        + popper.js (core)
                        + bootstrap.js (core)
                        + slimscroll.js (extension)
                        + app.navigation.js (core)
                        + ba-throttle-debounce.js (core)
                        + waves.js (extension)
                        + FlairTech panels.js (extension)
                        + src/../jquery-snippets.js (core) -->
        <!-- <script src="js/jquery.min.js"></script> -->
        <script src="js/vendors.bundle.js"></script>
        <script src="js/app.bundle.js"></script>
        <!-- datatble responsive bundle contains: 
    + jquery.dataTables.js
    + dataTables.bootstrap4.js
    + dataTables.autofill.js							
    + dataTables.buttons.js
    + buttons.bootstrap4.js
    + buttons.html5.js
    + buttons.print.js
    + buttons.colVis.js
    + dataTables.colreorder.js							
    + dataTables.fixedcolumns.js							
    + dataTables.fixedheader.js						
    + dataTables.keytable.js						
    + dataTables.responsive.js							
    + dataTables.rowgroup.js							
    + dataTables.rowreorder.js							
    + dataTables.scroller.js							
    + dataTables.select.js							
    + datatables.styles.app.js
    + datatables.styles.buttons.app.js -->
    
    
        <script src="js/select2.bundle.js"></script>
        <script src="js/datagrid/datatables/datatables.bundle.js"></script>
        <script src="js/notifications/sweetalert2/sweetalert2.bundle.js"></script>
        
        <script>
            
            $(document).ready(function()
            {
                var user_id = '<?php echo $_SESSION['user_id'] ?>';
                
                /* 
                NOTES:
                    
                    Column id
                    ---------------------------------------------------
                    Please always keep in mind that DataTable framework allows two different kinds of "rows": Arrays and Objects. In first case columns are indexed through integers; in second case columns are indexed by their attribute name. Usually JSON's use the Object approach, but we cannot be sure.


                    Row key
                    ---------------------------------------------------
                    There is no default key in the table. Inside your callback functions, probably you will need a row key to build URL's, in that case you can get them from the rowdata parameter.


                COLUMN DEFINITIONS:

                    title = "string" - title name on table header th and on form labels
                    ---------------------------------------------------
                    id = "string" - id assigned to imput element when editing/adding in modal
                    ---------------------------------------------------
                    data = "string"  - data name from the dataset
                    ---------------------------------------------------
                    type = "text" | "select" | "hidden" | "readonly"  - Type of HTML input to be shown.
                    ---------------------------------------------------
                    hoverMsg = "some msg" - The message will appear as a tooltip over the input field.
                    ---------------------------------------------------
                    pattern = r.e.  - If type is "input", the typed text will be matched against given regular expression, before submit.
                    ---------------------------------------------------
                    msg = "some string" - An error message that is displayed in case pattern is not matched. Set HTML "data-errorMsg" attribute.
                    ---------------------------------------------------
                    maxLength = integer - If type is "input", set HTML "maxlength" attribute.
                    ---------------------------------------------------
                    options = ["a", "b", "c"] - If type is "select", the options that shall be presented.
                    ---------------------------------------------------
                    select2 = {} - If type is "select", enable a select2 component. Select2 jQuery plugin must be linked. More select2 configuration options may be passed within the array.
                    ---------------------------------------------------
                    datepicker = {} - If type is "text", enable a datepicker component. jQuery-UI plugin must be linked. More datepicker configuration options may be passed within the array.
                    ---------------------------------------------------
                    multiple = true | false - Set HTML "multiple" attribute (for use with select2).
                    ---------------------------------------------------
                    unique = true | false - Ensure that no two rows have the same value. The check is performed client side, not server side. Set HTML "data-unique" attribute. (Probably there's some issue with this).
                    ---------------------------------------------------
                    uniqueMsg = "some string" - An error message that is displayed when the unique constraint is not respected. Set HTML "data-uniqueMsg" attribute.
                    ---------------------------------------------------
                    special = "any string" - Set HTML "data-special" attribute (don't know what's that needed for).
                    ---------------------------------------------------
                    defaultValue = "any string" - Adds a default value when adding a row
                    ---------------------------------------------------
                */


                // Event Lot
                var events = $("#app-eventlog");
                var all_programs = [<?php echo $all_programs ?>];
                var all_academic_years = [<?php echo $all_academic_years ?>];
                var all_courses = [<?php echo $all_courses ?>];
                var all_semesters = [<?php echo $all_semesters ?>];
              
                
                // Column Definitions
                var columnSet = [
                {
                    title: "RowId",
                    id: "internal_claim_id",
                    data: "internal_claim_id",
                    placeholderMsg: "Server Generated ID",
                    "visible": false,
                    "searchable": false,
                    type: "hidden"
                },
                {
                    title: "Staff ID",
                    id: "staff_id",
                    data: "staff_id",
                   
                },
                {
                    title: "Name",
                    id: "name",
                    data: "name",
                    
                },
                {
                    title: "Contact",
                    id: "phone",
                    data: "phone",
                    
                },    
                {
                    title: "Academic Year",
                    id: "academic_year",
                    data: "academic_year",
                    placeholderMsg: "Academic Year",
                    type: "select",
                    "options":
                    all_academic_years
                },
                {
                    title: "Claim Type",
                    id: "claim_type",
                    data: "claim_type",
                    placeholderMsg: "claim type",
                    type: "select",
                    "options":
                    all_semesters
                },
                {
                    title: "Degree Supervised",
                    id: "degree",
                    data: "degree",
                    placeholderMsg: "Degree Supervised",
                    type: "select",
                    "options":
                    all_semesters
                },
                {
                    title: "Student Index Number",
                    id: "stud_id",
                    data: "stud_id",
                    placeholderMsg: "Index Number of Student",
                    type: "text"
                    
                },
                {
                    title: "Project Title",
                    id: "project_title",
                    data: "project_title",
                    placeholderMsg: "Title of Thesis/Long Essay",
                    type: "textarea",
                    
                },
                {
                    title: "Status",
                    id: "status",
                    data: "status",
                    
                    
                }
                
               
                
            ]

                //Get domain
                var BaseUrl = window.location.origin;
                /* start data table */
                var myTable = $('#dt-basic-example').dataTable(
                {
                    /* check datatable buttons page for more info on how this DOM structure works */
                    dom: "<'row mb-3'<'col-sm-12 col-md-6 d-flex align-items-center justify-content-start'f><'col-sm-12 col-md-6 d-flex align-items-center justify-content-end'B>>" +
                        "<'row'<'col-sm-12'tr>>" +
                        "<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
                    ajax: "controller/internal_claim_code.php?hod=",
                    columns: columnSet,
                    /* selecting multiple rows will not work */
                    select: 'single',
                    /* altEditor at work */
                    altEditor: true,
                    responsive: true,
                    
                    /* buttons uses classes from bootstrap, see buttons page for more details */
                    buttons: [
                    
                    {
                        text: '<i class="fal fa-sync mr-1"></i> Refresh',
                        name: 'refresh',
                        className: 'btn-primary btn-sm'
                    },
                    {
                            extend: 'pdfHtml5',
                            text: 'PDF',
                            titleAttr: 'Generate PDF',
                            className: 'btn-outline-danger btn-sm mr-1'
                    },
                    {
                        extend: 'excelHtml5',
                        text: 'Excel',
                        titleAttr: 'Generate Excel',
                        className: 'btn-outline-success btn-sm mr-1'
                    },
                    {
                        extend: 'csvHtml5',
                        text: 'CSV',
                        titleAttr: 'Generate CSV',
                        className: 'btn-outline-primary btn-sm mr-1'
                    },
                    {
                        extend: 'print',
                        text: 'Print',
                        titleAttr: 'Print Table',
                        className: 'btn-outline-primary btn-sm'
                    }
                ],
                    columnDefs: [],
                    /* default callback for insertion: mock webservice, always success */
                    onAddRow: function(dt, rowdata, success, error)
                    {
                        var myFormData = new FormData();
                        myFormData.append('academic_yr',rowdata.academic_year);                       
                        myFormData.append('user_id',user_id);
                        myFormData.append('add_claim','');
                        rowdata['ex_id'] = '';
                        success(rowdata);
                        
                        $.ajax({
                            url: 'controller/certificate_code.php',
                            type: 'POST',
                            processData: false, // important
                            contentType: false, // important
                            dataType : 'json',
                            data: myFormData,
                            beforeSend:function(res){
                            },
                            complete:function(res){
                            },
                            success:function(res){
                                Swal.fire(
                                {
                                    type: "success",
                                    title: "Add Successful",
                                    showConfirmButton: false,
                                    timer: 2500
                                });
                            },
                            error:function(res){
                            console.log(res);
                            }
                        });
                        

                        // demo only below:
                        events.prepend('<p class="text-success fw-500">' + JSON.stringify(rowdata, null, 4) + '</p>');
                    },
                    
                    
                });

                    $('#btn_search').click(function(){
                    $('.result').html("");
                    var user_id = $('#user_search').val();
                    var academic_year_id = $('#academic_year_search').val();
                    var degree_id = $('#degree_search').val();
                    var claim_type_id = $('#claim_type_search').val();
                    var serverData = {
                        user_id:user_id,
                        academic_year_id:academic_year_id,
                        degree_id:degree_id,
                        claim_type_id:claim_type_id,
                        searchClaim:''
                    }
                    $('#approve_claim'). prop('disabled', false);
                    $.get('controller/internal_claim_code.php',serverData,function(res){
                        var searchResult = JSON.parse(res);
                        var display = '';
                        if(searchResult){
                        for(var i=0;i<searchResult.length;i++){
                            
                            if(searchResult[i]['status']==1){
                            display = `<button data-toggle="modal" data-target="#default-example-modal-sm${searchResult[i]['user_id']}" class="btn btn-warning">Continue</button>`;
                        }else{
                            display = `<br /><span class="h5 warning" style="color:darkred">Claim Approved <button class="btn btn-info" data-toggle="modal" data-target="#view${searchResult[i]['user_id']}" >View Details</button> </span>`;
                            
                        }

                        var serverApprovalDetails = {
                            get_approval:'',
                            user_id:searchResult[i]['user_id']
                        };

                        var approvee_detail = '';
                        if(searchResult[i]['issued_id'] != 0){
                            approvee_detail = ` <div class="card mb-g">
                                    <div class="card-body">
                                        <a href="javascript:void(0);" class="d-flex flex-row align-items-center">
                                            <div class='icon-stack display-3 flex-shrink-0'>
                                                <i class="fal fa-circle icon-stack-3x opacity-100 color-warning-400"></i>
                                                <i class="fas fa-handshake icon-stack-1x opacity-100 color-warning-500"></i>
                                            </div>
                                            <div class="ml-3">
                                                <strong>
                                                    Name: ${searchResult[i]['name']}
                                                </strong>
                                                <br>
                                                <strong>
                                                    Claim Type: ${searchResult[i]['claim_type']}
                                                </strong>
                                                <br>
                                                Staff ID : ${searchResult[i]['staff_id']}
                                                <br>
                                                Phone Number: ${searchResult[i]['phone']}
                                                <br>
                                                Amount: ${searchResult[i]['signature']}
                                                <br>
                                                Approval Date: ${searchResult[i]['date_approved']}
                                            </div>
                                        </a>
                                    </div>
                                </div>  `;

                                }

                        var viewDetailTemp = ``;
                        
                        var template = `
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true"><i class="fal fa-times"></i></span>
                            </button>
                            <div class="d-flex align-items-center">
                                <div class="alert-icon">
                                    <span class="icon-stack icon-stack-md">
                                        <i class="base-2 icon-stack-3x color-success-400"></i>
                                        <i class="base-10 text-white icon-stack-1x"></i>
                                        <i class="ni md-profile color-info-800 icon-stack-2x"></i>
                                    </span>
                                </div>
                                <div class="flex-1">
                                    <span class="h5">${searchResult[i]['name']} | ${searchResult[i]['academic_year']} | ${searchResult[i]['dept_name']} </span> 
                                    ${display}
                                </div>
                            </div>
                        </div>

                        <!-- Modal Form -->
                                            <div class="modal fade" id="default-example-modal-sm${searchResult[i]['user_id']}" tabindex="-1" role="dialog" aria-hidden="true">
                                                <div class="modal-dialog modal-lg" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title">Approve Claim</h5>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true"><i class="fal fa-times"></i></span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                <form action="">
                                                            <div class="form-group">
                                                                <label class="form-label" for="claim_id">Claim ID</label>
                                                                <input type="hidden" disabled id="claim_id" value="${searchResult[i]['internal_claim_id']}" class="form-control">
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="form-label" for="approved_by">Approved By: <?php echo $_SESSION['name'] ?></label>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="form-label" for="claim_type">Academic: ${searchResult[i]['academic_year']} </label>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="form-label" for="claim_type">Claim Type: ${searchResult[i]['claim_type']} </label>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="form-label" for="degree">Degree Type: ${searchResult[i]['degree']}</label>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="form-label" for="claim_type">Number Of Students: ${searchResult[i]['claim_type']} </label>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="form-label" for="claim_type">Rate: ${searchResult[i]['rate']} </label>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="form-label" for="claim_type">Amount To be paid: ${searchResult[i]['amount']}ghc </label>
                                                            </div>
                                                                </div>
                                                            </div>                                                                    
                                                            </form>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                            <button type="button" id="deny_claim_btn" class="btn btn-danger">Deny</button>
                                                            <button type="button" id="approve_claim_btn" class="btn btn-primary">Approve</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- Modal Details -->
                                            <div class="modal fade" id="view${searchResult[i]['user_id']}" tabindex="-1" role="dialog" aria-hidden="true">
                                                <div class="modal-dialog modal-md" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title">Detail</h5>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true"><i class="fal fa-times"></i></span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                        ${approvee_detail}
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                        `;
                        if(searchResult.length == 1){
                            $('.result').html(template);
                        }else if(searchResult.length > 1){
                            $('.result').append(template);
                        }else{
                            $('.result').html('<span class=" h6 bg-warning">Claim Not Found!</span>');
                        }
                        
                        
                        
                        
                    }
                    }else{
                        $('.result').html('<span class=" h6 bg-warning">Claim Not Found!</span>');
                    }
                    
                    
                        
                    });
                }); 
             $('body').on('click','#approve_claim_btn',function(){
                   console.log('hi');
                   var issued_by = $('#issued_by').val();
                   var claim_id = $('#claim_id').val();
                   var serverData = {
                    issued_by:issued_by,     
                    claim_id:claim_id,
                    approve_claim:''
                   };
                   $.post('controller/internal_claim_code.php',serverData,function(res){
                        var response = JSON.parse(res);
                        if(response.message=="success"){
                            myTable.DataTable().columns.adjust().draw();
                            Swal.fire(
                                {
                                    type: "success",
                                    title: "Approval Successful",
                                    showConfirmButton: false,
                                    timer: 2500
                                });
                                $('#save_collection'). prop('disabled', true);
                        }else{
                            Swal.fire(
                                {
                                    type: "warning",
                                    title: "Approval Unsuccessful",
                                    showConfirmButton: false,
                                    timer: 2500
                                }); 
                        }
                   });

                });
             $('body').on('click','#deny_claim',function(){
                   
                   var issued_by = $('#issued_by').val();
                   var claim_id = $('#claim_id').val();
                   var serverData = {
                    certificate_serial:certificate_serial,
                    issued_by:issued_by,     
                    claim_id:claim_id,
                    deny_claim:''
                   };
                   $.post('controller/collection_code.php',serverData,function(res){
                        var response = JSON.parse(res);
                        if(response.message=="success"){
                            myTable.DataTable().columns.adjust().draw();
                            Swal.fire(
                                {
                                    type: "success",
                                    title: "Deny Successful",
                                    showConfirmButton: false,
                                    timer: 2500
                                });
                                $('#approve_claim'). prop('disabled', true);
                        }else{
                            Swal.fire(
                                {
                                    type: "warning",
                                    title: "Deny Unsuccessful",
                                    showConfirmButton: false,
                                    timer: 2500
                                }); 
                        }
                   });

                });

                             

            });
        </script>
    </body>

</html>
