
<!DOCTYPE html>

<html lang="en">
 <head>
    <meta charset="utf-8">
    <title>AAMUSTED</title> 
    <meta name="description" content="Login - SmartAdmin v4.0.3">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, user-scalable=no, minimal-ui">
    <!-- Call App Mode on ios devices -->
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <!-- Remove Tap Highlight on Windows Phone IE -->
    <meta name="msapplication-tap-highlight" content="no">
    <!-- base css -->
    <link rel="stylesheet" media="screen, print" href="css/vendors.bundle.css">
    <link rel="stylesheet" media="screen, print" href="css/app.bundle.css">
    <!-- Place favicon.ico in the root directory -->
    <link rel="apple-touch-icon" sizes="180x180" href="img/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="img/favicon/favicon-32x32.png">
    <link rel="mask-icon" href="img/favicon/safari-pinned-tab.svg" color="#5bbad5">
    <link rel="stylesheet" href="css/notifications/sweetalert2/sweetalert2.bundle.css">
    <meta name="hostname" content="smartadmin.lodev09.com">
    <meta name="app-url" content="index.html">
    <meta name="assets-url" content="index.html">
    <meta name="environment" content="dev">
    <!-- Optional: page related CSS -->
    <!-- PHP docs -->
    <link rel="stylesheet" media="screen, print" href="css/markdown.css">
    	<link rel="stylesheet" media="screen, print" href="css/page-login.css">
</head>
    <body>
        <div class="blankpage-form-field" >
           <div style="background-color:#2B2A7B !important" class="page-logo m-0 w-100 align-items-center justify-content-center rounded border-bottom-left-radius-0 border-bottom-right-radius-0 px-4">
                <a href="javascript:void(0)" class="page-logo-link press-scale-down d-flex align-items-center">
                    <img src="img/aamusted.png" style="width: 10%;height:auto; margin-left:180px" class="img img-responsive" alt="UEW logo" aria-roledescription="logo">
                    <span class="page-logo-text mr-1">AAMUSTED CLAIMS MANAGER</span>
                    <i class="fal fa-angle-down d-inline-block ml-1 fs-lg color-primary-300"></i>
                </a>
            </div>
            <div class="card p-4 border-top-left-radius-0 border-top-right-radius-0">
                <form action="">
                    <div class="alert bg-danger-600 alert-dismissible fade show d-none">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true"><i class="fal fa-times"></i></span>
                        </button>
                        <div class="d-flex align-items-center">
                            <div class="alert-icon width-8">
                                <span class="icon-stack icon-stack-xl">
                                    <i class="base-2 icon-stack-3x color-danger-400"></i>
                                    <i class="base-10 text-white icon-stack-1x"></i>
                                    <i class="ni md-profile color-danger-800 icon-stack-2x"></i>
                                </span>
                            </div>
                            <div class="flex-1 pl-1">
                                <span>
                                    Invalid Credential!
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="username">Username</label>
                        <input type="text" id="user_name" class="form-control" placeholder="your id or email" >
                        <span class="help-block">
                            Your unique username to app
                        </span>
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="password">Password</label>
                        <input type="password" id="user_password" class="form-control" placeholder="password" >
                        <span class="help-block">
                            Your password
                        </span>
                    </div>
                    <div class="form-group text-left">
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="rememberme">
                            <label class="custom-control-label" for="rememberme"> Remember me for the next 30 days</label>
                        </div>
                    </div>
                    <button type="button" id="btn_auth" class="btn btn-info float-right">Login</button>
                </form>
            </div>
            <!-- <div class="blankpage-footer text-center">
                <a href="#"><strong>Recover Password</strong></a> | <a href="#"><strong>Register Account</strong></a>
            </div> -->
        </div>
        <div class="login-footer p-2">
            <div class="row">
                <div class="col col-sm-12 text-center">
                    <!-- <i><strong>System Message:</strong> You were logged out from 198.164.246.1 on Saturday, March, 2017 at 10.56AM</i> -->
                </div>
            </div>
        </div>
        <video poster="img/backgrounds/clouds.png" id="bgvid" playsinline autoplay muted loop>
            <source src="media/video/cc.webm" type="video/webm">
            <source src="media/video/cc.mp4" type="video/mp4">
        </video>
<!-- base vendor bundle: 
             DOC: if you remove pace.js from core please note on Internet Explorer some CSS animations may execute before a page is fully loaded, resulting 'jump' animations 
                        + pace.js (recommended)
                        + jquery.js (core)
                        + jquery-ui-cust.js (core)
                        + popper.js (core)
                        + bootstrap.js (core)
                        + slimscroll.js (extension)
                        + app.navigation.js (core)
                        + ba-throttle-debounce.js (core)
                        + waves.js (extension)
                        + smartpanels.js (extension)
                        + src/../jquery-snippets.js (core) -->
<script src="js/vendors.bundle.js"></script>
<script src="js/app.bundle.js"></script>
<script src="js/notifications/sweetalert2/sweetalert2.bundle.js"></script>
        <!-- Page related scripts -->
<script>
    $(document).ready(function(){
        $('#btn_auth').click(function(){
            var user_name = $('#user_name').val();
            var user_password = $('#user_password').val();
            var serverData = {
                user_name:user_name,
                user_password:user_password,
                auth:''
            }

        $.get('controller/user_code.php',serverData,function(res){
            var response = JSON.parse(res);
            if(response.message == 'success'){
                window.location.replace('dashboard.php');
            }else if(response.message == 'fail'){
                Swal.fire(
                    {
                        type: "warning",
                        title: "Invalid Credential",
                        showConfirmButton: false,
                        timer: 2500
                    });
            }else{
                alert('500');
            }
        });
        });
    });
</script>
</body>

</html>
