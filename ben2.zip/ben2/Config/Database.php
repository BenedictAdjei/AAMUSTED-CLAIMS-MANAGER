<?php 
/**
 * Connection to Database
 *
 * @author 
 */
class Database{
	// Declare Database Variable Constants
	const DB_HOST = 'localhost';
	const DB_USER = 'root';
	const DB_PASSWORD = '';
	const DB_NAME = 'aamusted_cms';


	public static function connect(){
		$dsn = 'mysql:dbname='.self::DB_NAME.';host='.self::DB_HOST;
		try{
			//Try to Connect to Database
			$conn = new PDO($dsn,self::DB_USER,self::DB_PASSWORD);
		}catch(PDOException $e){
			//Throw an Exception if Connection Fails
			throw new Exception("Database Connection Failed: ". $e->getMessage());
		}
		//Return Database connection
		return $conn;
	}
}