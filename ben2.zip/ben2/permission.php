<!DOCTYPE html>

<html lang="en">
    
<head>
        <?php include 'controller/php_inc/setup_inc_code.php' ?>
        <?php include 'inc/meta_inc.php' ?>
        <!-- base css -->
        <?php include 'inc/styles_inc.php' ?>
        <script src="js/jquery.min.js"></script>
</head>
    <body class="mod-bg-1 ">
        <!-- DOC: script to save and load page settings -->
        <script>
    
            /**
             *	This script should be placed right after the body tag for fast execution 
            *	Note: the script is written in pure javascript and does not depend on thirdparty library
            **/
            'use strict';

            var classHolder = document.getElementsByTagName("BODY")[0],
                /** 
                 * Load from localstorage
                 **/
                themeSettings = (localStorage.getItem('themeSettings')) ? JSON.parse(localStorage.getItem('themeSettings')) :
                {},
                themeURL = themeSettings.themeURL || '',
                themeOptions = themeSettings.themeOptions || '';
            /** 
             * Load theme options
             **/
            if (themeSettings.themeOptions)
            {
                classHolder.className = themeSettings.themeOptions;
                console.log("%c✔ Theme settings loaded", "color: #148f32");
            }
            else
            {
                console.log("Heads up! Theme settings is empty or does not exist, loading default settings...");
            }
            if (themeSettings.themeURL && !document.getElementById('mytheme'))
            {
                var cssfile = document.createElement('link');
                cssfile.id = 'mytheme';
                cssfile.rel = 'stylesheet';
                cssfile.href = themeURL;
                document.getElementsByTagName('head')[0].appendChild(cssfile);
            }
            /** 
             * Save to localstorage 
             **/
            var saveSettings = function()
            {
                themeSettings.themeOptions = String(classHolder.className).split(/[^\w-]+/).filter(function(item)
                {
                    return /^(nav|header|mod|display)-/i.test(item);
                }).join(' ');
                if (document.getElementById('mytheme'))
                {
                    themeSettings.themeURL = document.getElementById('mytheme').getAttribute("href");
                };
                localStorage.setItem('themeSettings', JSON.stringify(themeSettings));
            }
            /** 
             * Reset settings
             **/
            var resetSettings = function()
            {
                localStorage.setItem("themeSettings", "");
            }

        </script>
        <!-- BEGIN Page Wrapper -->
        <div class="page-wrapper">
            <div class="page-inner">
                <!-- BEGIN Left Aside -->
                <?php include 'inc/aside_inc.php' ?>
                <!-- END Left Aside -->
                <div class="page-content-wrapper">
                    <!-- BEGIN Page Header -->
                    <?php include 'inc/header_inc.php' ?>    
                    <!-- END Page Header -->
                    <!-- BEGIN Page Content -->
                    <!-- the #js-page-content id is needed for some plugins to initialize -->
                    <main id="js-page-content" role="main" class="page-content">
                        <ol class="breadcrumb page-breadcrumb"> 
                            <li class="breadcrumb-item"><a href="javascript:void(0);">AmgTech Admin</a></li>
                            <li class="breadcrumb-item">Users</li>
                            <li class="position-absolute pos-top pos-right d-none d-sm-block"><span class="js-get-date"></span></li>
                        </ol>
                        <div class="subheader">
                            <h1 class="subheader-title">
                                <i class='subheader-icon fal fa-table'></i> Roles <span class='fw-300'></span> 
                                
                            </h1>
                        </div>
                        
                        <div class="row">
                            <div class="col-xl-12">
                                <?php foreach($roles as $role): ?>
                                    <div id="panel-1" class="panel">
                                    <div class="panel-hdr">
                                    <h2 style="font-weight:bolder">
                                        Manage Roles For <?php echo $role['role_name'] ?>
                                    </h2>
                                        
                                    </div>
                                    <?php
                                             $check_user_permissions = $user->read_user_permissions($role['role_id']);
                                        
                                        // if($check_user_permissions && $system_permissions){
                                        //     $result = array_diff($check_user_permissions[0],$system_permissions[0]);
                                        // }else{
                                        //     $result = array();
                                        // }
                                        $array1 = array();
                                        $array2 = array();  
                                        if($check_user_permissions){
                                        foreach($check_user_permissions as $permissions){
                                            array_push($array1,$permissions['system_permission_id']);
                                        }
                                        }

                                        foreach($system_permissions as $permissions){
                                            array_push($array2,$permissions['system_permission_id']);
                                        }
                                       
                                        $array3 = array_diff($array2,$array1);
                                        
                                        
                                    ?>
                                    <div class="panel-container show">
                                        <div class="panel-content">
                                        <div class="form-group">
                                        <select multiple="multiple" size="10" name="duallistbox_demo2" id="permissions<?php echo $role['role_id'] ?>" class="initializeDuallistbox">
											
                                                
                                            <?php foreach($array1 as $permission => $value): ?>
                                                <?php
                                                    $perm = $user->get_system_permission($value);
                                                ?>
                                                <option value="<?php echo $value ?>" selected><?php echo $perm[0]['display_name'] ?></option>
                                                
                                            <?php endforeach ?>
                                            <?php if(count($array3) > 0): ?>
                                            <?php foreach($array3 as $perm => $value): ?>
                                                <?php
                                                    $perm = $user->get_system_permission($value);
                                                ?>
                                                <option value="<?php echo $value ?>" ><?php echo $perm[0]['display_name'] ?></option>
                                            <?php endforeach ?>
                                            <?php elseif(count($array3) == 0): ?>
                                                <?php foreach($array3 as $perm => $value): ?>
                                                    <?php
                                                    $perm = $user->get_system_permission($value);
                                                ?>
                                                <option value="<?php echo $value ?>" ><?php echo $perm[0]['display_name'] ?></option>
                                            <?php endforeach ?>
                                                <?php else: ?>
                                                    <?php foreach($array2 as $perm => $value): ?>
                                                    <?php
                                                    $perm = $user->get_system_permission($value);
                                                ?>
                                                <option value="<?php echo $value ?>" ><?php echo $perm[0]['display_name'] ?></option>
                                            <?php endforeach ?>
                                            <?php endif ?>
										</select>
                                        </div>
                                        <div class="from-group">
                                        <button class="btn btn-info pull-right btn-block" id="btn<?php echo $role['role_id'] ?>">Set Roles</button>
                                        </div>
                                        <div class="row">
                                                <div class="col-xl-12">
                                                   
                                                </div>
                                            
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                                <script>
                                    $(document).ready(function(){
                                        $('#btn<?php echo $role['role_id'] ?>').click(function(){
                                            var system_permission_id = $('#permissions<?php echo $role['role_id'] ?>').val();
                                            var role_id = '<?php echo $role['role_id'] ?>';
                                            serverData = {
                                                system_permission_id:system_permission_id,
                                                role_id:role_id,
                                                set_permission:''
                                            };
                                            $.post('controller/user_code.php',serverData,function(res){
                                                var response = JSON.parse(res);
                                                if(response.message == 'success'){
                                                    Swal.fire(
                                                    {
                                                        type: "success",
                                                        title: "Role Set Successfully",
                                                        showConfirmButton: false,
                                                        timer: 2500
                                                    });
                                                }else if(response.message == 'success'){
                                                    Swal.fire(
                                                    {
                                                        type: "warning",
                                                        title: "Role Set Unsuccessful",
                                                        showConfirmButton: false,
                                                        timer: 2500
                                                    });
                                                }else{
                                                    Swal.fire(
                                                    {
                                                        type: "warning",
                                                        title: "Server Error!",
                                                        showConfirmButton: false,
                                                        timer: 2500
                                                    });
                                                }
                                            });
                                        })
                                    });
                                </script>
                                <?php endforeach ?>
                            </div>
                        </div>
                    </main>
                    <!-- this overlay is activated only when mobile menu is triggered -->
                    <div class="page-content-overlay" data-action="toggle" data-class="mobile-nav-on"></div> <!-- END Page Content -->
                    <!-- BEGIN Page Footer -->
                <?php include 'inc/footer_inc.php' ?>
        <script src="js/vendors.bundle.js"></script>
        <script src="js/app.bundle.js"></script>
        <script src="js/datagrid/datatables/datatables2.bundle.js"></script>
        <script src="js/notifications/sweetalert2/sweetalert2.bundle.js"></script>
        <script src="js/jquery.bootstrap-duallistbox.min.js"></script>
        <script>
            $(document).ready(function()
            {
                /*
			 * BOOTSTRAP DUALLIST BOX
			 */
					
			var initializeDuallistbox = $('.initializeDuallistbox').bootstrapDualListbox({
	          nonSelectedListLabel: 'Non-selected',
	          selectedListLabel: 'Selected',
	          preserveSelectionOnMove: 'moved',
	          moveOnSelect: false,
	          nonSelectedFilter: ''
	        });
			
            
                // Event Lot
                var events = $("#app-eventlog");
                

            });

        </script>
    </body>

</html>
