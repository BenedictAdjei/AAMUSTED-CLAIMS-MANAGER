<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-hidden="true">
										<div class="modal-dialog" role="document">
											<div class="modal-content">
												<div class="modal-header no-bd">
													<h5 class="modal-title">
														<span class="fw-mediumbold">
														New</span> 
														<span class="fw-light">
															Role
														</span>
													</h5>
													<button type="button" class="close" data-dismiss="modal" aria-label="Close">
														<span aria-hidden="true">&times;</span>
													</button>
												</div>
												<form action="role.php" method="POST" id="add-role">
												<div class="modal-body">
													<p class="small">Add Role</p>
														<div class="row">
															<div class="col-sm-12">
																<div class="form-group form-group-default">
																	<label>Role</label>
																	<input id="role_name" name="name" type="text" class="form-control" placeholder="Role Name" required>
																</div>
															</div>
														</div>	
												</div>
												<div class="modal-footer no-bd">
													<button type="submit" id="add_role_btn" name="add_role_btn" class="btn btn-primary">Add</button>
													<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
												</div></form>
											</div>
											
										</div>
									</div>