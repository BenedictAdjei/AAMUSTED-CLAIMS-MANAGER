<!DOCTYPE html>

<html lang="en">
    
<head>
        <?php include 'controller/php_inc/setup_inc_code.php' ?>
        <?php include 'inc/meta_inc.php' ?>
        <!-- base css -->
        <?php include 'inc/styles_inc.php' ?>
        <?php
        function url(){
            return sprintf(
              "%s://%s%s",
              isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http',
              $_SERVER['SERVER_NAME'],
              $_SERVER['REQUEST_URI']
            );
          }
          $parse = parse_url(url());
        ?>
</head>
    <body class="mod-bg-1 ">
        <!-- DOC: script to save and load page settings -->
        <script>
    
            /**
             *	This script should be placed right after the body tag for fast execution 
            *	Note: the script is written in pure javascript and does not depend on thirdparty library
            **/
            'use strict';

            var classHolder = document.getElementsByTagName("BODY")[0],
                /** 
                 * Load from localstorage
                 **/
                themeSettings = (localStorage.getItem('themeSettings')) ? JSON.parse(localStorage.getItem('themeSettings')) :
                {},
                themeURL = themeSettings.themeURL || '',
                themeOptions = themeSettings.themeOptions || '';
            /** 
             * Load theme options
             **/
            if (themeSettings.themeOptions)
            {
                classHolder.className = themeSettings.themeOptions;
                console.log("%c✔ Theme settings loaded", "color: #148f32");
            }
            else
            {
                console.log("Heads up! Theme settings is empty or does not exist, loading default settings...");
            }
            if (themeSettings.themeURL && !document.getElementById('mytheme'))
            {
                var cssfile = document.createElement('link');
                cssfile.id = 'mytheme';
                cssfile.rel = 'stylesheet';
                cssfile.href = themeURL;
                document.getElementsByTagName('head')[0].appendChild(cssfile);
            }
            /** 
             * Save to localstorage 
             **/
            var saveSettings = function()
            {
                themeSettings.themeOptions = String(classHolder.className).split(/[^\w-]+/).filter(function(item)
                {
                    return /^(nav|header|mod|display)-/i.test(item);
                }).join(' ');
                if (document.getElementById('mytheme'))
                {
                    themeSettings.themeURL = document.getElementById('mytheme').getAttribute("href");
                };
                localStorage.setItem('themeSettings', JSON.stringify(themeSettings));
            }
            /** 
             * Reset settings
             **/
            var resetSettings = function()
            {
                localStorage.setItem("themeSettings", "");
            }

        </script>
        <!-- BEGIN Page Wrapper -->
        <div class="page-wrapper">
            <div class="page-inner">
                <!-- BEGIN Left Aside -->
                <?php include 'inc/aside_inc.php' ?>
                <!-- END Left Aside -->
                <div class="page-content-wrapper">
                    <!-- BEGIN Page Header -->
                    <?php include 'inc/header_inc.php' ?>    
                    <!-- END Page Header -->
                    <!-- BEGIN Page Content -->
                    <!-- the #js-page-content id is needed for some plugins to initialize -->
                    
                    <main id="js-page-content" role="main" class="page-content">
                        <!-- Page heading removed for composed layout -->
                        <div class="px-3 px-sm-5 pt-4">
                            <h2 class="mb-4">Verify Certificate</h2>
                            <h4 class="mb-4">
                            <div class="info text-success d-none"> 
                                <span id="count">0</span>
                                 Results for "<span id="term"></span>"
                            </div> 
                                <small class="mb-3">
                                   
                                </small>
                            </h4>
                            <div class="input-group input-group-lg mb-5 shadow-1 rounded">
                                <input type="text" class="form-control shadow-inset-2" id="search_term" aria-label="type 2 or more letters" placeholder="Search Certificate..." value="">
                                <div class="input-group-append">
                                   
                                    <button type="button" class="btn btn-primary dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <span class="sr-only">Toggle Dropdown</span>
                                    </button>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <a class="dropdown-item" id="by_index_number" href="#">Index Number</a>
                                        <a class="dropdown-item" id="by_name" href="#">Student Name</a>
                                        <a class="dropdown-item" id="by_serial" href="#">Certificate Serial</a> 
                                    </div>
                                </div>
                            </div>
                        </div>
                       
                       
                        <div class="px-3 px-sm-5 pb-4 results d-none">
                            
                            <!-- <ul class="pagination my-4">
                                <li class="page-item">
                                    <a class="page-link" href="#" aria-label="Previous">
                                        <span aria-hidden="true">«</span>
                                    </a>
                                </li>
                                <li class="page-item active">
                                    <a class="page-link" href="#">1</a>
                                </li>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="#" aria-label="Next">
                                        <span aria-hidden="true">»</span>
                                    </a>
                                </li>
                            </ul> -->
                        </div>
                    </main>



                    <!-- this overlay is activated only when mobile menu is triggered -->
                    <div class="page-content-overlay" data-action="toggle" data-class="mobile-nav-on"></div> <!-- END Page Content -->
                    <!-- BEGIN Page Footer -->
                <?php include 'inc/footer_inc.php' ?>
                    
        <!-- END Page Settings -->
        
        <!-- base vendor bundle: 
            DOC: if you remove pace.js from core please note on Internet Explorer some CSS animations may execute before a page is fully loaded, resulting 'jump' animations 
                        + pace.js (recommended)
                        + jquery.js (core)
                        + jquery-ui-cust.js (core)
                        + popper.js (core)
                        + bootstrap.js (core)
                        + slimscroll.js (extension)
                        + app.navigation.js (core)
                        + ba-throttle-debounce.js (core)
                        + waves.js (extension)
                        + AmgTech panels.js (extension)
                        + src/../jquery-snippets.js (core) -->
        <script src="js/vendors.bundle.js"></script>
        <script src="js/app.bundle.js"></script>
        <!-- datatble responsive bundle contains: 
    + jquery.dataTables.js
    + dataTables.bootstrap4.js
    + dataTables.autofill.js							
    + dataTables.buttons.js
    + buttons.bootstrap4.js
    + buttons.html5.js
    + buttons.print.js
    + buttons.colVis.js
    + dataTables.colreorder.js							
    + dataTables.fixedcolumns.js							
    + dataTables.fixedheader.js						
    + dataTables.keytable.js						
    + dataTables.responsive.js							
    + dataTables.rowgroup.js							
    + dataTables.rowreorder.js							
    + dataTables.scroller.js							
    + dataTables.select.js							
    + datatables.styles.app.js
    + datatables.styles.buttons.app.js -->
        <script src="js/datagrid/datatables/datatables2.bundle.js"></script>
        <script src="js/notifications/sweetalert2/sweetalert2.bundle.js"></script>
        <script>
            $(document).ready(function()
            {
                
               $('#by_index_number').click(function(){
                var template = '';
                var index_number = $('#search_term').val();
                var serverData = {
                    by_index_number:index_number
                };
                $('.results').addClass('d-none');
                $('.results').html('');

                $.get('controller/certificate_code.php',serverData,function(res){
                    var response = JSON.parse(res);
                    
                    var badge = '';
                    if(response.length > 0){
                        for(var i=0;i<response.length;i++){
                            if(response[i].collected==1){
                                badge = '<span class="badge badge-success badge-pill">been Collected</span>';
                            }else{
                                badge = '<span class="badge badge-danger badge-pill">not been Collected</span>';
                            }
                            template = `
                        <div class="tab-content">
                                <div class="tab-pane show active" id="tab-all" role="tabpanel" aria-labelledby="tab-all">
                                    <div class="card">
                                        <ul class="list-group list-group-flush">
                                            <li class="list-group-item py-4 px-4">
                                                <a href="javascript:void(0)" class="fs-lg fw-500">${response[i].index_number} - ${response[i].stud_name}</a>
                                                <div class="fs-xs mt-1">
                                                   
                                                    <a href="certificates/${response[i].picture}" class="text-success"><?php echo $parse['scheme'].'://'.$parse['host'].'/certificate_ms/certificates/${response[i].picture}'; ?></a>
                                                </div>
                                                <div class="mt-2">
                                                    <span class="text-muted"> ${response[i].date_created}</span> - This certificate was added by ${response[i].name} on ${response[i].date_created} and certificate has ${badge} 
                                                </div>
                                                <div class="d-flex flex-row mt-3">
                                                    <img src="certificates/${response[i].picture}" class="img img-responsive" style="width:200px;height:auto" alt="">
                                                </div>

                                                <div class="d-flex flex-row mt-3">
                                                <button type="button" id="fake${response[i].cert_id}" class="d-block btn btn-lg btn-danger mr-3">
                                                    <span class="fal  fa-times mr-1"></span>
                                                    Fake
                                                </button>
                                                <button type="button" id="valid${response[i].cert_id}" class="d-block btn btn-lg btn-success">
                                                    <span class="fal  fa-check mr-1"></span>
                                                    Valid
                                                </button>
                                                </div>
                                            </li>
                                           
                                        </ul>
                                    </div>
                                </div>
                             `;
                            $('.results').removeClass('d-none');
                            $('.results').append(template);

                            if(i<response.length){
                            $('body').on('click',`#valid${response[i].cert_id}`,function(){
                            $(this).attr('disabled','disabled');
                            
                            var string_id = $(this)[0].id;
                            var get_id = string_id.split("valid");
                            $('#fake'+id).attr('disabled','disabled');
                            var id = get_id[1];
                            var serverData  = {
                                cert_id:id,
                                user_id:'<?php echo $_SESSION['user_id'] ?>',
                                valid:1,
                                set_verification_by_index:''
                            };
                            $.post('controller/certificate_code.php',serverData,function(serverRes){
                                var serverResponse = JSON.parse(serverRes);
                                if(serverResponse.message=="success"){
                                    Swal.fire(
                                {
                                    type: "success",
                                    title: "Verification History Set to Valid",
                                    showConfirmButton: false,
                                    timer: 2500
                                });
                                }else{
                                    Swal.fire(
                                {
                                    type: "warning",
                                    title: "!Oops, something went wrong.",
                                    showConfirmButton: false,
                                    timer: 2500
                                });
                                }
                               
                            });
                        });

                        $('body').on('click',`#fake${response[i].cert_id}`,function(){
                            $(this).attr('disabled','disabled');
                            var string_id = $(this)[0].id;
                            var get_id = string_id.split("fake");
                            var id = get_id[1];
                            $('#valid'+id).attr('disabled','disabled');
                            var serverData  = {
                                cert_id:id,
                                valid:0,
                                user_id:'<?php echo $_SESSION['user_id'] ?>',
                                set_verification_by_index:''
                            };
                            $.post('controller/certificate_code.php',serverData,function(serverRes){
                                var serverResponse = JSON.parse(serverRes);
                                if(serverResponse.message=="success"){
                                    Swal.fire(
                                {
                                    type: "warning",
                                    title: "Verification History Set to Fake",
                                    showConfirmButton: false,
                                    timer: 2500
                                });
                                }else{
                                    Swal.fire(
                                {
                                    type: "warning",
                                    title: "!Oops, something went wrong.",
                                    showConfirmButton: false,
                                    timer: 2500
                                });
                                }
                            });
                        }); 
                            }
                        
                        }
                        $('.info').removeClass('d-none');
                        $('#count').html(response.length);
                        $('#term').html(index_number);

                        
                    }else{
                        $('.info').removeClass('d-none');
                        $('#count').html('0');
                        $('#term').html(index_number);
                        $('.results').removeClass('d-none');
                        template = `
                        <div class="tab-content">
                                <div class="tab-pane show active" id="tab-all" role="tabpanel" aria-labelledby="tab-all">
                                    <div class="card">
                                        <ul class="list-group list-group-flush">
                                            <li class="list-group-item py-4 px-4">
                                                <a href="javascript:void(0)" class="fs-lg fw-500">No Records Found!</a>
                                               
                                                   
                                                   
                                                </div>
                                            </li>
                                           
                                        </ul>
                                    </div>
                                </div>
                             `;
                            $('.results').html(template);
                    }
                    console.log(response);
                });
               });

               $('#by_name').click(function(){
                var template = '';
                var name = $('#search_term').val();
                var serverData = {
                    by_name:name
                };
                $('.results').addClass('d-none');
                $('.results').html('');

                $.get('controller/certificate_code.php',serverData,function(res){
                    var response = JSON.parse(res);
                    
                    var badge = '';
                    if(response.length > 0){
                        for(var i=0;i<response.length;i++){
                            if(response[i].collected==1){
                                badge = '<span class="badge badge-success badge-pill">been Collected</span>';
                            }else{
                                badge = '<span class="badge badge-danger badge-pill">not been Collected</span>';
                            }
                            template = `
                        <div class="tab-content">
                                <div class="tab-pane show active" id="tab-all" role="tabpanel" aria-labelledby="tab-all">
                                    <div class="card">
                                        <ul class="list-group list-group-flush">
                                            <li class="list-group-item py-4 px-4">
                                                <a href="javascript:void(0)" class="fs-lg fw-500">${response[i].index_number} - ${response[i].stud_name}</a>
                                                <div class="fs-xs mt-1">
                                                   
                                                    <a href="certificates/${response[i].picture}" class="text-success"><?php echo $parse['scheme'].'://'.$parse['host'].'/certificate_ms/certificates/${response[i].picture}'; ?></a>
                                                </div>
                                                <div class="mt-2">
                                                    <span class="text-muted"> ${response[i].date_created}</span> - This certificate was added by ${response[i].name} on ${response[i].date_created} and certificate has ${badge} 
                                                </div>
                                                <div class="d-flex flex-row mt-3">
                                                    <img src="certificates/${response[i].picture}" class="img img-responsive" style="width:200px;height:auto" alt="">
                                                </div>

                                                <div class="d-flex flex-row mt-3">
                                                <button type="button" id="fake${response[i].cert_id}" class="d-block btn btn-lg btn-danger mr-3">
                                                    <span class="fal  fa-times mr-1"></span>
                                                    Fake
                                                </button>
                                                <button type="button" id="valid${response[i].cert_id}" class="d-block btn btn-lg btn-success">
                                                    <span class="fal  fa-check mr-1"></span>
                                                    Valid
                                                </button>
                                                </div>
                                            </li>
                                           
                                        </ul>
                                    </div>
                                </div>
                             `;
                            $('.results').removeClass('d-none');
                            $('.results').append(template);

                            if(i<response.length){
                            $('body').on('click',`#valid${response[i].cert_id}`,function(){
                            $(this).attr('disabled','disabled');
                            
                            var string_id = $(this)[0].id;
                            var get_id = string_id.split("valid");
                            $('#fake'+id).attr('disabled','disabled');
                            var id = get_id[1];
                            var serverData  = {
                                cert_id:id,
                                user_id:'<?php echo $_SESSION['user_id'] ?>',
                                valid:1,
                                set_verification_by_name:''
                            };
                            $.post('controller/certificate_code.php',serverData,function(serverRes){
                                var serverResponse = JSON.parse(serverRes);
                                if(serverResponse.message=="success"){
                                    Swal.fire(
                                {
                                    type: "success",
                                    title: "Verification History Set to Valid",
                                    showConfirmButton: false,
                                    timer: 2500
                                });
                                }else{
                                    Swal.fire(
                                {
                                    type: "warning",
                                    title: "!Oops, something went wrong.",
                                    showConfirmButton: false,
                                    timer: 2500
                                });
                                }
                               
                            });
                        });

                        $('body').on('click',`#fake${response[i].cert_id}`,function(){
                            $(this).attr('disabled','disabled');
                            var string_id = $(this)[0].id;
                            var get_id = string_id.split("fake");
                            var id = get_id[1];
                            $('#valid'+id).attr('disabled','disabled');
                            var serverData  = {
                                cert_id:id,
                                valid:0,
                                user_id:'<?php echo $_SESSION['user_id'] ?>',
                                set_verification_by_name:''
                            };
                            $.post('controller/certificate_code.php',serverData,function(serverRes){
                                var serverResponse = JSON.parse(serverRes);
                                if(serverResponse.message=="success"){
                                    Swal.fire(
                                {
                                    type: "warning",
                                    title: "Verification History Set to Fake",
                                    showConfirmButton: false,
                                    timer: 2500
                                });
                                }else{
                                    Swal.fire(
                                {
                                    type: "warning",
                                    title: "!Oops, something went wrong.",
                                    showConfirmButton: false,
                                    timer: 2500
                                });
                                }
                            });
                        }); 
                            }
                        
                        }
                        $('.info').removeClass('d-none');
                        $('#count').html(response.length);
                        $('#term').html(name);

                        
                    }else{
                        $('.info').removeClass('d-none');
                        $('#count').html('0');
                        $('#term').html(name);
                        $('.results').removeClass('d-none');
                        template = `
                        <div class="tab-content">
                                <div class="tab-pane show active" id="tab-all" role="tabpanel" aria-labelledby="tab-all">
                                    <div class="card">
                                        <ul class="list-group list-group-flush">
                                            <li class="list-group-item py-4 px-4">
                                                <a href="javascript:void(0)" class="fs-lg fw-500">No Records Found!</a>
                                               
                                                   
                                                   
                                                </div>
                                            </li>
                                           
                                        </ul>
                                    </div>
                                </div>
                             `;
                            $('.results').html(template);
                    }
                    console.log(response);
                });
               });

               $('#by_serial').click(function(){
                var template = '';
                var serial = $('#search_term').val();
                var serverData = {
                    by_serial:serial
                };
                $('.results').addClass('d-none');
                $('.results').html('');

                $.get('controller/certificate_code.php',serverData,function(res){
                    var response = JSON.parse(res);
                    
                    var badge = '';
                    if(response.length > 0){
                        for(var i=0;i<response.length;i++){
                            if(response[i].collected==1){
                                badge = '<span class="badge badge-success badge-pill">been Collected</span>';
                            }else{
                                badge = '<span class="badge badge-danger badge-pill">not been Collected</span>';
                            }
                            template = `
                        <div class="tab-content">
                                <div class="tab-pane show active" id="tab-all" role="tabpanel" aria-labelledby="tab-all">
                                    <div class="card">
                                        <ul class="list-group list-group-flush">
                                            <li class="list-group-item py-4 px-4">
                                                <a href="javascript:void(0)" class="fs-lg fw-500">${response[i].index_number} - ${response[i].stud_name}</a>
                                                <div class="fs-xs mt-1">
                                                   
                                                    <a href="certificates/${response[i].picture}" class="text-success"><?php echo $parse['scheme'].'://'.$parse['host'].'/certificate_ms/certificates/${response[i].picture}'; ?></a>
                                                </div>
                                                <div class="mt-2">
                                                    <span class="text-muted"> ${response[i].date_created}</span> - This certificate was added by ${response[i].name} on ${response[i].date_created} and certificate has ${badge} 
                                                </div>
                                                <div class="d-flex flex-row mt-3">
                                                    <img src="certificates/${response[i].picture}" class="img img-responsive" style="width:200px;height:auto" alt="">
                                                </div>

                                                <div class="d-flex flex-row mt-3">
                                                <button type="button" id="fake${response[i].cert_id}" class="d-block btn btn-lg btn-danger mr-3">
                                                    <span class="fal  fa-times mr-1"></span>
                                                    Fake
                                                </button>
                                                <button type="button" id="valid${response[i].cert_id}" class="d-block btn btn-lg btn-success">
                                                    <span class="fal  fa-check mr-1"></span>
                                                    Valid
                                                </button>
                                                </div>
                                            </li>
                                           
                                        </ul>
                                    </div>
                                </div>
                             `;
                            $('.results').removeClass('d-none');
                            $('.results').append(template);

                            if(i<response.length){
                            $('body').on('click',`#valid${response[i].cert_id}`,function(){
                            $(this).attr('disabled','disabled');
                            
                            var string_id = $(this)[0].id;
                            var get_id = string_id.split("valid");
                            $('#fake'+id).attr('disabled','disabled');
                            var id = get_id[1];
                            var serverData  = {
                                cert_id:id,
                                user_id:'<?php echo $_SESSION['user_id'] ?>',
                                valid:1,
                                set_verification_by_serial:''
                            };
                            $.post('controller/certificate_code.php',serverData,function(serverRes){
                                var serverResponse = JSON.parse(serverRes);
                                if(serverResponse.message=="success"){
                                    Swal.fire(
                                {
                                    type: "success",
                                    title: "Verification History Set to Valid",
                                    showConfirmButton: false,
                                    timer: 2500
                                });
                                }else{
                                    Swal.fire(
                                {
                                    type: "warning",
                                    title: "!Oops, something went wrong.",
                                    showConfirmButton: false,
                                    timer: 2500
                                });
                                }
                               
                            });
                        });

                        $('body').on('click',`#fake${response[i].cert_id}`,function(){
                            $(this).attr('disabled','disabled');
                            var string_id = $(this)[0].id;
                            var get_id = string_id.split("fake");
                            var id = get_id[1];
                            $('#valid'+id).attr('disabled','disabled');
                            var serverData  = {
                                cert_id:id,
                                valid:0,
                                user_id:'<?php echo $_SESSION['user_id'] ?>',
                                set_verification_by_serial:''
                            };
                            $.post('controller/certificate_code.php',serverData,function(serverRes){
                                var serverResponse = JSON.parse(serverRes);
                                if(serverResponse.message=="success"){
                                    Swal.fire(
                                {
                                    type: "warning",
                                    title: "Verification History Set to Fake",
                                    showConfirmButton: false,
                                    timer: 2500
                                });
                                }else{
                                    Swal.fire(
                                {
                                    type: "warning",
                                    title: "!Oops, something went wrong.",
                                    showConfirmButton: false,
                                    timer: 2500
                                });
                                }
                            });
                        }); 
                            }
                        
                        }
                        $('.info').removeClass('d-none');
                        $('#count').html(response.length);
                        $('#term').html(serial);

                        
                    }else{
                        $('.info').removeClass('d-none');
                        $('#count').html('0');
                        $('#term').html(serial);
                        $('.results').removeClass('d-none');
                        template = `
                        <div class="tab-content">
                                <div class="tab-pane show active" id="tab-all" role="tabpanel" aria-labelledby="tab-all">
                                    <div class="card">
                                        <ul class="list-group list-group-flush">
                                            <li class="list-group-item py-4 px-4">
                                                <a href="javascript:void(0)" class="fs-lg fw-500">No Records Found!</a>
                                               
                                                   
                                                   
                                                </div>
                                            </li>
                                           
                                        </ul>
                                    </div>
                                </div>
                             `;
                            $('.results').html(template);
                    }
                    console.log(response);
                });
               });

               

            });

        </script>
    </body>

</html>
