<?php
if(!isset($_SESSION['user_id'])){
    header("Location:index.php");
    session_start();
}

?>
<meta charset="utf-8">
        <title>
            AAMUSTED CMS
        </title>
        <meta name="description" content="AltEditor (beta)">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, user-scalable=no, minimal-ui">
        <!-- Call App Mode on ios devices -->
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <!-- Remove Tap Highlight on Windows Phone IE -->
        <meta name="msapplication-tap-highlight" content="no">