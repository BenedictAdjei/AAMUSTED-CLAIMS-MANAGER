<footer class="page-footer" role="contentinfo">
                        <div class="d-flex align-items-center flex-1 text-muted">
                            <span class="hidden-md-down fw-700 text-center">&copy; 2022 AAMUSTED CLaims Management System All Rights Reserved</span>
                        </div>
                       
</footer>
