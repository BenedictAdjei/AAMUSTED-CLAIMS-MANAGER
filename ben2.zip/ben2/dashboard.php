
<!DOCTYPE html>

<html lang="en">
    
<head>
        <?php include 'controller/php_inc/setup_inc_code.php' ?>
        <?php include 'inc/meta_inc.php' ?>
        <!-- base css -->
        <?php include 'inc/styles_inc.php' ?>
        <link rel="stylesheet" media="screen, print" href="css/statistics/chartist/chartist.css">
<style>
.select2-selection__rendered {
    line-height: 32px !important;
}
.select2-container .select2-selection--single {
    height: 39px !important;
}
.select2-selection__arrow {
    height: 35px !important;
}
</style>
</head>
    <body class="mod-bg-1 ">
        <!-- DOC: script to save and load page settings -->
        <script>
    
            /**
             *	This script should be placed right after the body tag for fast execution 
            *	Note: the script is written in pure javascript and does not depend on thirdparty library
            **/
            'use strict';

            var classHolder = document.getElementsByTagName("BODY")[0],
                /** 
                 * Load from localstorage
                 **/
                themeSettings = (localStorage.getItem('themeSettings')) ? JSON.parse(localStorage.getItem('themeSettings')) :
                {},
                themeURL = themeSettings.themeURL || '',
                themeOptions = themeSettings.themeOptions || '';
            /** 
             * Load theme options
             **/
            if (themeSettings.themeOptions)
            {
                classHolder.className = themeSettings.themeOptions;
                console.log("%c✔ Theme settings loaded", "color: #148f32");
            }
            else
            {
                console.log("Heads up! Theme settings is empty or does not exist, loading default settings...");
            }
            if (themeSettings.themeURL && !document.getElementById('mytheme'))
            {
                var cssfile = document.createElement('link');
                cssfile.id = 'mytheme';
                cssfile.rel = 'stylesheet';
                cssfile.href = themeURL;
                document.getElementsByTagName('head')[0].appendChild(cssfile);
            }
            /** 
             * Save to localstorage 
             **/
            var saveSettings = function()
            {
                themeSettings.themeOptions = String(classHolder.className).split(/[^\w-]+/).filter(function(item)
                {
                    return /^(nav|header|mod|display)-/i.test(item);
                }).join(' ');
                if (document.getElementById('mytheme'))
                {
                    themeSettings.themeURL = document.getElementById('mytheme').getAttribute("href");
                };
                localStorage.setItem('themeSettings', JSON.stringify(themeSettings));
            }
            /** 
             * Reset settings
             **/
            var resetSettings = function()
            {
                localStorage.setItem("themeSettings", "");
            }

        </script>
        <!-- BEGIN Page Wrapper -->
        <div class="page-wrapper">
            <div class="page-inner">
                <!-- BEGIN Left Aside -->
                <?php include 'inc/aside_inc.php' ?>
                <!-- END Left Aside -->
                <div class="page-content-wrapper">
                    <!-- BEGIN Page Header -->
                    <?php include 'inc/header_inc.php' ?>    
                    <!-- END Page Header -->
                    <!-- BEGIN Page Content -->
                    <!-- the #js-page-content id is needed for some plugins to initialize -->
                    <main id="js-page-content" role="main" class="page-content">
                        <ol class="breadcrumb page-breadcrumb"> 
                            <li class="breadcrumb-item"><a href="javascript:void(0);">Admin</a></li>
                            <li class="breadcrumb-item">Dashboard</li>
                            <li class="position-absolute pos-top pos-right d-none d-sm-block"><span class="js-get-date"></span></li>
                        </ol>
                        <div class="subheader">
                            <h1 class="subheader-title">
                                Dashboard <span class='fw-300'></span> 
                                
                            </h1>
                        </div>
                        <h6 class="text-center"style="text-transform: uppercase;">Excess Scripts Claim Count</h6>
                        <div class="row">
                            <div class="col-sm-3">
                                <div class="p-3 bg-primary rounded overflow-hidden position-relative text-white mb-g">
                                    <div class="">
                                        <h3 class="display-4 d-block l-h-n m-0 fw-500">
                                            <?php echo $count_all_excess_marking_claim ?>
                                            <small class="m-0 l-h-n">Total Number Of Claims Made</small>
                                        </h3>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-3">
                                <div class="p-3 bg-success rounded overflow-hidden position-relative text-white mb-g">
                                    <div class="">
                                        <h3 class="display-4 d-block l-h-n m-0 fw-500">
                                        <?php echo $count_approved_excess_marking_claim ?>
                                            <small class="m-0 l-h-n">Total Number Of Approved Claims</small>
                                        </h3>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-3">
                                <div class="p-3 bg-warning rounded overflow-hidden position-relative text-white mb-g">
                                    <div class="">
                                        <h3 class="display-4 d-block l-h-n m-0 fw-500">
                                        <?php echo $count_pending_excess_marking_claim ?>
                                            <small class="m-0 l-h-n">Total Number Of Claims Pending Approval</small>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="p-3 bg-danger rounded overflow-hidden position-relative text-white mb-g">
                                    <div class="">
                                        <h3 class="display-4 d-block l-h-n m-0 fw-500">
                                        <?php echo $count_denied_excess_marking_claim ?>
                                            <small class="m-0 l-h-n">Total Number Of Denied Claims</small>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr></hr>
                        <h6 class="text-center" style="text-transform: uppercase;">Internal Supervision/Examination Claim Count</h6>
                        <div class="row">
                            <div class="col-sm-3">
                                <div class="p-3 bg-primary rounded overflow-hidden position-relative text-white mb-g">
                                    <div class="">
                                        <h3 class="display-4 d-block l-h-n m-0 fw-500">
                                            <?php echo $count_all_internal_sup_claim ?>
                                            <small class="m-0 l-h-n">Total Number Of Claims Made</small>
                                        </h3>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-3">
                                <div class="p-3 bg-success rounded overflow-hidden position-relative text-white mb-g">
                                    <div class="">
                                        <h3 class="display-4 d-block l-h-n m-0 fw-500">
                                        <?php echo $count_approved_internal_sup_claim ?>
                                            <small class="m-0 l-h-n">Total Number Of Approved Claims</small>
                                        </h3>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-3">
                                <div class="p-3 bg-warning rounded overflow-hidden position-relative text-white mb-g">
                                    <div class="">
                                        <h3 class="display-4 d-block l-h-n m-0 fw-500">
                                        <?php echo $count_pending_internal_sup_claim ?>
                                            <small class="m-0 l-h-n">Total Number Of Claims Pending Approval</small>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="p-3 bg-danger rounded overflow-hidden position-relative text-white mb-g">
                                    <div class="">
                                        <h3 class="display-4 d-block l-h-n m-0 fw-500">
                                        <?php echo $count_denied_internal_sup_claim ?>
                                            <small class="m-0 l-h-n">Total Number Of Denied Claims</small>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                    <div id="panel-13" class="panel">
                                        <div class="panel-hdr bg-primary-700 bg-success-gradient">
                                            <h2>
                                                Online <span class="fw-300"><i>Users (Max 6,remaining = ...)</i></span>
                                            </h2>
                                            <div class="panel-toolbar">
                                                
                                            </div>
                                        </div>
                                        <div class="panel-container show">
                                            <div class="panel-content">
                                        <div class="row row-grid no-gutters">
                                                        <?php $i = 0; ?>
                                                    <?php foreach($online_users as $online): ?>
                                                        <?php
                                                        $role_name = $user->read_role($online['role_id']);
                                                        ?>
                                                        <?php if($i<6): ?>
                                                            <div class="col-4">
                                                        <a href="javascript:void(0);" class="text-center p-3 d-flex flex-column hover-highlight">
                                                            <span class="profile-image rounded-circle d-block m-auto" style="background-image:url('img/demo/avatars/avatar-m.png'); background-size: cover;"></span>
                                                            <strong><span style="font-weight:bolder" class="d-block text-truncate text-muted fs-xs mt-1"><?php echo $online['name'] ?></span></strong>
                                                            <span class="d-block text-truncate text-muted fs-xs mt-1"><?php echo $role_name[0]['role_name'] ?></span>
                                                        </a>
                                                    </div>
                                                        <?php else: ?>
                                                            ...
                                                        <?php endif ?>
                                                    
                                                    <?php $i++; ?>
                                                    <?php endforeach ?>
                                                </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <?php if($_SESSION['role_id']==1): ?>
                            <div class="col-md-6">
                            <div id="panel-13" class="panel">
                                <div class="panel-hdr bg-primary-700 bg-success-gradient">
                                    <h2>
                                    Manage <span class="fw-300"><i>Database</i></span>
                                    </h2>
                                </div>
                                <div class="panel-container show">
                                    <div class="panel-content"> 
                                       
                                        <div class="form-group">
                                            <div class="input-group">
                                                
                                            <button type="button" id="backup_db" class="btn btn-lg btn-success">
                                            <span class="fal fa-download mr-1"></span>
                                            Backup DB
                                        </button> 
                                            </div>
                                        </div> 
                                           
                                        <div class="form-group">
                                            <div class="input-group">
                                                <select class="custom-select" id="backup_name" aria-label="usertype">
                                                    <option value="" selected="">Select Database Backup File</option>
                                                    <?php foreach($all_backups as $backup): ?>
                                                        <option value="<?php echo $backup['backup'] ?>"><?php echo $backup['backup'] ?></option>
                                                    <?php endforeach ?>
                                                </select>
                                                <div class="input-group-append">
                                                    <button type="button" id="restore_db" class="btn btn-info shadow-0"> Restore Database</button>    
                                                </div>
                                                
                                            </div>
                                        </div>   
                                    </div>
                                </div>
                                </div>                        
                            </div>
                            <?php endif ?>
                        </div>                       
                    </main>
                    <!-- this overlay is activated only when mobile menu is triggered -->
                    <div class="page-content-overlay" data-action="toggle" data-class="mobile-nav-on"></div> <!-- END Page Content -->
                    <!-- BEGIN Page Footer -->
                <?php include 'inc/footer_inc.php' ?>
                    
      
        <script src="js/vendors.bundle.js"></script>
        <script src="js/app.bundle.js"></script>
       
        <script src="js/statistics/chartist/chartist.js"></script>
        <script src="js/datagrid/datatables/datatables2.bundle.js"></script>
        <script src="js/notifications/sweetalert2/sweetalert2.bundle.js"></script>
        <script src="js/select2.bundle.js"></script>
        <script>
            $(document).ready(function()
            {
                
                $('#backup_name').select2({});      

                

                $('#backup_db').click(function(){
                    var serverData = {
                        backup:''
                    }
                    $.get('backupdb.php',serverData,function(res){
                        var response = JSON.parse(res);
                        if(response.message == "success"){
                            Swal.fire(
                                {
                                    type: "success",
                                    title: "Database Backup Successful",
                                    showConfirmButton: false,
                                    timer: 2500
                                });
                        }else{
                            Swal.fire(
                                {
                                    type: "warning",
                                    title: "Database Backup Failed",
                                    showConfirmButton: false,
                                    timer: 2500
                                });
                        }

                    });
                });

                $('#restore_db').click(function(){
                    $('#restore_db').text('Restoring ...');
                    $('#restore_db').attr('disabled','disabled');
                    var backup_name = $('#backup_name').val();
                    var serverData = {
                        backup_name:backup_name,
                        restore_db:''
                    }
                    $.post('backupdb.php',serverData,function(res){
                        console.log(res);
                        var response = JSON.parse(res);
                        if(response.message == "success"){
                            Swal.fire(
                                {
                                    type: "success",
                                    title: "Database Backup Successful",
                                    showConfirmButton: false,
                                    timer: 2500
                                });
                                $('#restore_db').text('Restore Database');
                                $('#restore_db').removeAttr('disabled');
                        }else{
                            Swal.fire(
                                {
                                    type: "warning",
                                    title: "Database Backup Failed",
                                    showConfirmButton: false,
                                    timer: 2500
                                });
                                $('#restore_db').text('Restore Database');
                                $('#restore_db').removeAttr('disabled');
                        }

                    });
                });
            });
   
        </script>
    </body>

</html>
