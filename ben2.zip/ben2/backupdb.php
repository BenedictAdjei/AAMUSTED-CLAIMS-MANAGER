<?php
include_once 'Config/Database.php';
class DatabaseBackUp
{
	
	public $conn;
	
	function __construct()
	{
		$this->conn = Database::connect();
	}

    public function backup(array $data){
		$sql = "INSERT INTO backup ";
		$fields = array_keys($data);
		$vals = array_values($data);

		$sql .= "(".implode(",", $fields).")";
		$arr = array();
		foreach ($fields as $f) {
			$arr[] = "?";
		}
		$sql .= " VALUES(".implode(",", $arr).")";

		$statement = $this->conn->prepare($sql);

		foreach ($vals as $i => $v) {
			$statement->bindValue($i + 1, $v);
		}

		return $statement->execute();

    }

    public function DROP_DB(){
		$sql = "DROP DATABASE certificate_ms";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
    }

    public function CREATE_DB(){
		$sql = "CREATE DATABASE certificate_ms";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
    }

    


}



$dbBackup = new DatabaseBackUp();

if(isset($_GET['backup'])){
include_once(dirname(__FILE__) . '/Ifsnop/Mysqldump/Mysqldump.php');
$dump = new Ifsnop\Mysqldump\Mysqldump('mysql:host=localhost;dbname=certificate_ms', 'root', '');
$date = new DateTime("NOW");
$db_name = date_format($date, '\o\n l jS F Y');
$db_name .= ' '.microtime();
$db_name .= ' Back Up.sql';
$tb_data = array("backup"=>$db_name);
    $dbResponse = $dbBackup->backup($tb_data);
    if($dbResponse){
        echo json_encode(
            array("message"=>"success")
        );
    }else{
        echo json_encode(
            array("message"=>"fail")
        );
    }
$dump->start('storage/'.$db_name);

}

if(isset($_POST['restore_db'])){
    if($_POST['backup_name']){
    $dir = 'storage/';
    $file_name = $_POST['backup_name'];
    $filename = $dir.$file_name;
    $dbBackup->DROP_DB();
    $dbBackup->CREATE_DB();

    $server  =  'localhost'; 
    $username   = 'root'; 
    $password   = '';  
    $database = 'certificate_ms';

    /* PDO connection start */
    $conn = new PDO("mysql:host=$server; dbname=$database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);         
    $conn->exec("SET CHARACTER SET utf8");     
   
    // Temporary variable, used to store current query
$templine = '';
// Read in entire file

$lines = file($filename);
// Loop through each line
foreach ($lines as $line)
{
// Skip it if it's a comment
if (substr($line, 0, 2) == '--' || $line == '')
    continue;

// Add this line to the current segment
$templine .= $line;
// If it has a semicolon at the end, it's the end of the query
if (substr(trim($line), -1, 1) == ';')
{
    $statement = $conn->prepare($templine);
    $statement->execute();
    $templine = '';
}
}
echo json_encode(
    array("message"=>"success")
);
    }else{
        echo json_encode(
            array("message"=>"fail")
        );
    }

}
?>

