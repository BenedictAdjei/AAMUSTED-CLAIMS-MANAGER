<!DOCTYPE html>

<html lang="en">
    
<head>
        <?php include 'controller/php_inc/setup_inc_code.php' ?>
        <?php include 'inc/meta_inc.php' ?>
        <!-- base css -->
        <?php include 'inc/styles_inc.php' ?>
</head>
    <body class="mod-bg-1 ">
        <!-- DOC: script to save and load page settings -->
        <script>
    
            /**
             *	This script should be placed right after the body tag for fast execution 
            *	Note: the script is written in pure javascript and does not depend on thirdparty library
            **/
            'use strict';

            var classHolder = document.getElementsByTagName("BODY")[0],
                /** 
                 * Load from localstorage
                 **/
                themeSettings = (localStorage.getItem('themeSettings')) ? JSON.parse(localStorage.getItem('themeSettings')) :
                {},
                themeURL = themeSettings.themeURL || '',
                themeOptions = themeSettings.themeOptions || '';
            /** 
             * Load theme options
             **/
            if (themeSettings.themeOptions)
            {
                classHolder.className = themeSettings.themeOptions;
                console.log("%c✔ Theme settings loaded", "color: #148f32");
            }
            else
            {
                console.log("Heads up! Theme settings is empty or does not exist, loading default settings...");
            }
            if (themeSettings.themeURL && !document.getElementById('mytheme'))
            {
                var cssfile = document.createElement('link');
                cssfile.id = 'mytheme';
                cssfile.rel = 'stylesheet';
                cssfile.href = themeURL;
                document.getElementsByTagName('head')[0].appendChild(cssfile);
            }
            /** 
             * Save to localstorage 
             **/
            var saveSettings = function()
            {
                themeSettings.themeOptions = String(classHolder.className).split(/[^\w-]+/).filter(function(item)
                {
                    return /^(nav|header|mod|display)-/i.test(item);
                }).join(' ');
                if (document.getElementById('mytheme'))
                {
                    themeSettings.themeURL = document.getElementById('mytheme').getAttribute("href");
                };
                localStorage.setItem('themeSettings', JSON.stringify(themeSettings));
            }
            /** 
             * Reset settings
             **/
            var resetSettings = function()
            {
                localStorage.setItem("themeSettings", "");
            }

        </script>
        <!-- BEGIN Page Wrapper -->
        <div class="page-wrapper">
            <div class="page-inner">
                <!-- BEGIN Left Aside -->
                <?php include 'inc/aside_inc.php' ?>
                <!-- END Left Aside -->
                <div class="page-content-wrapper">
                    <!-- BEGIN Page Header -->
                    <?php include 'inc/header_inc.php' ?>    
                    <!-- END Page Header -->
                    <!-- BEGIN Page Content -->
                    <!-- the #js-page-content id is needed for some plugins to initialize -->
                    <main id="js-page-content" role="main" class="page-content">
                        <ol class="breadcrumb page-breadcrumb"> 
                            <li class="breadcrumb-item"><a href="javascript:void(0);">FlairTech Admin</a></li>
                            <li class="breadcrumb-item">Student</li>
                            <li class="position-absolute pos-top pos-right d-none d-sm-block"><span class="js-get-date"></span></li>
                        </ol>
                        <div class="subheader">
                            <h1 class="subheader-title">
                                <i class='subheader-icon fal fa-table'></i> Student Setup <span class='fw-300'></span> 
                                
                            </h1>
                        </div>
                        <div class="alert alert-primary">
                            <div class="d-flex flex-start w-100">
                                <div class="mr-2 hidden-md-down">
                                    <span class="icon-stack icon-stack-lg">
                                        <i class="base base-2 icon-stack-3x opacity-100 color-primary-500"></i>
                                        <i class="base base-2 icon-stack-2x opacity-100 color-primary-300"></i>
                                        <i class="fal fa-info icon-stack-1x opacity-100 color-white"></i>
                                    </span>
                                </div>
                                <div class="d-flex flex-fill">
                                    <div class="flex-fill">
                                        <span class="h5">Import bulk students from CSV file. <span style="color:darkred">Note:</spna> When import is finished, click on the <i class="fal fa-sync mr-1"></i> Refresh button to refresh the table</span>
                                        <div class="row">
                                        <div class="col-xl-4"></div>
                                        <div class="col-xl-4">
                                        <input class="form-control" accept=".csv" type="file" name="import_students" id="import_students" /> 
                                        
                                        </div>
                                        <div class="col-xl-4"><button class="btn-success btn-sm mr-1" id="import_file">Import Students</button></div>
                                        </div>
                                                                                            
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-xl-12">
                                <div id="panel-1" class="panel">
                                    <div class="panel-hdr">
                                        <h2>
                                        Manage Student
                                        </h2>
                                        
                                        
                                    </div>
                                    <div class="panel-container show">
                                        <div class="panel-content">
                                        
                                            
                                        <div class="row">
                                                <div class="col-xl-12">
                                                    <!-- datatable start -->
                                                    <table id="dt-basic-example" class="table table-bordered table-hover table-striped w-100"></table>
                                                    <!-- datatable end -->
                                                </div>
                                            
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </main>
                    <!-- this overlay is activated only when mobile menu is triggered -->
                    <div class="page-content-overlay" data-action="toggle" data-class="mobile-nav-on"></div> <!-- END Page Content -->
                    <!-- BEGIN Page Footer -->
                <?php include 'inc/footer_inc.php' ?>
                    
        <!-- END Page Settings -->
        
        <!-- base vendor bundle: 
            DOC: if you remove pace.js from core please note on Internet Explorer some CSS animations may execute before a page is fully loaded, resulting 'jump' animations 
                        + pace.js (recommended)
                        + jquery.js (core)
                        + jquery-ui-cust.js (core)
                        + popper.js (core)
                        + bootstrap.js (core)
                        + slimscroll.js (extension)
                        + app.navigation.js (core)
                        + ba-throttle-debounce.js (core)
                        + waves.js (extension)
                        + FlairTech panels.js (extension)
                        + src/../jquery-snippets.js (core) -->
        <script src="js/vendors.bundle.js"></script>
        <script src="js/app.bundle.js"></script>
        <!-- datatble responsive bundle contains: 
    + jquery.dataTables.js
    + dataTables.bootstrap4.js
    + dataTables.autofill.js							
    + dataTables.buttons.js
    + buttons.bootstrap4.js
    + buttons.html5.js
    + buttons.print.js
    + buttons.colVis.js
    + dataTables.colreorder.js							
    + dataTables.fixedcolumns.js							
    + dataTables.fixedheader.js						
    + dataTables.keytable.js						
    + dataTables.responsive.js							
    + dataTables.rowgroup.js							
    + dataTables.rowreorder.js							
    + dataTables.scroller.js							
    + dataTables.select.js							
    + datatables.styles.app.js
    + datatables.styles.buttons.app.js -->
        <script src="js/datagrid/datatables/datatables2.bundle.js"></script>
        <script src="js/notifications/sweetalert2/sweetalert2.bundle.js"></script>
        <script>
            $(document).ready(function()
            {
                
                /* 
                NOTES:
                    
                    Column id
                    ---------------------------------------------------
                    Please always keep in mind that DataTable framework allows two different kinds of "rows": Arrays and Objects. In first case columns are indexed through integers; in second case columns are indexed by their attribute name. Usually JSON's use the Object approach, but we cannot be sure.


                    Row key
                    ---------------------------------------------------
                    There is no default key in the table. Inside your callback functions, probably you will need a row key to build URL's, in that case you can get them from the rowdata parameter.


                COLUMN DEFINITIONS:

                    title = "string" - title name on table header th and on form labels
                    ---------------------------------------------------
                    id = "string" - id assigned to imput element when editing/adding in modal
                    ---------------------------------------------------
                    data = "string"  - data name from the dataset
                    ---------------------------------------------------
                    type = "text" | "select" | "hidden" | "readonly"  - Type of HTML input to be shown.
                    ---------------------------------------------------
                    hoverMsg = "some msg" - The message will appear as a tooltip over the input field.
                    ---------------------------------------------------
                    pattern = r.e.  - If type is "input", the typed text will be matched against given regular expression, before submit.
                    ---------------------------------------------------
                    msg = "some string" - An error message that is displayed in case pattern is not matched. Set HTML "data-errorMsg" attribute.
                    ---------------------------------------------------
                    maxLength = integer - If type is "input", set HTML "maxlength" attribute.
                    ---------------------------------------------------
                    options = ["a", "b", "c"] - If type is "select", the options that shall be presented.
                    ---------------------------------------------------
                    select2 = {} - If type is "select", enable a select2 component. Select2 jQuery plugin must be linked. More select2 configuration options may be passed within the array.
                    ---------------------------------------------------
                    datepicker = {} - If type is "text", enable a datepicker component. jQuery-UI plugin must be linked. More datepicker configuration options may be passed within the array.
                    ---------------------------------------------------
                    multiple = true | false - Set HTML "multiple" attribute (for use with select2).
                    ---------------------------------------------------
                    unique = true | false - Ensure that no two rows have the same value. The check is performed client side, not server side. Set HTML "data-unique" attribute. (Probably there's some issue with this).
                    ---------------------------------------------------
                    uniqueMsg = "some string" - An error message that is displayed when the unique constraint is not respected. Set HTML "data-uniqueMsg" attribute.
                    ---------------------------------------------------
                    special = "any string" - Set HTML "data-special" attribute (don't know what's that needed for).
                    ---------------------------------------------------
                    defaultValue = "any string" - Adds a default value when adding a row
                    ---------------------------------------------------
                */


                // Event Lot
                var events = $("#app-eventlog");
                var departments = [<?php echo $all_departments ?>];
                var faculties = [<?php echo $all_faculties ?>];
                var academic_years = [<?php echo $all_academic_years ?>];
                var roles = [<?php echo $all_roles ?>];
                // Column Definitions
                var columnSet = [
                {
                    title: "RowId",
                    id: "stud_id",
                    data: "stud_id",
                    placeholderMsg: "Server Generated ID",
                    "visible": false,
                    "searchable": false,
                    type: "hidden"
                },    
                {
                    title: "Staff ID",
                    id: "staff_id",
                    data: "staff_id",
                    placeholderMsg: "Staff ID",
                    type: "text",
                    unique: true,
                    uniqueMsg: 'Staff ID already exist'
                },
                {
                    title: "Name",
                    id: "name",
                    data: "name",
                    placeholderMsg: "Name",
                    type: "text",
                    unique: false
                },
                {
                    title: "Username",
                    id: "user_name",
                    data: "user_name",
                    placeholderMsg: "Username",
                    type: "text",
                    unique: true,
                    uniqueMsg:"Username already Exist"
                    
                },
                {
                    title: "Password",
                    id: "user_password",
                    data: "user_password",
                    placeholderMsg: "Password",
                    type: "text",
                    unique: false
                    
                },
                {
                    title: "Academic Year",
                    id: "academic_year",
                    data: "academic_year",
                    placeholderMsg: "Academic Year",
                    type: "select",
                    "options":
                        academic_years
                    
                },
                {
                    title: "Faculty",
                    id: "faculty_name",
                    data: "faculty_name",
                    placeholderMsg: "Faculty",
                    type: "select",
                    "options":
                        faculties
                    
                },
                {
                    title: "Department",
                    id: "dept_name",
                    data: "dept_name",
                    placeholderMsg: "Department",
                    type: "select",
                    "options":
                        departments
                    
                },
                {
                    title: "Role",
                    id: "role_name",
                    data: "role_name",
                    placeholderMsg: "Role",
                    type: "select", 
                    "options":
                        roles
                    
                }
                
                
            ]

                //Get domain
                var BaseUrl = window.location.origin;
                /* start data table */
                var myTable = $('#dt-basic-example').dataTable(
                {
                    /* check datatable buttons page for more info on how this DOM structure works */
                    dom: "<'row mb-3'<'col-sm-12 col-md-6 d-flex align-items-center justify-content-start'f><'col-sm-12 col-md-6 d-flex align-items-center justify-content-end'B>>" +
                        "<'row'<'col-sm-12'tr>>" +
                        "<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
                    ajax: "controller/student_code.php?::=",
                    columns: columnSet,
                    /* selecting multiple rows will not work */
                    select: 'single',
                    /* altEditor at work */
                    altEditor: true,
                    responsive: true,
                    /* buttons uses classes from bootstrap, see buttons page for more details */
                    buttons: [
                    {
                        extend: 'selected',
                        text: '<i class="fal fa-times mr-1"></i> Delete',
                        name: 'delete',
                        className: 'btn-primary btn-sm mr-1'
                    },
                    {
                        extend: 'selected',
                        text: '<i class="fal fa-edit mr-1"></i> Edit',
                        name: 'edit',
                        className: 'btn-primary btn-sm mr-1'
                    },
                    {
                        text: '<i class="fal fa-plus mr-1"></i> Add',
                        name: 'add',
                        className: 'btn-success btn-sm mr-1'
                    },
                    {
                        text: '<i class="fal fa-sync mr-1"></i> Refresh',
                        name: 'refresh',
                        className: 'btn-primary btn-sm'
                    }],
                    columnDefs: [
                    {
                        // targets: 3,
                        // render: function(data, type, full, meta)
                        // {
                        //     return '<img src="../images/user/'+data+'" style="width:300px;height:auto" class="img img-responsive ">';
                            
                        // },
                    }
                    ],
                    /* default callback for insertion: mock webservice, always success */
                    onAddRow: function(dt, rowdata, success, error)
                    {
                        var myFormData = new FormData();
                        myFormData.append('first_name',rowdata.first_name);
                        myFormData.append('middle_name',rowdata.middle_name);
                        myFormData.append('last_name',rowdata.last_name);
                        myFormData.append('academic_year',rowdata.academic_year);
                        myFormData.append('index_number',rowdata.index_number);
                        myFormData.append('faculty_name',rowdata.faculty_name);
                        myFormData.append('dept_name',rowdata.dept_name);
                        myFormData.append('prog_name',rowdata.prog_name);
                        myFormData.append('add_student','');
                        rowdata['stud_id'] = '';
                        success(rowdata);
                        
                        $.ajax({
                            url: 'controller/student_code.php',
                            type: 'POST',
                            processData: false, // important
                            contentType: false, // important
                            dataType : 'json',
                            data: myFormData,
                            beforeSend:function(res){
                            },
                            complete:function(res){
                            },
                            success:function(res){
                                Swal.fire(
                                {
                                    type: "success",
                                    title: "Add Successful",
                                    showConfirmButton: false,
                                    timer: 2500
                                });
                            },
                            error:function(res){
                            console.log(res);
                            }
                        });
                        

                        // demo only below:
                        events.prepend('<p class="text-success fw-500">' + JSON.stringify(rowdata, null, 4) + '</p>');
                    },
                    onEditRow: function(dt, rowdata, success, error)
                    {
                        success(rowdata);
                        var myFormData = new FormData();
                        myFormData.append('stud_id',rowdata.stud_id);
                        myFormData.append('first_name',rowdata.first_name);
                        myFormData.append('middle_name',rowdata.middle_name);
                        myFormData.append('last_name',rowdata.last_name);
                        myFormData.append('academic_year',rowdata.academic_year);
                        myFormData.append('index_number',rowdata.index_number);
                        myFormData.append('faculty_name',rowdata.faculty_name);
                        myFormData.append('dept_name',rowdata.dept_name);
                        myFormData.append('prog_name',rowdata.prog_name);
                        myFormData.append('edit_student','');
                        success(rowdata);
                        
                        $.ajax({
                            url: 'controller/student_code.php',
                            type: 'POST',
                            processData: false, // important
                            contentType: false, // important
                            dataType : 'json',
                            data: myFormData,
                            beforeSend:function(res){
                                // console.log(e);
                            },
                            complete:function(res){
                            },
                            success:function(res){
                                Swal.fire(
                                    {
                                        type: "success",
                                        title: "Edit Successful",
                                        showConfirmButton: false,
                                        timer: 2500
                                    });
                            },
                            error:function(res){
                            console.log(res);
                            }
                        });

                        // demo only below:
                        events.prepend('<p class="text-info fw-500">' + JSON.stringify(rowdata, null, 4) + '</p>');
                    },
                    onDeleteRow: function(dt, rowdata, success, error)
                    {
                        Swal.fire(
                        {
                            type: "success",
                            title: "Delete Successful",
                            showConfirmButton: false,
                            timer: 2500
                        });
                        success(rowdata);
                        console.log(rowdata);
                        var stud_id = rowdata.stud_id;
                        $.post('controller/student_code.php?del_student='+stud_id,function(del_res){
                                    Swal.fire(
                                    {
                                        type: "success",
                                        title: "Delete Successful",
                                        showConfirmButton: false,
                                        timer: 2500
                                    });
                        });
                    

                        // demo only below:
                        events.prepend('<p class="text-danger fw-500">' + JSON.stringify(rowdata, null, 4) + '</p>');
                    },
                });
                
                $('body').on('change','#faculty_name',function(){
                    var thisVery = $(this);
                    var faculty_name = $(this).val();
                    var serverData = {
                        faculty_name:faculty_name,
                        get_falculty_by_name:''
                    };
                    $.get('controller/program_code.php',serverData,function(res){
                        var response = JSON.parse(res);
                        departments = [res];
                        columnSet[3]['options'] = departments;
                        if(response['data'].length==1){
                            for(i=0; i<response['data'].length; i++){
                                $('#dept_name').html(`<option value="${response['data'][i]['dept_name']}">${response['data'][i]['dept_name']}</option>`);
                            }
                            var dept_name = response['data'][0]['dept_name'];
                            serverData = {
                                faculty_name:faculty_name,
                                dept_name:dept_name,
                                get_program_by_name:''
                            };
                            $.get('controller/program_code.php',serverData,function(serverRes){
                                serverRes = JSON.parse(serverRes);
                                if(serverRes['data'].length==1){
                                    for(i=0; i<serverRes['data'].length; i++){
                                        $('#prog_name').html(`<option value="${serverRes['data'][i]['prog_name']}">${serverRes['data'][i]['prog_name']}</option>`);
                                    }
                                }else if(serverRes['data'].length > 1){
                                    if(i==0){
                                    $('#prog_name').html(`<option value="${serverRes['data'][i]['prog_name']}">${serverRes['data'][i]['prog_name']}</option>`);
                                }else{
                                    $('#prog_name').append(`<option value="${serverRes['data'][i]['prog_name']}">${serverRes['data'][i]['prog_name']}</option>`);
                                }
                                }else if(serverRes['data'].length == undefined){
                                    $('#prog_name').html(`<option value="">-- No Program Available --</option>`);
                                }
                                
                            });
                        }else if(response['data'].length > 1){
                            for(i=0; i<response['data'].length; i++){
                                if(i==0){
                                    $('#dept_name').html(`<option value="${response['data'][i]['dept_name']}">${response['data'][i]['dept_name']}</option>`);
                                }else{
                                    $('#dept_name').append(`<option value="${response['data'][i]['dept_name']}">${response['data'][i]['dept_name']}</option>`);
                                }
                            }

                            var dept_name = response['data'][0]['dept_name'];
                            serverData = {
                                faculty_name:faculty_name,
                                dept_name:dept_name,
                                get_program_by_name:''
                            };
                            $.get('controller/program_code.php',serverData,function(serverRes){
                                
                                serverRes = JSON.parse(serverRes);
                                if(serverRes['data'].length==1){
                                    for(i=0; i<serverRes['data'].length; i++){
                                        $('#prog_name').html(`<option value="${serverRes['data'][i]['prog_name']}">${serverRes['data'][i]['prog_name']}</option>`);
                                    }
                                }else if(serverRes['data'].length > 1){
                                    for(i=0; i<serverRes['data'].length; i++){
                                        if(i==0){
                                            $('#prog_name').html(`<option value="${serverRes['data'][i]['prog_name']}">${serverRes['data'][i]['prog_name']}</option>`);
                                        }else{
                                            $('#prog_name').append(`<option value="${serverRes['data'][i]['prog_name']}">${serverRes['data'][i]['prog_name']}</option>`);
                                        }
                                    }
                                    
                                }else if(serverRes['data'].length == undefined){
                                    $('#prog_name').html(`<option value="">-- No Program Available --</option>`);
                                }
                            });
                        }else if(response['data'].length == undefined){
                            $('#dept_name').html(`<option value="">-- No Department Available --</option>`);
                            $('#prog_name').html(`<option value="">-- No Program Available --</option>`);
                        }
                        
                       
                    });
                });

                $('body').on('change','#dept_name',function(){
                    var dept_name = $(this).val();
                    var serverData = {
                        dept_name:dept_name,
                        get_dept_by_name:''
                    };
                    $.get('controller/program_code.php',serverData,function(res){
                        console.log(res);
                        var response = JSON.parse(res);
                        departments = [res];
                        columnSet[3]['options'] = departments;
                        if(response['data'].length==1){
                            for(i=0; i<response['data'].length; i++){
                                $('#prog_name').html(`<option value="${response['data'][i]['prog_name']}">${response['data'][i]['prog_name']}</option>`);
                            }
                        }else if(response['data'].length > 1){
                            for(i=0; i<response['data'].length; i++){
                                if(i==0){
                                    $('#prog_name').html(`<option value="${response['data'][i]['prog_name']}">${response['data'][i]['prog_name']}</option>`);
                                }else{
                                    $('#prog_name').append(`<option value="${response['data'][i]['prog_name']}">${response['data'][i]['prog_name']}</option>`);
                                }
                            }
                        }else if(response['data'].length == undefined){
                            $('#prog_name').html(`<option value="">-- No Department Available --</option>`);
                        }
                        
                       
                    });
                });
                

                $('#import_file').click(function(){
                var myFormData = new FormData();
                myFormData.append('import_students', $('#import_students').prop('files')[0]);
                $.ajax({
                            url: 'controller/student_code.php',
                            type: 'POST',
                            processData: false, // important
                            contentType: false, // important
                            dataType : 'json',
                            data: myFormData,
                            beforeSend:function(res){
                                // console.log(e);
                            },
                            complete:function(res){
                                if( document.getElementById("import_students").files.length == 0 ){
                                    Swal.fire(
                                    {
                                        type: "warning",
                                        title: "No CSV File Selected",
                                        showConfirmButton: false,
                                        timer: 2500
                                    });
                                }else{
                                    Swal.fire(
                                    {
                                        type: "success",
                                        title: "Import Successful",
                                        showConfirmButton: false,
                                        timer: 2500
                                    });
                                    $('#import_students').val('');
                                }
                                
                            },
                            success:function(res){
                                Swal.fire(
                                    {
                                        type: "success",
                                        title: "Import Successful",
                                        showConfirmButton: false,
                                        timer: 2500
                                    });
                                    $('#import_students').val('');
                                    
                            },
                            error:function(res){
                                // Swal.fire(
                                //     {
                                //         type: "success",
                                //         title: "Import Successful",
                                //         showConfirmButton: false,
                                //         timer: 2500
                                //     });
                                //     $('#import_students').val('');
                            }
                        });
                    
            });

            });

            

        </script>
    </body>

</html>
