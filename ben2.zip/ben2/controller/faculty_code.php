<?php
include_once '../Config/Database.php';
require_once '../Model/Faculty.php';
$faculty = new Faculty();

if(isset($_GET['::'])){
    $all_faculties = $faculty->read_all_faculties();
    echo json_encode(
        array("data"=>$all_faculties)
    );
}

if(isset($_POST['add_faculty'])){
    $faculty_name = $_POST['faculty_name'];
    $tb_data = array("faculty_name"=>$faculty_name);
    $db_response = $faculty->add_faculty($tb_data);
    if($db_response){
        echo json_encode(
          array("message"=>"success")
        );
    }
}

if(isset($_POST['edit_faculty'])){
    $faculty_id = $_POST['faculty_id'];
    $faculty_name = $_POST['faculty_name'];
    $tb_data = array("faculty_name"=>$faculty_name);
    $tb_primary_key = array("faculty_id"=>$faculty_id);
    $db_response = $faculty->update_faculty($tb_primary_key,$tb_data);
    if($db_response){
        echo json_encode(
          array("message"=>"success")
        );
    }
}

if(isset($_GET['del_faculty'])){
    $faculty_id = $_GET['del_faculty'];
    $db_response = $faculty->delete_faculty($faculty_id);
    if(is_array($db_response)){
        echo json_encode(
        array("message"=>"success")
        );
    }else if(!$db_response){
        echo json_encode(
            array("message"=>"fail")
            );
    }
}