<?php
include_once '../Config/Database.php';
require_once '../Model/Semester.php';
$semester = new Semester();

if(isset($_GET['::'])){
    $all_semesters = $semester->read_all_semesters();
    echo json_encode(
        array("data"=>$all_semesters)
    );
}

if(isset($_POST['add_semester'])){
    $all_semesters = $semester->read_all_semesters();
    $sem = $_POST['semester'];
    $isset = false;
    foreach($all_semesters as $semesters){
        if($sem == $semesters['semester']){
            $isset = true;
        }
    }
    if(!$isset){
        $tb_data = array("semester"=>$sem);
        $db_response = $semester->add_semester($tb_data);
        if($db_response){
            echo json_encode(
            array("message"=>"success")
            );
        }
    }
    
}

if(isset($_POST['edit_semester'])){
    $semester_id = $_POST['semester_id'];
    $sem = $_POST['semester'];
    $tb_data = array("semester"=>$sem);
    $tb_primary_key = array("semester_id"=>$semester_id);
    $db_response = $semester->update_semester($tb_primary_key,$tb_data);
    if($db_response){
        echo json_encode(
          array("message"=>"success")
        );
    }
}

if(isset($_GET['del_semester'])){
    $semester_id = $_GET['del_semester'];
    $db_response = $semester->delete_semester($semester_id);
    if(is_array($db_response)){
        echo json_encode(
        array("message"=>"success")
        );
    }else if(!$db_response){
        echo json_encode(
            array("message"=>"fail")
            );
    }
    
}