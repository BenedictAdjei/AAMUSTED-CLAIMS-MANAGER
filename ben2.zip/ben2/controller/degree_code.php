<?php
include_once '../Config/Database.php';
require_once '../Model/Degree.php';
$degree = new Degree();

if(isset($_GET['::'])){
    $all_degrees = $degree->read_all_degrees();
    echo json_encode(
        array("data"=>$all_degrees)
    );
}

if(isset($_POST['add_degree'])){
    $all_degrees = $degree->read_all_degrees();
    $degree_ty = $_POST['degree'];
    $isset = false;
    foreach($all_degrees as $degrees){
        if($degree_ty == $degrees['degree']){
            $isset = true;
        }
    }
    if(!$isset){
        $tb_data = array("degree"=>$degree_ty);
        $db_response = $degree->add_degree($tb_data);
        if($db_response){
            echo json_encode(
            array("message"=>"success")
            );
        }
    }
    
}

if(isset($_POST['edit_degree'])){
    $degree_id = $_POST['degree_id'];
    $degree_ty = $_POST['degree'];
    $tb_data = array("degree"=>$degree_ty);
    $tb_primary_key = array("degree_id"=>$degree_id);
    $db_response = $degree->update_degree($tb_primary_key,$tb_data);
    if($db_response){
        echo json_encode(
          array("message"=>"success")
        );
    }
}

if(isset($_GET['del_degree'])){
    $degree_id = $_GET['del_degree'];
    $db_response = $degree->delete_degree($degree_id);
    if(is_array($db_response)){
        echo json_encode(
        array("message"=>"success")
        );
    }else if(!$db_response){
        echo json_encode(
            array("message"=>"fail")
            );
    }
    
}