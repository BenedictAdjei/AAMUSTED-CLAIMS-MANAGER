<?php
include_once '../Config/Database.php';
require_once '../Model/Academic_Year.php';
$academic_year = new Academic_Year();

if(isset($_GET['::'])){
    $all_academic_years = $academic_year->read_all_academic_years();
    echo json_encode(
        array("data"=>$all_academic_years)
    );
}

if(isset($_POST['add_academic_year'])){
    $all_academic_years = $academic_year->read_all_academic_years();
    $academic_yr = $_POST['academic_year'];
    $isset = false;
    foreach($all_academic_years as $academic_years){
        if($academic_yr == $academic_years['academic_year']){
            $isset = true;
        }
    }
    if(!$isset){
        $tb_data = array("academic_year"=>$academic_yr);
        $db_response = $academic_year->add_academic_year($tb_data);
        if($db_response){
            echo json_encode(
            array("message"=>"success")
            );
        }
    }
    
}

if(isset($_POST['edit_academic_year'])){
    $academic_year_id = $_POST['academic_year_id'];
    $academic_yr = $_POST['academic_year'];
    $tb_data = array("academic_year"=>$academic_yr);
    $tb_primary_key = array("academic_year_id"=>$academic_year_id);
    $db_response = $academic_year->update_academic_year($tb_primary_key,$tb_data);
    if($db_response){
        echo json_encode(
          array("message"=>"success")
        );
    }
}

if(isset($_GET['del_academic_year'])){
    $academic_year_id = $_GET['del_academic_year'];
    $db_response = $academic_year->delete_academic_year($academic_year_id);
    if(is_array($db_response)){
        echo json_encode(
        array("message"=>"success")
        );
    }else if(!$db_response){
        echo json_encode(
            array("message"=>"fail")
            );
    }
    
}