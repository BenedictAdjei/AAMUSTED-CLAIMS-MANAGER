<?php
include_once '../Config/Database.php';
require_once '../Model/Program.php';
require_once '../Model/Department.php';
require_once '../Model/Faculty.php';

$department = new Department();
$faculty = new Faculty();
$program = new Program();

if(isset($_GET['::'])){
    $all_programs = $program->read_all_programs();
    echo json_encode(
        array("data"=>$all_programs)
    );
}

if(isset($_GET['get_program_by_name'])){
    $faculty_name = $_GET['faculty_name'];
    $faculty_id = $faculty->get_faculty_by_name($faculty_name);
    $faculty_id = $faculty_id[0]['faculty_id'];
    $dept_name = $_GET['dept_name'];
    $dept_id = $department->get_department_by_name($dept_name);
    $dept_id = $dept_id[0]['dept_id'];
    $programs = $program->read_program_by_both_ids($dept_id,$faculty_id);
    echo json_encode(
        array("data"=>$programs)
    );
}


if(isset($_GET['get_falculty_by_name'])){
    $faculty_name = $_GET['faculty_name'];
    $faculty_id = $faculty->get_faculty_by_name($faculty_name);
    $faculty_id = $faculty_id[0]['faculty_id'];
    $departments_for_faculty = $department->get_department_by_faculty_id($faculty_id);
    echo json_encode(
        array("data"=>$departments_for_faculty)
    );
}

if(isset($_GET['get_dept_by_name'])){
    $dept_name = $_GET['dept_name'];
    $dept_id = $department->get_department_by_name($dept_name);
    $dept_id = $dept_id[0]['dept_id'];
    $programs_for_department = $program->get_program_by_dept_id($dept_id);
    echo json_encode(
        array("data"=>$programs_for_department)
    );
}

if(isset($_POST['add_prog'])){
    $prog_name = $_POST['prog_name'];
    $faculty_name = $_POST['faculty_name'];
    $faculty_id = $faculty->get_faculty_by_name($faculty_name);
    $faculty_id = $faculty_id[0]['faculty_id'];
    $dept_name = $_POST['dept_name'];
    $dept_id = $department->get_department_by_name($dept_name);
    $dept_id = $dept_id[0]['dept_id'];
    $qual_level = $_POST['qual_level'];
    $tb_data = array("prog_name"=>$prog_name,
                    "dept_id"=>$dept_id,
                    "qual_level"=>$qual_level,
                    "faculty_id"=>$faculty_id);
    $db_response = $program->add_program($tb_data);
    if($db_response){
        echo json_encode(
          array("message"=>"success")
        );
    }
}

if(isset($_POST['edit_prog'])){
    $prog_id = $_POST['prog_id'];
    $prog_name = $_POST['prog_name'];
    $faculty_name = $_POST['faculty_name'];
    $faculty_id = $faculty->get_faculty_by_name($faculty_name);
    $faculty_id = $faculty_id[0]['faculty_id'];
    $dept_name = $_POST['dept_name'];
    $dept_id = $department->get_department_by_name($dept_name);
    $dept_id = $dept_id[0]['dept_id'];
    $qual_level = $_POST['qual_level'];
    $tb_data = array("prog_name"=>$prog_name,
                    "dept_id"=>$dept_id,
                    "qual_level"=>$qual_level,
                    "faculty_id"=>$faculty_id);
    $tb_primary_key = array("prog_id"=>$prog_id);
    $db_response = $program->update_program($tb_primary_key,$tb_data);
    if($db_response){
        echo json_encode(
          array("message"=>"success")
        );
    }
}

if(isset($_GET['del_prog'])){
    $prog_id = $_GET['del_prog'];
    $db_response = $program->delete_program($prog_id);
    if($db_response){
        echo json_encode(
        array("message"=>"success")
        );
    }
}