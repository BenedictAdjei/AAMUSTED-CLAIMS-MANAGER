<?php
session_start();
include_once 'Config/Database.php';
require_once 'Model/Department.php';
require_once 'Model/Faculty.php';
require_once 'Model/Program.php';
require_once 'Model/Academic_Year.php';
require_once 'Model/Student.php';
require_once 'Model/User.php';
require_once 'Model/Certificate.php';
require_once 'Model/Semester.php';
require_once 'Model/Claim_Type.php';
require_once 'Model/Claim_Header.php';
require_once 'Model/Course.php';
require_once 'Model/Degree.php';
require_once 'Model/Payhead.php';
require_once 'Model/ExcessClaims.php';
require_once 'Model/InternalClaims.php';

$department = new Department();
$faculty = new Faculty();
$program = new Program();
$academic_year = new Academic_Year();
$user = new User();
$student = new Student();
$certificate = new Certificate();
$semester = new Semester();
$claim_type = new Claim_type();
$claim_header = new Claim_Header();
$course = new Course();
$degree = new Degree();
$payhead = new Payhead();
$claim = new ExcessClaims();
$internal = new InternalSupClaim();


//Dashboard Stuff
$online_users = $user->online_users_report();
$count_all_excess_marking_claim = $claim->count_all_excess_marking_claim();
$count_approved_excess_marking_claim = $claim->count_approved_excess_marking_claim();
$count_pending_excess_marking_claim = $claim->count_pending_excess_marking_claim();
$count_denied_excess_marking_claim = $claim->count_denied_excess_marking_claim();

$count_all_internal_sup_claim = $internal->count_all_internal_sup_claim();
$count_approved_internal_sup_claim = $internal->count_approved_internal_sup_claim();
$count_pending_internal_sup_claim = $internal->count_pending_internal_sup_claim();
$count_denied_internal_sup_claim = $internal->count_denied_internal_sup_claim();

//End

$generate_certificates = array();
$generate_collected_certificates = array();
$generate_pending_certificates = array();
$all_departments = '';
$system_permissions = '';
$all_roles = '';
$all_users = '';
$all_users_by_filter = '';
$all_faculties = '';
$all_programs = '';
$all_academic_years = '';
$all_semesters = '';
$all_courses = '';
$all_degrees = '';
$all_claim_types = '';
$all_claim_headers = '';
$all_payheads = '';
$all_selected_user_permissions = '';
$roles = $user->read_all_roles();
$selected_user_permissions = $user->read_all_selected_user_permissions();
$system_permissions = $user->read_all_system_permissions();
$departments = $department->read_all_departments();
$faculties = $faculty->read_all_faculties();
$programs = $program->read_all_programs();
$users = $user->read_all_users();
$academic_years = $academic_year->read_all_academic_years();
$semesters = $semester->read_all_semesters();
$courses = $course->read_all_courses();
$degrees = $degree->read_all_degrees();
$claim_types = $claim_type->read_all_claim_types();
$claim_headers = $claim_header->read_all_claim_headers();
$payheads= $payhead->read_all_payheads();
$read_all_certificates = $certificate->read_all_certificates();
$read_all_excess_marking = $claim->read_all_excess_marking();
$mega_claims = $internal->read_mega_claims();
$mega_collected_certificates = $certificate->read_mega_collected_certificates();
$mega_pending_certificates = $certificate->read_mega_pending_certificates();
$all_users = $user->read_all_users();
$all_backups = $user->read_all_backups();
//$roles = $user->read_all_roles();
if($departments){
    foreach($departments as $department){
        $all_departments .= '"'.$department['dept_name'].'",';
    }
}

if($faculties){
    foreach($faculties as $faculty){
        $all_faculties .= '"'.$faculty['faculty_name'].'",';
    }
}

if($programs){
    foreach($programs as $program){
        $all_programs .= '"'.$program['prog_name'].'",';
    }
}


if($academic_years){
    foreach($academic_years as $academic_year){
        $all_academic_years .= '"'.$academic_year['academic_year'].'",';
    }
}

if($semesters){
    foreach($semesters as $semester){
        $all_semesters .= '"'.$semester['semester'].'",';
    }
}

// if($payheads){
//     foreach($payheads as $payhead){
//         $all_payheads .= '"'.$payhead['payhead'].'",';
//     }
// }

// if($courses){
//     foreach($academic_years as $academic_year){
//         $all_academic_years .= '"'.$academic_year['academic_year'].'",';
//     }
// }

if($degrees){
    foreach($degrees as $degree){
        $all_degrees .= '"'.$degree['degree'].'",';
    }
}

if($courses){
    foreach($courses as $course){
        $all_courses .= '"'.$course['course_title'].'",';
    }
}

if($claim_types){
    foreach($claim_types as $claim_type){
        $all_claim_types .= '"'.$claim_type['claim_type'].'",';
    }
}
if($claim_headers){
    foreach($claim_headers as $claim_header){
        $all_claim_headers .= '"'.$claim_header['claim_header'].'",';
    }
}

// if($users){
//     foreach($users as $user){
//         $all_users .= '"'.$user['name'].'",';
//     }
// }

// if($students){
//     foreach($users as $user){
//         $all_users_by_filter .= '"'.$user['staff_id'].'|'.$user['name'].' | '.$user['dept_name'].'",';
//     }
// }


if($roles){
    foreach($roles as $role){
        $all_roles .= '"'.$role['role_name'].'",';
    }
}


//Chart Builder
$build_chart1 = '';
$build_chart2 = '';
$join_chart = '';
$join_chart1 = '';
$academic_yr ='';
$i= 0;
$pending = array();
$collected = array();
$total = array();
$newTotal = array();
$newCollected = array();
$newPending = array();
$academic_yrs = '';
$bigTotal = array();
if($academic_years){
for($i=0;$i<count($academic_years);$i++){
    $academic_yr = $certificate->read_certificate_academic_yr($academic_years[$i]['academic_year_id']);
    if($academic_yr){

            for($j=0;$j<count($academic_yr);$j++){
                $pending =  $certificate->read_pending($academic_yr[$j]['academic_yr']);
                
            }
            
            for($j=0;$j<count($academic_yr);$j++){
                $collected =  $certificate->read_collected($academic_yr[$j]['academic_yr']);
                
            }
            for($j=0;$j<count($academic_yr);$j++){ 
                $total =  $certificate->read_total($academic_yr[$j]['academic_yr']);
               
            }

            if($total){
                array_push($newTotal,count($certificate->read_total($academic_yr[0]['academic_yr'])));
                $test =  $certificate->read_total($academic_yr[0]['academic_yr']);
                array_push($bigTotal,$test);
            }
            if($collected){
                array_push($newCollected,count($certificate->read_collected($academic_yr[0]['academic_yr'])));
            }
            if($pending){
                array_push($newPending,count($certificate->read_pending($academic_yr[0]['academic_yr'])));
            }
           
    }

}
    
}
$all_cert_academic_year = '';
$cert_academic_year = $certificate->cert_academic_year();
if($cert_academic_year){
    foreach($cert_academic_year as $academic_year){
        $all_cert_academic_year .= '"'.$academic_year['academic_year'].'",';
    }
}
$main_chart = '';
$join_chart.','.$build_chart1.','.$build_chart2;
$main_chart = $join_chart.','.$build_chart1.','.$build_chart2;

$equilCount = count($newTotal);
$pCount = count($newPending);
$cCount = count($newCollected);
$pDiff= $equilCount - $pCount;
$cDiff = $equilCount - $cCount;

$bigTotalCont = array();
$newCollected2 = array();
for($i=0;$i<count($bigTotal);$i++){
    for($j=0;$j<count($bigTotal[$i]);$j++){
        array_push($bigTotalCont,$bigTotal[$i][$j]);
    }
}

$mcollected = '';
$mpending = '';
if($cert_academic_year){
for($i=0;$i<count($cert_academic_year);$i++){
    for($j=0;$j<count($bigTotalCont);$j++){
        if($bigTotalCont[$j]['academic_yr']==$cert_academic_year[$i]['academic_yr']){
            if($bigTotalCont[$j]['collected']==1){
                $mcollected .= $bigTotalCont[$j]['academic_yr'];
            }else{
                $mpending .= $bigTotalCont[$j]['academic_yr'];
            }
        }
    }
}
}
$c='';
$p='';
if($cert_academic_year){
for($i=0;$i<count($cert_academic_year);$i++){
    
    if($i!=count($cert_academic_year)-1){
        $c .= ''.substr_count($mcollected,$cert_academic_year[$i]['academic_yr']).' ';
    }else{
        $c .= ''.substr_count($mcollected,$cert_academic_year[$i]['academic_yr']).'';
    }
  
}
}

if($cert_academic_year){
for($i=0;$i<count($cert_academic_year);$i++){
    
    if($i!=count($cert_academic_year)-1){
        $p .= ''.substr_count($mpending,$cert_academic_year[$i]['academic_yr']).' ';
    }else{
        $p .= ''.substr_count($mpending,$cert_academic_year[$i]['academic_yr']).'';
    }
  
}
}
$data = explode(" ",$c);
$newCollected = $data;
$data2 = explode(" ",$p);
$newPending = $data2;


    // if($pDiff!=0){
    //     for($i=0;$i<$pDiff;$i++){
    //        // echo $i;
    //         array_push($newPending,0);
    //     }
    // }

    // if($cDiff!=0){
    //     for($i=0;$i<$cDiff;$i++){
    //        // echo $i;
    //         array_push($newCollected,0);
    //     }
    // }
 // print_r($newTotal);

    if($newTotal){
        for($i=0;$i<count($newTotal);$i++){
            if($i==0){
             $join_chart .= '['.$newTotal[$i].'';
            }else if($i%2!=0){
            $join_chart .= ','.$newTotal[$i].'';
           }else if($i%2==0){
            $join_chart .= ','.$newTotal[$i].'';
           }
           if($i==count($newTotal)-1){
            $join_chart .= ']';
           }
        }

    }

    if($newCollected){
        for($i=0;$i<count($newCollected);$i++){
            if($i==0){
             $build_chart1 .= '['.$newCollected[$i].'';
            }else if($i%2!=0){
            $build_chart1 .= ','.$newCollected[$i].'';
           }else if($i%2==0){
            $build_chart1 .= ','.$newCollected[$i].'';
           }
           if($i==count($newCollected)-1){
            $build_chart1 .= ']';
           }
        }

    }
    

    if($newPending){
        for($i=0;$i<count($newPending);$i++){
            if($i==0){
             $build_chart2 .= '['.$newPending[$i].'';
            }else if($i%2!=0){
            $build_chart2 .= ','.$newPending[$i].'';
           }else if($i%2==0){
            $build_chart2 .= ','.$newPending[$i].'';
           }
           if($i==count($newPending)-1){
            $build_chart2 .= ']';
           }
        }

    }
    $main_chart = $join_chart.','.$build_chart1.','.$build_chart2;
//  print_r($build_chart2);
//  print_r($newPending);
//print_r($bigTotal);


// End of Academic Year Chart
//Start of Faculty Chart
//Chart Builder
$f_build_chart1 = '';
$f_build_chart2 = '';
$f_join_chart = '';
$f_join_chart1 = '';
$Faculties ='';
$i= 0;
$f_pending = array();
$f_collected = array();
$f_total = array();
$f_newTotal = array();
$f_newCollected = array();
$f_newPending = array();

if($faculties){
    $bigTotal = array();
    $test = array();
for($i=0;$i<count($faculties);$i++){
    $Faculties = $certificate->read_certificate_faculty($faculties[$i]['faculty_id']);
    if($Faculties){

            for($j=0;$j<count($Faculties);$j++){
                $f_pending =  $certificate->f_read_pending($Faculties[$j]['faculty_id']);
                
            }
            
            for($j=0;$j<count($Faculties);$j++){
                $f_collected =  $certificate->f_read_collected($Faculties[$j]['faculty_id']);
                
            }
            for($j=0;$j<count($Faculties);$j++){ 
                $f_total =  $certificate->f_read_total($Faculties[$j]['faculty_id']);
               
            }

            if($f_total){
                
                array_push($f_newTotal,count($certificate->f_read_total($Faculties[0]['faculty_id'])));
                $test =  $certificate->f_read_total($Faculties[0]['faculty_id']);
                array_push($bigTotal,$test);
            }
            if($f_collected){
                array_push($f_newCollected,count($certificate->f_read_collected($Faculties[0]['faculty_id'])));
            }
            if($f_pending){
                array_push($f_newPending,count($certificate->f_read_pending($Faculties[0]['faculty_id'])));
            }
           
    }

}
    
}
$all_cert_f_cert_faculty = '';
$f_cert_faculty = $certificate->f_cert_faculty();
if($f_cert_faculty){
    foreach($f_cert_faculty as $f_cert){
        $all_cert_f_cert_faculty .= '"'.$f_cert['faculty_name'].'",';
    }
}
// $f_main_chart = '';
// $f_join_chart.','.$f_build_chart1.','.$f_build_chart2;
// $f_main_chart = $f_join_chart.','.$f_build_chart1.','.$f_build_chart2;

$f_equilCount = count($f_newTotal);
$f_pCount = count($f_newPending);
$f_cCount = count($f_newCollected);
 $f_pDiff= $f_equilCount-$f_pCount;
$f_cDiff =   $f_equilCount-$f_cCount ;


$bigTotalCont = array();
$newCollected2 = array();
for($i=0;$i<count($bigTotal);$i++){
    for($j=0;$j<count($bigTotal[$i]);$j++){
        array_push($bigTotalCont,$bigTotal[$i][$j]);
    }
}

$mcollected = '';
$mpending = '';
if($f_cert_faculty){
for($i=0;$i<count($f_cert_faculty);$i++){
    for($j=0;$j<count($bigTotalCont);$j++){
        if($bigTotalCont[$j]['faculty_id']==$f_cert_faculty[$i]['faculty_id']){
            if($bigTotalCont[$j]['collected']==1){
                $mcollected .= $bigTotalCont[$j]['faculty_id'];
            }else{
                $mpending .= $bigTotalCont[$j]['faculty_id'];
            }
        }
    }
}
}
$c='';
$p='';
if($f_cert_faculty){
for($i=0;$i<count($f_cert_faculty);$i++){
    
    if($i!=count($f_cert_faculty)-1){
        $c .= ''.substr_count($mcollected,$f_cert_faculty[$i]['faculty_id']).' ';
    }else{
        $c .= ''.substr_count($mcollected,$f_cert_faculty[$i]['faculty_id']).'';
    }
  
}
}

if($f_cert_faculty){
for($i=0;$i<count($f_cert_faculty);$i++){
    
    if($i!=count($f_cert_faculty)-1){
        $p .= ''.substr_count($mpending,$f_cert_faculty[$i]['faculty_id']).' ';
    }else{
        $p .= ''.substr_count($mpending,$f_cert_faculty[$i]['faculty_id']).'';
    }
  
}
}

$data = explode(" ",$c);
$f_newCollected = $data;
$data2 = explode(" ",$p);
$f_newPending = $data2;

    // if($f_pDiff!=0){
    //     for($i=0;$i<$f_pDiff;$i++){
    //        // echo $i;
    //         array_push($f_newPending,0);
    //     }
    // }

    // if($f_cDiff!=0){
    //     for($i=0;$i<$f_cDiff;$i++){
    //        // echo $i;
    //         array_push($f_newCollected,0);
    //     }
    // }
 // print_r($newTotal);
 if($f_newTotal){
    for($i=0;$i<count($f_newTotal);$i++){
        if($i==0){
         $f_join_chart .= '['.$f_newTotal[$i].'';
        }else if($i%2!=0){
        $f_join_chart .= ','.$f_newTotal[$i].'';
       }else if($i%2==0){
        $f_join_chart .= ','.$f_newTotal[$i].'';
       }
       if($i==count($f_newTotal)-1){
        $f_join_chart .= ']';
       }
    }

}

if($f_newCollected){
    for($i=0;$i<count($f_newTotal);$i++){
        if($i==0){
         $f_build_chart1 .= '['.$f_newCollected[$i].'';
        }else if($i%2!=0){
        $f_build_chart1 .= ','.$f_newCollected[$i].'';
       }else if($i%2==0){
        $f_build_chart1 .= ','.$f_newCollected[$i].'';
       }
       if($i==count($f_newCollected)-1){
        $f_build_chart1 .= ']';
       }
    }

}

if($f_newPending){
    for($i=0;$i<count($f_newPending);$i++){
        if($i==0){
         $f_build_chart2 .= '['.$f_newPending[$i].'';
        }else if($i%2!=0){
        $f_build_chart2 .= ','.$f_newPending[$i].'';
       }else if($i%2==0){
        $f_build_chart2 .= ','.$f_newPending[$i].'';
       }
       if($i==count($f_newPending)-1){
        $f_build_chart2 .= ']';
       }
    }

}
    $f_main_chart = $f_join_chart.','.$f_build_chart1.','.$f_build_chart2;
    // print_r($f_build_chart2);
    // print_r($f_newPending);
//End of Faculty

//Start of Dept Chart
//Chart Builder
$d_build_chart1 = '';
$d_build_chart2 = '';
$d_join_chart = '';
$d_join_chart1 = '';
$Faculties ='';
$i= 0;
$d_pending = array();
$d_collected = array();
$d_total = array();
$Department = array();
$d_newTotal = array();
$d_newCollected = array();
$d_newPending = array();

if($departments){
    $bigTotal = array();
    $test = array();
for($i=0;$i<count($departments);$i++){
    $Departments = $certificate->read_certificate_dept($departments[$i]['dept_id']);
   
    if($Departments){
        
            for($j=0;$j<count($Departments);$j++){
                $d_pending =  $certificate->d_read_pending($Departments[$j]['dept_id']);
                
            }
            
            for($j=0;$j<count($Departments);$j++){
                $d_collected =  $certificate->d_read_collected($Departments[$j]['dept_id']);
            }
            for($j=0;$j<count($Departments);$j++){ 
                $d_total =  $certificate->d_read_total($Departments[$j]['dept_id']);
                
            }
            if($d_total){
                array_push($d_newTotal,count($certificate->d_read_total($Departments[0]['dept_id'])));
                $test =  $certificate->d_read_total($Departments[0]['dept_id']);
                array_push($bigTotal,$test);
            }
            if($d_collected){
                array_push($d_newCollected,count($certificate->d_read_collected($Departments[0]['dept_id'])));
            }
            if($d_pending){
                array_push($d_newPending,count($certificate->d_read_pending($Departments[0]['dept_id'])));
            }    
            
         
    }

    
    
}
}

$d_certs = '';
$all_d_cert_faculty = $certificate->d_cert_dept();
if($all_d_cert_faculty){
    foreach($all_d_cert_faculty as $d_cert){
        $d_certs .= '"'.$d_cert['dept_name'].'",';
    }
}
$d_equilCount = count($d_newTotal);
$d_pCount = count($d_newPending);
$d_cCount = count($d_newCollected);
 $d_pDiff= $d_equilCount-$d_pCount;
$d_cDiff =  $d_equilCount-$d_cCount;


$bigTotalCont = array();
$newCollected2 = array();
for($i=0;$i<count($bigTotal);$i++){
    for($j=0;$j<count($bigTotal[$i]);$j++){
        array_push($bigTotalCont,$bigTotal[$i][$j]);
    }
}

$mcollected = '';
$mpending = '';
if($all_d_cert_faculty){
for($i=0;$i<count($all_d_cert_faculty);$i++){
    for($j=0;$j<count($bigTotalCont);$j++){
        if($bigTotalCont[$j]['dept_id']==$all_d_cert_faculty[$i]['dept_id']){
            if($bigTotalCont[$j]['collected']==1){
                $mcollected .= $bigTotalCont[$j]['dept_id'];
            }else{
                $mpending .= $bigTotalCont[$j]['dept_id'];
            }
        }
    }
}
}
$c='';
$p='';
if($all_d_cert_faculty){
for($i=0;$i<count($all_d_cert_faculty);$i++){
    
    if($i!=count($all_d_cert_faculty)-1){
        $c .= ''.substr_count($mcollected,$all_d_cert_faculty[$i]['dept_id']).' ';
    }else{
        $c .= ''.substr_count($mcollected,$all_d_cert_faculty[$i]['dept_id']).'';
    }
  
}
}

if($all_d_cert_faculty){
for($i=0;$i<count($all_d_cert_faculty);$i++){
    
    if($i!=count($all_d_cert_faculty)-1){
        $p .= ''.substr_count($mpending,$all_d_cert_faculty[$i]['dept_id']).' ';
    }else{
        $p .= ''.substr_count($mpending,$all_d_cert_faculty[$i]['dept_id']).'';
    }
  
}
}

$data = explode(" ",$c);
$d_newCollected = $data;
$data2 = explode(" ",$p);
$d_newPending = $data2;


    // if($d_pDiff!=0){
    //     for($i=0;$i<$d_pDiff;$i++){
    //        // echo $i;
    //        $d_newPending[1] = 0;
    //         array_push($d_newPending,0);
    //     }
    // }
    

    // if($d_cDiff!=0){
    //     for($i=0;$i<$d_cDiff;$i++){
    //        // echo $i;
    //        //$d_newCollected[1] = 0;
    //         array_push($d_newCollected,0);
    //     }
    // }

    
  
    if($d_newTotal){
        for($i=0;$i<count($d_newTotal);$i++){
            if($i==0){
             $d_join_chart .= '['.$d_newTotal[$i].'';
            }else if($i%2!=0){
            $d_join_chart .= ','.$d_newTotal[$i].'';
           }else if($i%2==0){
            $d_join_chart .= ','.$d_newTotal[$i].'';
           }
           if($i==count($d_newTotal)-1){
            $d_join_chart .= ']';
           }
        }
    
    }

    if($d_newCollected){
        for($i=0;$i<count($d_newTotal);$i++){
            if($i==0){
             $d_build_chart1 .= '['.$d_newCollected[$i].'';
            }else if($i%2!=0){
            $d_build_chart1 .= ','.$d_newCollected[$i].'';
           }else if($i%2==0){
            $d_build_chart1 .= ','.$d_newCollected[$i].'';
           }
           if($i==count($d_newCollected)-1){
            $d_build_chart1 .= ']';
           }
        }
    
    }

    if($d_newPending){
        for($i=0;$i<count($d_newPending);$i++){
            if($i==0){
             $d_build_chart2 .= '['.$d_newPending[$i].'';
            }else if($i%2!=0){
            $d_build_chart2 .= ','.$d_newPending[$i].'';
           }else if($i%2==0){
            $d_build_chart2 .= ','.$d_newPending[$i].'';
           }
           if($i==count($d_newPending)-1){
            $d_build_chart2 .= ']';
           }
        }
    
    }

    
    $d_main_chart = $d_join_chart.','.$d_build_chart1.','.$d_build_chart2;
    // print_r($d_join_chart);
    //  print_r($build_chart2);
//End of Dept
