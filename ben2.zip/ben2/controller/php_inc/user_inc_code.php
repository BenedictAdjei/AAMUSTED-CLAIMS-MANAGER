<?php
session_start();
require_once 'Model/User.php';
include_once 'Config/Database.php';
require_once 'Model/Department.php';
require_once 'Model/Faculty.php';
require_once 'Model/Program.php';
require_once 'Model/Academic_Year.php';
require_once 'Model/Student.php';
require_once 'Model/Certificate.php';

$user = new User();
$department = new Department();
$faculty = new Faculty();
$program = new Program();
$academic_year = new Academic_Year();
$student = new Student();
$certificate = new Certificate();

$generated_history_report  = array();
$login_history_report = $user->login_history_report();
$users = $user->read_all_users();
$online_users = $user->online_users_report();
$login_attempts_report = $user->login_attempts_report();