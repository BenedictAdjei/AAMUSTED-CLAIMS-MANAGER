<?php
session_start();
include_once '../Config/Database.php';
require_once '../Model/Degree.php';
require_once '../Model/Academic_Year.php';
require_once '../Model/Claim_Type.php';
require_once '../Model/InternalClaims.php';
require_once '../Model/Payhead.php';
require_once '../Model/Course.php';
require_once '../Model/Semester.php';
require_once '../Model/Claim_Header.php';


$academic_year = new Academic_Year();
$payhead = new Payhead();
$claim_type = new Claim_Type();
$claim = new InternalSupClaim();
$degree = new Degree();
$claim_header = new Claim_Header();


if(isset($_GET['::'])){
    $role=$_SESSION['role_id'];
    if ($role=1) {
         $all_claims = $claim->read_all_internal_sup_claim();
    echo json_encode(
        array("data"=>$all_claims)
    );
     }else{
        $user_id=$_SESSION['dept_id'];
        $all_claims = $claim->read_all_internal_sup_claim_by_userdept($user_id);
    echo json_encode(
        array("data"=>$all_claims)
    );} 
    
}

if(isset($_GET['hod'])){
    $role=$_SESSION['role_id'];
    if ($role==1) {
       $all_claims = $claim->read_all_internal_sup_claim();
    echo json_encode(
        array("data"=>$all_claims)
    );
     }else{
        $user_id=$_SESSION['dept_id'];
        $all_claims = $claim->read_all_internal_sup_claim_by_userdept_n_hod($user_id);
    echo json_encode(
        array("data"=>$all_claims)
    );} 
    
}

if(isset($_GET['ac'])){
    $all_claims = $claim->read_all_internal_sup_claim();
    echo json_encode(
        array("data"=>$all_claims)
    );
}

if(isset($_POST['add_claim'])){
    
    $academic_yr = $_POST['academic_yr'];
    $academic_yr_id = $academic_year->get_academic_year_by_name($academic_yr);
    $academic_yr_id = $academic_yr_id[0]['academic_year_id'];
    $claim_type_name = $_POST['claim_type'];
    $claim_type_id = $claim_type->get_claim_type_by_name($claim_type_name);
    $claim_type_id = $claim_type_id[0]['claim_type_id'];
    $degree_name = $_POST['degree'];
    $degree_id = $degree->get_degree_by_name($degree_name);
    $degree_id = $degree_id[0]['degree_id'];
    $stud_id = $_POST['stud_id'];
    $project_title = $_POST['project_title'];
    $claim_header_name = 'External Supervision or Examination';
    $claim_header_id = $claim_header->get_claim_header_by_name($claim_header_name);
    $claim_header_id = $claim_header_id[0]['claim_header_id'];
    $rate = $payhead->get_rate_by_claim_h_n_d($claim_header_id,$degree_id);
    $rate = $rate[0]['rate'];
    echo $rate;
    $status = 1;
    $user_id = $_POST['user_id'];
    $dept_id=$_SESSION['dept_id'];
    $amount=$rate;
    $tb_data = array(
        "claim_type_id"=>$claim_type_id,
        "academic_yr"=>$academic_yr_id,
        "degree_id"=>$degree_id,
        "stud_id"=>$stud_id,
        "project_title"=>$project_title,
                    "rate"=>$rate,
                    "amount"=>$amount,
                    "status"=>$status,
                    "user_id"=>$user_id,
                    "dept_id"=>$dept_id,
);
    $db_response = $claim->add($academic_yr_id,$claim_type_id,$stud_id,$degree_id,$project_title,$rate,$amount,$status,$dept_id,$user_id);
    if($db_response){
        echo json_encode(
          array("message"=>"success")
        );
    }
}


if(isset($_GET['del_claim'])){
    $cert_id = $_GET['del_certificate'];
    $db_response = $certificate->delete_certificate($cert_id);
    if($db_response){
        echo json_encode(
        array("message"=>"success")
        );
    }
}


if(isset($_GET['searchClaim'])){
    $user_id = $_GET['user_id'];
    $academic_year_id = $_GET['academic_year_id'];
    $degree_id = $_GET['degree_id'];
    $claim_type_id = $_GET['claim_type_id'];
    $db_response = false;
    if($user_id && $academic_year_id && $degree_id && $claim_type_id){
        $db_response = $claim->search_claim_by_4($user_id,$academic_year_id,$degree_id,$claim_type_id);
    }    
    if($db_response){
        echo json_encode($db_response);
    }else{
        echo json_encode($db_response);
    }
}

if(isset($_POST['approve_claim'])){
    echo "working";
    $claim_id = $_POST['claim_type'];
    $user_id = $_POST['issued_by'];
    $amount=$_POST['amount'];
    $user_id = $_POST['user_id'];
    $tb_data = array("academic_yr"=>$academic_yr_id,
                    "stud_id"=>$stud_id,
                    "degree_id"=>$degree_id,
                    "claim_type_id"=>$claim_type_id,
                    "project_title"=>$project_title,
                    "serial"=>$serial,
                    "status"=>$status,
                    "user_id"=>$user_id,
);
    $db_response = $claim->add_claim($tb_data);
    if($db_response){
        echo json_encode(
          array("message"=>"success")
        );
    }
}