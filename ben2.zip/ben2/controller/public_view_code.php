<?php
include_once '../Config/Database.php';
require_once '../Model/Public_View_Setup.php';
$public_view_setup = new Public_View_Setup();
if(isset($_GET['::'])){
    $public_setup = $public_view_setup->read_all_public_view_setup();
    echo json_encode(
        array("data"=>$public_setup)
    );
}

if(isset($_POST['public_view_setup_id'])){
    $public_view_setup_id = $_POST['public_view_setup_id'];
    $support_phone = $_POST['support_phone'];
    $support_email = $_POST['support_email'];
    $fb_handle= $_POST['fb_handle'];
    $twitter_handle = $_POST['twitter_handle'];
    $youtube_handle = $_POST['youtube_handle'];
    $site_name = $_POST['site_name'];
    $about_site = $_POST['about_site'];
    $notice = $_POST['notice'];
    $tb_primary_key = array("public_view_setup_id"=>$public_view_setup_id);
    $tb_values = array("support_phone"=>$support_phone,
                       "support_email"=>$support_email,
                       "fb_handle"=>$fb_handle,
                       "twitter_handle"=>$twitter_handle,
                       "youtube_handle"=>$youtube_handle,
                       "site_name"=>$site_name,
                       "about_site"=>$about_site,
                       "notice"=>$notice);
    $dbResponse = $public_view_setup->update_home($tb_primary_key,$tb_values);
    if($dbResponse){
      echo  json_encode(
        array("edit"=>"success")
      );
    }
}


if(isset($_FILES['upload_logo'])){
  $public_view_setup_id = $_POST['logo_id'];
  $generated_name_1 = '';
	$ext_1 = explode('.', basename($_FILES["upload_logo"]["name"])); //explode file name from dot(.) 
  $file_extension_1 = end($ext_1); //store extensions in the variable
  $generated_name_1 .= md5(uniqid()) . "." . $ext_1[count($ext_1) - 1];
  move_uploaded_file($_FILES["upload_logo"]["tmp_name"], "../../images/".$generated_name_1);
  $data = array("site_logo"=>$generated_name_1);
  $tb_primary_key = array("public_view_setup_id"=>$public_view_setup_id);
  $public_view_setup->update_home($tb_primary_key,$data);
}

//Campus
if(isset($_GET['get_campuses'])){
  $get_campuses = $public_view_setup->get_campuses();
  echo json_encode(
      array("data"=>$get_campuses)
  );
}

if(isset($_POST['add_campus'])){
  $campus_name = $_POST['campus_name'];
  $campus_desc = $_POST['campus_desc'];
  $generated_name_1 = '';
  print_r($_FILES);
  if($_FILES['campus_thumbnail']){
    
    $ext_1 = explode('.', basename($_FILES["campus_thumbnail"]["name"])); //explode file name from dot(.) 
    $file_extension_1 = end($ext_1); //store extensions in the variable
    $generated_name_1 .= md5(uniqid()) . "." . $ext_1[count($ext_1) - 1];
    move_uploaded_file($_FILES["campus_thumbnail"]["tmp_name"], "../../images/campus/".$generated_name_1);
  }
  $tbData = array("campus_name"=>$campus_name,
                  "campus_desc"=>$campus_desc,
                  "campus_thumbnail"=>$generated_name_1
            );
  $dbResponse = $public_view_setup->add_campus($tbData);

}

if(isset($_POST['edit_campus'])){
  $campus_id = $_POST['campus_id'];
  $campus_name = $_POST['campus_name'];
  $campus_desc = $_POST['campus_desc'];
  $generated_name_1 = $_POST['campus_thumb'];
  if(isset($_FILES['campus_thumbnail']['name'])){
    $generated_name_1 = '';
    $ext_1 = explode('.', basename($_FILES["campus_thumbnail"]["name"])); //explode file name from dot(.) 
    $file_extension_1 = end($ext_1); //store extensions in the variable
    $generated_name_1 .= md5(uniqid()) . "." . $ext_1[count($ext_1) - 1];
    move_uploaded_file($_FILES["campus_thumbnail"]["tmp_name"], "../../images/campus/".$generated_name_1);
  }
  $tbData = array("campus_name"=>$campus_name,
                  "campus_desc"=>$campus_desc,
                  "campus_thumbnail"=>$generated_name_1
            );
  $tb_primary_key = array("campus_id"=>$campus_id);
  $dbResponse = $public_view_setup->edit_campus($tb_primary_key,$tbData);

}

if(isset($_GET['del_campus'])){
  $campus_id = $_GET['del_campus'];
  $dbResponse = $public_view_setup->delete_campus($campus_id);
  if($dbResponse){
    echo json_encode(
      array("message"=>"success")
  );
  }
  
}

//Slider
if(isset($_GET['get_slides'])){
  $get_slides = $public_view_setup->get_slides();
  echo json_encode(
      array("data"=>$get_slides)
  );
}

if(isset($_POST['edit_slide'])){
  $slide_id = $_POST['slide_id'];
  $active = $_POST['active'];
  $generated_name_1 = $_POST['edit_image'];
  if(isset($_FILES['edit_image']['name'])){
    $generated_name_1 = '';
    $ext_1 = explode('.', basename($_FILES["edit_image"]["name"])); //explode file name from dot(.) 
    $file_extension_1 = end($ext_1); //store extensions in the variable
    $generated_name_1 .= md5(uniqid()) . "." . $ext_1[count($ext_1) - 1];
    move_uploaded_file($_FILES["edit_image"]["tmp_name"], "../../images/slides/".$generated_name_1);
  }
  $tbData = array("active"=>$active,
                  "image"=>$generated_name_1
            );
  $tb_primary_key = array("slide_id"=>$slide_id);
  $dbResponse = $public_view_setup->edit_slide($tb_primary_key,$tbData);

}

if(isset($_GET['del_image'])){
  $slide_id = $_GET['del_image'];
  $dbResponse = $public_view_setup->delete_slide($slide_id);
  if($dbResponse){
    echo json_encode(
      array("message"=>"success")
  );
  }
  
}


// if(isset($_POST['add_slide'])){
  if(isset($_FILES['image']['name'])){
    $generated_name_1 = '';
    $ext_1 = explode('.', basename($_FILES["image"]["name"])); //explode file name from dot(.) 
    $file_extension_1 = end($ext_1); //store extensions in the variable
    $generated_name_1 .= md5(uniqid()) . "." . $ext_1[count($ext_1) - 1];
    move_uploaded_file($_FILES["image"]["tmp_name"], "../../images/slides/".$generated_name_1);
  
  $tbData = array("active"=>'No',
                  "image"=>$generated_name_1
            );
  $dbResponse = $public_view_setup->add_slide($tbData);

}

//Complaint
if(isset($_GET['get_complaints'])){
  $get_complaints = $public_view_setup->get_complaints();
  echo json_encode(
      array("data"=>$get_complaints)
  );
}

if(isset($_POST['update_complaint'])){
  $addressed = $_POST['addressed'];
  $complaint_id = $_POST['complaint_id'];
  
  $tbData = array("addressed"=>$addressed );
  $tb_primary_key = array("complaint_id"=>$complaint_id);
  $dbResponse = $public_view_setup->update_complaint($tb_primary_key,$tbData);

}

//Hostel
if(isset($_GET['get_hostels'])){
  $get_hostels = $public_view_setup->get_hostels();
  echo json_encode(
      array("data"=>$get_hostels)
  );
}

if(isset($_POST['add_hostel'])){
  $campus_name = $_POST['campus_name'];
  $campus_id = $public_view_setup->get_campus_by_name($campus_name);
  $campus_id = $campus_id[0]['campus_id'];
  $hostel_name = $_POST['hostel_name'];
  $hostel_price_tag = $_POST['hostel_price_tag'];
  $hostel_desc = $_POST['hostel_desc'];
  $hostel_min_price = $_POST['hostel_min_price'];
  $owner = $_POST['owner'];
  $owner_contact = $_POST['owner_contact'];
  $generated_name_1 = '';
  if(isset($_FILES['hostel_thumbnail']['name'])){
    
    $ext_1 = explode('.', basename($_FILES["hostel_thumbnail"]["name"])); //explode file name from dot(.) 
    $file_extension_1 = end($ext_1); //store extensions in the variable
    $generated_name_1 .= md5(uniqid()) . "." . $ext_1[count($ext_1) - 1];
    move_uploaded_file($_FILES["hostel_thumbnail"]["tmp_name"], "../../images/rooms/".$generated_name_1);
  }
  $tbData = array("hostel_name"=>$hostel_name,
                  "campus_id"=>$campus_id,
                  "hostel_price_tag"=>$hostel_price_tag,
                  "hostel_desc"=>$hostel_desc,
                  "hostel_min_price"=>$hostel_min_price,
                  "owner_contact"=>$owner_contact,
                  "owner"=>$owner,
                  "hostel_thumbnail"=>$generated_name_1
            );
  $dbResponse = $public_view_setup->add_hostel($tbData);

}

if(isset($_POST['edit_hostel'])){
  $hostel_id = $_POST['hostel_id'];
  $campus_name = $_POST['campus_name'];
  $campus_id = $public_view_setup->get_campus_by_name($campus_name);
  $campus_id = $campus_id[0]['campus_id'];
  $hostel_name = $_POST['hostel_name'];
  $hostel_price_tag = $_POST['hostel_price_tag'];
  $hostel_desc = $_POST['hostel_desc'];
  $hostel_min_price = $_POST['hostel_min_price'];
  $owner = $_POST['owner'];
  $owner_contact = $_POST['owner_contact'];
  $generated_name_1 = $_POST['hostel_thumbnail'];
  if(isset($_FILES['hostel_thumbnail']['name'])){
    $generated_name_1 = '';
    $ext_1 = explode('.', basename($_FILES["hostel_thumbnail"]["name"])); //explode file name from dot(.) 
    $file_extension_1 = end($ext_1); //store extensions in the variable
    $generated_name_1 .= md5(uniqid()) . "." . $ext_1[count($ext_1) - 1];
    move_uploaded_file($_FILES["hostel_thumbnail"]["tmp_name"], "../../images/rooms/".$generated_name_1);
  }
  $tbData = array("hostel_name"=>$hostel_name,
                  "campus_id"=>$campus_id,
                  "hostel_name"=>$hostel_name,
                  "hostel_price_tag"=>$hostel_price_tag,
                  "hostel_desc"=>$hostel_desc,
                  "hostel_min_price"=>$hostel_min_price,
                  "owner_contact"=>$owner_contact,
                  "owner"=>$owner,
                  "hostel_thumbnail"=>$generated_name_1
            );
  $tb_primary_key = array("hostel_id"=>$hostel_id);
  $dbResponse = $public_view_setup->update_hostel($tb_primary_key,$tbData);

}

if(isset($_GET['del_hostel'])){
  $hostel_id = $_GET['del_hostel'];
  $dbResponse = $public_view_setup->delete_hostel($hostel_id);
  if($dbResponse){
    echo json_encode(
      array("message"=>"success")
  );
  }
  
}


//Hostel Rooms
if(isset($_GET['get_rooms'])){
  $get_rooms = $public_view_setup->get_rooms();
  echo json_encode(
      array("data"=>$get_rooms)
  );
}



//Hostel Reservations
if(isset($_GET['get_res'])){
  $get_hostel_reservations = $public_view_setup->get_hostel_reservations();
  echo json_encode(
      array("data"=>$get_hostel_reservations)
  );
}


