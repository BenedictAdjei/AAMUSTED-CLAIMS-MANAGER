<?php
include_once '../Config/Database.php';
require_once '../Model/Claim_Type.php';
$claim_type = new Claim_type();

if(isset($_GET['::'])){
    $all_claim_types = $claim_type->read_all_claim_types();
    echo json_encode(
        array("data"=>$all_claim_types)
    );
}

if(isset($_POST['add_claim_type'])){
    $all_claim_types = $claim_type->read_all_claim_types();
    $claim_ty = $_POST['claim_type'];
    $isset = false;
    foreach($all_claim_types as $claim_types){
        if($claim_ty == $claim_types['claim_type']){
            $isset = true;
        }
    }
    if(!$isset){
        $tb_data = array("claim_type"=>$claim_ty);
        $db_response = $claim_type->add_claim_type($tb_data);
        if($db_response){
            echo json_encode(
            array("message"=>"success")
            );
        }
    }
    
}

if(isset($_POST['edit_claim_type'])){
    $claim_type_id = $_POST['claim_type_id'];
    $claim_ty = $_POST['claim_type'];
    $tb_data = array("claim_type"=>$claim_ty);
    $tb_primary_key = array("claim_type_id"=>$claim_type_id);
    $db_response = $claim_type->update_claim_type($tb_primary_key,$tb_data);
    if($db_response){
        echo json_encode(
          array("message"=>"success")
        );
    }
}

if(isset($_GET['del_claim_type'])){
    $claim_type_id = $_GET['del_claim_type'];
    $db_response = $claim_type->delete_claim_type($claim_type_id);
    if(is_array($db_response)){
        echo json_encode(
        array("message"=>"success")
        );
    }else if(!$db_response){
        echo json_encode(
            array("message"=>"fail")
            );
    }
    
}