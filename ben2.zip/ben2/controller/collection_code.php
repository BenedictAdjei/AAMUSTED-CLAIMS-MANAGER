<?php
include_once '../Config/Database.php';
require_once '../Model/Collection.php';
require_once '../Model/Certificate.php';
require_once '../Model/Student.php';
require_once '../Model/Department.php';
$collection = new Collection();
$certificate = new Certificate();
$student = new Student();
$department = new Department();

if(isset($_GET['::'])){
    $all_collections = $collection->read_all_collections();
    echo json_encode(
        array("data"=>$all_collections)
    );
}

if(isset($_GET['get_collection'])){
    $stud_id = $_GET['stud_id'];
    $collections = $collection->read_collection_by_stud_id($stud_id);
    echo json_encode(
        array("data"=>$collections)
    );
}

if(isset($_POST['add_collection'])){
    $cert_id = $_POST['cert_id'];
    $certificate_serial = $_POST['certificate_serial'];
    $dispatched_by = $_POST['dispatched_by'];
    $received_by = $_POST['received_by'];
    $received_by = $student->get_student_by_name($received_by);
    $received_by = $received_by[0]['stud_id'];  
    $signature = $_POST['signature'];
    $phone_number = $_POST['phone_number'];
    $other_name = $_POST['other_name'];
    $other_staff_id = $_POST['other_staff_id'];
    $other_rank = $_POST['other_rank'];
    $other_dept_id = $_POST['other_dept_id'];
    $other_phone_number = $_POST['other_phone_number'];
    $other_signature = $_POST['other_signature'];
    $date = date("y-m-d");
    $tb_data = array("certificate_serial"=>$certificate_serial,
                    "dispatched_by"=>$dispatched_by,
                    "received_by"=>$received_by,
                    "signature"=>$signature,
                    "date"=>$date,
                    "phone_number"=>$phone_number,
                    "other_name"=>$other_name,
                    "other_staff_id"=>$other_staff_id,
                    "other_rank"=>$other_rank,
                    "other_dept_id"=>$other_dept_id,
                    "other_phone_number"=>$other_phone_number,
                    "other_signature"=>$other_signature);
    $db_response = $collection->add_collection($tb_data);
    $tb_data2 = array("collected"=>1);
    $tb_primary_key2 = array("cert_id"=>$cert_id);
    $db_response = $certificate->update_certificate($tb_primary_key2,$tb_data2);
    if($db_response){
        echo json_encode(
          array("message"=>"success")
        );
    }
}

if(isset($_POST['edit_collection'])){
    $collection_id = $_POST['collection_id'];
    $certificate_serial = $_POST['certificate_serial'];
    $dispatched_by = $_POST['dispatched_by'];
    $received_by = $_POST['stud_name'];
    $received_by = $student->get_student_by_name($received_by);
    $received_by = $received_by[0]['stud_id'];  
    $signature = $_POST['signature'];
    $phone_number = $_POST['phone_number'];
    $other_name = $_POST['other_name'];
    $other_staff_id = $_POST['other_staff_id'];
    $other_rank = $_POST['other_rank'];
    $other_dept_id = $_POST['other_dept_id'];
    $other_phone_number = $_POST['other_phone_number'];
    $other_signature = $_POST['other_signature'];
    $tb_data = array("certificate_serial"=>$certificate_serial,
                    "dispatched_by"=>$dispatched_by,
                    "received_by"=>$received_by,
                    "signature"=>$signature,
                    "phone_number"=>$phone_number,
                    "other_name"=>$other_name,
                    "other_staff_id"=>$other_staff_id,
                    "other_rank"=>$other_rank,
                    "other_dept_id"=>$other_dept_id,
                    "other_phone_number"=>$other_phone_number,
                    "other_signature"=>$other_signature);
    $tb_primary_key = array("collection_id"=>$collection_id);
    $db_response = $collection->update_collection($tb_primary_key,$tb_data);
    if($db_response){
        echo json_encode(
          array("message"=>"success")
        );
    }
}

if(isset($_GET['del_collection_id']) && isset($_GET['cert_serial'])){
    $cert_serial = $_GET['cert_serial'];
    $tb_data2 = array("collected"=>0);
    $tb_primary_key2 = array("serial"=>$cert_serial);
    $db_response2 = $certificate->update_certificate($tb_primary_key2,$tb_data2);
    $collection_id = $_GET['del_collection_id'];
    $db_response = $collection->delete_collection($collection_id);
    if($db_response2 && $db_response){
        echo json_encode(
        array("message"=>"success")
        );
    }else{
        echo json_encode(
            array("message"=>"fail")
            );
    }
}

if(isset($_GET['searchCert'])){
    $stud_id = $_GET['stud_id'];
    $academic_year_id = $_GET['academic_year_id'];
    $prog_id = $_GET['prog_id'];
    $db_response = false;
    if($stud_id && $academic_year_id && $prog_id){
        $db_response = $certificate->search_certificate_by_3($stud_id,$academic_year_id,$prog_id);
    }else if($stud_id && $academic_year_id){
        $db_response = $certificate->search_certificate_by_s_n_a($stud_id,$academic_year_id);
    }else if($stud_id && $prog_id){
        $db_response = $certificate->search_certificate_by_s_n_p($stud_id,$prog_id);
    }else if($academic_year_id && $prog_id){
        $db_response = $certificate->search_certificate_by_a_n_p($academic_year_id,$prog_id);
    }

    
    if($db_response){
        echo json_encode($db_response);
    }else{
        echo json_encode($db_response);
    }
}