<?php
include_once '../Config/Database.php';
require_once '../Model/Student.php';
require_once '../Model/Faculty.php';
require_once '../Model/Department.php';
require_once '../Model/Program.php';
require_once '../Model/Academic_Year.php';
$student = new Student();
$faculty = new Faculty();
$department = new Department();
$program = new Program();
$academic_year_obj = new Academic_Year();

if(isset($_GET['::'])){
    $all_students = $student->read_all_students();
    echo json_encode(
        array("data"=>$all_students)
    );
}




if(isset($_POST['add_student'])){
    $first_name = $_POST['first_name'];
    $middle_name = $_POST['middle_name'];
    $last_name = $_POST['last_name'];
    $index_number = $_POST['index_number'];
    $faculty_name = $_POST['faculty_name'];
    $faculty_id = $faculty->get_faculty_by_name($faculty_name);
    $faculty_id = $faculty_id[0]['faculty_id'];
    $dept_name = $_POST['dept_name'];
    $dept_id = $department->get_department_by_name($dept_name);
    $dept_id = $dept_id[0]['dept_id'];
    $prog_name = $_POST['prog_name'];
    $prog_id = $program->get_program_by_name($prog_name);
    $prog_id = $prog_id[0]['prog_id'];
    $academic_year = $_POST['academic_year'];
    $academic_year_id = $academic_year_obj->get_academic_year_by_name($academic_year);
    $academic_year_id = $academic_year_id[0]['academic_year_id'];
    $tb_data = array("first_name"=>$first_name,
                    "middle_name"=>$middle_name,
                    "last_name"=>$last_name,
                    "prog_id"=>$prog_id,
                    "faculty_id"=>$faculty_id,
                    "dept_id"=>$dept_id,
                    "academic_year_id"=>$academic_year_id,
                    "index_number"=>$index_number);
    $db_response = $student->add_student($tb_data);
    if($db_response){
        echo json_encode(
          array("message"=>"success")
        );
    }
}

if(isset($_POST['edit_student'])){
    $stud_id = $_POST['stud_id'];
    $first_name = $_POST['first_name'];
    $middle_name = $_POST['middle_name'];
    $last_name = $_POST['last_name'];
    $index_number = $_POST['index_number'];
    $faculty_name = $_POST['faculty_name'];
    $faculty_id = $faculty->get_faculty_by_name($faculty_name);
    $faculty_id = $faculty_id[0]['faculty_id'];
    $dept_name = $_POST['dept_name'];
    $dept_id = $department->get_department_by_name($dept_name);
    $dept_id = $dept_id[0]['dept_id'];
    $prog_name = $_POST['prog_name'];
    $prog_id = $program->get_program_by_name($prog_name);
    $prog_id = $prog_id[0]['prog_id'];
    $academic_year = $_POST['academic_year'];
    $academic_year_id = $academic_year_obj->get_academic_year_by_name($academic_year);
    $academic_year_id = $academic_year_id[0]['academic_year_id'];
    $tb_data = array("first_name"=>$first_name,
                    "middle_name"=>$middle_name,
                    "last_name"=>$last_name,
                    "prog_id"=>$prog_id,
                    "faculty_id"=>$faculty_id,
                    "dept_id"=>$dept_id,
                    "academic_year_id"=>$academic_year_id,
                    "index_number"=>$index_number);
    $tb_primary_key = array("stud_id"=>$stud_id);
    $db_response = $student->update_student($tb_primary_key,$tb_data);
    if($db_response){
        echo json_encode(
          array("message"=>"success")
        );
    }
}

if(isset($_GET['del_student'])){
    $stud_id = $_GET['del_student'];
    $db_response = $student->delete_student($stud_id);
    if($db_response){
        echo json_encode(
        array("message"=>"success")
        );
    }
}

if(isset($_FILES['import_students'])){
    $filename=$_FILES["import_students"]["tmp_name"];
    $ext=substr($filename,strrpos($filename,"."),(strlen($filename)-strrpos($filename,".")));

//we check,file must be have csv extention
// if($ext=="csv")
// {
    $file = fopen($filename, "r");
    while (($emapData = fgetcsv($file, 10000, ",")) !== FALSE)
    {
    $sn = $emapData[0];
    $index_number = $emapData[1];
    $first_name = $emapData[2];
    $middle_name = $emapData[3];
    $last_name = $emapData[4];
    $index_number = $emapData[5];
    $academic_year = $emapData[6];
    $academic_year_id = $academic_year_obj->get_academic_year_by_name($academic_year);
    $academic_year_id = $academic_year_id[0]['academic_year_id'];
    $faculty_name = $emapData[7];
    $faculty_id = $faculty->get_faculty_by_name($faculty_name);
    $faculty_id = $faculty_id[0]['faculty_id'];
    $dept_name = $emapData[8];
    $dept_id = $department->get_department_by_name($dept_name);
    $dept_id = $dept_id[0]['dept_id'];
    $prog_name = $emapData[9];
    $prog_id = $program->get_program_by_name($prog_name);
    $prog_id = $prog_id[0]['prog_id'];
    
    //$tb_data = array("first_name"=>$emapData[1],"middle_name"=>$emapData[2],"last_name"=>$emapData[3]);
    $tb_data = array("first_name"=>$first_name,
                    "middle_name"=>$middle_name,
                    "last_name"=>$last_name,
                    "prog_id"=>$prog_id,
                    "faculty_id"=>$faculty_id,
                    "dept_id"=>$dept_id,
                    "academic_year_id"=>$academic_year_id,
                    "index_number"=>$index_number);
    $success =  $student->add_student($tb_data);
    // if ($success) {
    // echo 0;
    // }else{
    // echo 1;
    // }
    //break;
    }
    fclose($file);
}