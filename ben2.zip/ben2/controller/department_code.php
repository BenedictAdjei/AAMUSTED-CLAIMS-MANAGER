<?php
include_once '../Config/Database.php';
require_once '../Model/Department.php';
require_once '../Model/Faculty.php';

$department = new Department();
$faculty = new Faculty();

if(isset($_GET['::'])){
    $all_departments = $department->read_all_departments();
    echo json_encode(
        array("data"=>$all_departments)
    );
}

if(isset($_POST['add_dept'])){
    $dept_name = $_POST['dept_name'];
    $faculty_name = $_POST['faculty_name'];
    $faculty_id = $faculty->get_faculty_by_name($faculty_name);
    $faculty_id = $faculty_id[0]['faculty_id'];
    $tb_data = array("dept_name"=>$dept_name,
                     "faculty_id"=>$faculty_id);
    $db_response = $department->add_department($tb_data);
    if($db_response){
        echo json_encode(
          array("message"=>"success")
        );
    }
}

if(isset($_POST['edit_dept'])){
    $dept_id = $_POST['dept_id'];
    $dept_name = $_POST['dept_name'];
    $faculty_name = $_POST['faculty_name'];
    $faculty_id = $faculty->get_faculty_by_name($faculty_name);
    $faculty_id = $faculty_id[0]['faculty_id'];
    $tb_data = array("dept_name"=>$dept_name,
                     "faculty_id"=>$faculty_id);
    $tb_primary_key = array("dept_id"=>$dept_id);
    $db_response = $department->update_department($tb_primary_key,$tb_data);
    if($db_response){
        echo json_encode(
          array("message"=>"success")
        );
    }
}

if(isset($_GET['del_dept'])){
    $dept_id = $_GET['del_dept'];
    $db_response = $department->delete_department($dept_id);
    if($db_response){
        echo json_encode(
        array("message"=>"success")
        );
    }
}