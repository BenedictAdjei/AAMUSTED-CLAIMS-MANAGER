<?php
include_once '../Config/Database.php';
require_once '../Model/Payhead.php';
require_once '../Model/Claim_Type.php';
require_once '../Model/Claim_Header.php';
require_once '../Model/Degree.php';


$claim_type = new Claim_Type();
$payhead = new Payhead();
$claim_header = new Claim_Header();
$degree = new Degree();

if(isset($_GET['::'])){
    $all_payheads = $payhead->read_all_payheads();
    echo json_encode(
        array("data"=>$all_payheads)
    );
}

// if(isset($_GET['get_payhead_by_name'])){
//     $claim_type_name = $_GET['claim_type_name'];
//     $claim_type_id = $claim_type->get_claim_type_by_name($claim_type_name);
//     $claim_type_id = $claim_type_id[0]['claim_type_id'];
//     $payheads = $payhead->read_payhead_by_both_ids($dept_id,$claim_type_id);
//     echo json_encode(
//         array("data"=>$payheads)
//     );
// }


// if(isset($_GET['get_claim_type_by_name'])){
//     $claim_type_name = $_GET['claim_type_name'];
//     $claim_type_id = $claim_type->get_claim_type_by_name($claim_type_name);
//     $claim_type_id = $claim_type_id[0]['claim_type_id'];
//     $payheads_for_claim_type = $payhead->get_payhead_by_claim_type_id($claim_type_id);
//     echo json_encode(
//         array("data"=>$payheads_for_claim_type)
//     );
// }



if(isset($_POST['add_payhead'])){
    $rate = $_POST['rate'];
    $claim_type_name = $_POST['claim_type'];
    $claim_type_id = $claim_type->get_claim_type_by_name($claim_type_name);
    $claim_type_id = $claim_type_id[0]['claim_type_id'];
    $item = $_POST['item'];
    $claim_header_name = $_POST['claim_header'];
    $claim_header_id = $claim_header->get_claim_header_by_name($claim_header_name);
    $claim_header_id = $claim_header_id[0]['claim_header_id'];
    $degree_name = $_POST['degree'];
    $degree_id = $degree->get_degree_by_name($degree_name);
    $degree_id = $degree_id[0]['degree_id'];

    $tb_data = array("rate"=>$rate,
                    "claim_type_id"=>$claim_type_id,
                    "degree_type_id"=>$degree_id,
                    "claim_header_id"=>$claim_header_id,
                    "item"=>$item,
                );
    $db_response = $payhead->add_payhead($tb_data);
    if($db_response){
        echo json_encode(
          array("message"=>"success")
        );
    }
}

if(isset($_POST['edit_prog'])){
    $prog_id = $_POST['prog_id'];
    $prog_name = $_POST['prog_name'];
    $claim_type_name = $_POST['claim_type_name'];
    $claim_type_id = $claim_type->get_claim_type_by_name($claim_type_name);
    $claim_type_id = $claim_type_id[0]['claim_type_id'];
    $dept_id = $dept_id[0]['dept_id'];
    $tb_data = array("prog_name"=>$prog_name,
                    "claim_type_id"=>$claim_type_id);
    $tb_primary_key = array("prog_id"=>$prog_id);
    $db_response = $payhead->update_payhead($tb_primary_key,$tb_data);
    if($db_response){
        echo json_encode(
          array("message"=>"success")
        );
    }
}

if(isset($_GET['del_prog'])){
    $prog_id = $_GET['del_prog'];
    $db_response = $payhead->delete_payhead($prog_id);
    if($db_response){
        echo json_encode(
        array("message"=>"success")
        );
    }
}