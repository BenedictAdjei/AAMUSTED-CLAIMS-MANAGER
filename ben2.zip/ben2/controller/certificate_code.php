<?php
include_once '../Config/Database.php';
require_once '../Model/Certificate.php';
require_once '../Model/Program.php';
require_once '../Model/Student.php';

$certificate = new Certificate();
$program = new Program();
$student = new Student();

if(isset($_GET['::'])){
    $all_certificates = $certificate->read_all_certificates();
    echo json_encode(
        array("data"=>$all_certificates)
    );
}

if(isset($_POST['add_certificate'])){
    
    $academic_yr = $_POST['academic_yr'];
    $academic_yr_id = $certificate->get_academic_year_by_name($academic_yr);
    $academic_yr_id = $academic_yr_id[0]['academic_year_id'];
    $stud_name = $_POST['stud_name'];
    $stud_id = $student->get_student_by_name($stud_name);
    $stud_id = $stud_id[0]['stud_id'];
    $prog_name = $_POST['prog_name'];
    $prog_id = $program->get_program_by_name($prog_name);
    $prog_id = $prog_id[0]['prog_id'];
    $class = $_POST['class'];
    $serial = $_POST['serial'];
    $user_id = $_POST['user_id'];
    $generated_name_1 = '';
    if(isset($_FILES['picture']['name'])){
        $ext_1 = explode('.', basename($_FILES["picture"]["name"])); //explode file name from dot(.) 
        $file_extension_1 = end($ext_1); //store extensions in the variable
        $generated_name_1 .= md5(uniqid()) . "." . $ext_1[count($ext_1) - 1];
        move_uploaded_file($_FILES["picture"]["tmp_name"], "../certificates/".$generated_name_1);
      }
    $tb_data = array("academic_yr"=>$academic_yr_id,
                    "stud_id"=>$stud_id,
                    "prog_id"=>$prog_id,
                    "class"=>$class,
                    "serial"=>$serial,
                    "user_id"=>$user_id,
                    "picture"=>$generated_name_1);
    $db_response = $certificate->add_certificate($tb_data);
    if($db_response){
        echo json_encode(
          array("message"=>"success")
        );
    }
}

if(isset($_POST['edit_certificate'])){
    $cert_id = $_POST['cert_id'];
    $academic_yr = $_POST['academic_yr'];
    $academic_yr_id = $certificate->get_academic_year_by_name($academic_yr);
    $academic_yr_id = $academic_yr_id[0]['academic_year_id'];
    $stud_name = $_POST['stud_name'];
    $stud_id = $student->get_student_by_name($stud_name);
    $stud_id = $stud_id[0]['stud_id'];
    $prog_name = $_POST['prog_name'];
    $prog_id = $program->get_program_by_name($prog_name);
    $prog_id = $prog_id[0]['prog_id'];
    $class = $_POST['class'];
    $serial = $_POST['serial'];
    $generated_name_1 = $_POST['old_picture'];
    if(isset($_FILES['picture']['name'])){
        $generated_name_1 = '';
        $ext_1 = explode('.', basename($_FILES["picture"]["name"])); //explode file name from dot(.) 
        $file_extension_1 = end($ext_1); //store extensions in the variable
        $generated_name_1 .= md5(uniqid()) . "." . $ext_1[count($ext_1) - 1];
        move_uploaded_file($_FILES["picture"]["tmp_name"], "../certificates/".$generated_name_1);
      }
    $tb_data = array("academic_yr"=>$academic_yr_id,
                    "stud_id"=>$stud_id,
                    "prog_id"=>$prog_id,
                    "class"=>$class,
                    "serial"=>$serial,
                    "picture"=>$generated_name_1);;
    $tb_primary_key = array("cert_id"=>$cert_id);
    $db_response = $certificate->update_certificate($tb_primary_key,$tb_data);
    if($db_response){
        echo json_encode(
          array("message"=>"success")
        );
    }
}

if(isset($_GET['del_certificate'])){
    $cert_id = $_GET['del_certificate'];
    $db_response = $certificate->delete_certificate($cert_id);
    if($db_response){
        echo json_encode(
        array("message"=>"success")
        );
    }
}

if(isset($_GET['by_index_number'])){
    $index_number = $_GET['by_index_number'];
    $db_response = $certificate->verify_certificate_by_index_number($index_number);
    if($db_response){
        echo json_encode(
            $db_response
        );
    }else{
        echo json_encode(
            array("message"=>"fail")
        );
    }
}

if(isset($_POST['set_verification_by_index'])){
    $cert_id = $_POST['cert_id'];
    $valid = $_POST['valid'];
    $user_id = $_POST['user_id'];
    $tb_data = array("cert_id"=>$cert_id,
                     "is_index"=>1,
                     "user_id"=>$user_id,
                    "valid"=>$valid);
    $db_response = $certificate->set_verification($tb_data);
    if($db_response){
        echo json_encode(
            array("message"=>"success")
        );
    }else{
        echo json_encode(
            array("message"=>"fail")
        );
    }
}

if(isset($_GET['by_name'])){
    $name = $_GET['by_name'];
    $db_response = $certificate->verify_certificate_by_name($name);
    if($db_response){
        echo json_encode(
            $db_response
        );
    }else{
        echo json_encode(
            array("message"=>"fail")
        );
    }
}


if(isset($_POST['set_verification_by_name'])){
    $cert_id = $_POST['cert_id'];
    $valid = $_POST['valid'];
    $user_id = $_POST['user_id'];
    $tb_data = array("cert_id"=>$cert_id,
                     "is_name"=>1,
                     "user_id"=>$user_id,
                    "valid"=>$valid);
    $db_response = $certificate->set_verification($tb_data);
    if($db_response){
        echo json_encode(
            array("message"=>"success")
        );
    }else{
        echo json_encode(
            array("message"=>"fail")
        );
    }
}

if(isset($_GET['by_serial'])){
    $serial = $_GET['by_serial'];
    $db_response = $certificate->verify_certificate_by_serial($serial);
    if($db_response){
        echo json_encode(
            $db_response
        );
    }else{
        echo json_encode(
            array("message"=>"fail")
        );
    }
}


if(isset($_POST['set_verification_by_serial'])){
    $cert_id = $_POST['cert_id'];
    $valid = $_POST['valid'];
    $user_id = $_POST['user_id'];
    $tb_data = array("cert_id"=>$cert_id,
                     "is_serial"=>1,
                     "user_id"=>$user_id,
                    "valid"=>$valid);
    $db_response = $certificate->set_verification($tb_data);
    if($db_response){
        echo json_encode(
            array("message"=>"success")
        );
    }else{
        echo json_encode(
            array("message"=>"fail")
        );
    }
}