<?php
include_once '../Config/Database.php';
require_once '../Model/Course.php';
require_once '../Model/Department.php';


$course = new Course();
$department = new Department();


if(isset($_GET['::'])){
    $all_courses = $course->read_all_courses();
    echo json_encode(
        array("data"=>$all_courses)
    );
}

if(isset($_POST['add_course'])){
    $course_code = $_POST['course_code'];
    $course_title = $_POST['course_title'];
    $dept_name = $_POST['dept_name'];
    $dept_id=$department->get_department_by_name($dept_name);
    $dept_id = $dept_id[0]['dept_id'];
    $max_scripts_number = $_POST['max_scripts_number'];
    $tb_data = array("course_title"=>$course_title,
                     "course_code"=>$course_code,
                     "dept_id"=>$dept_id,
                     "max_scripts_number"=>$max_scripts_number
                    );
    $db_response = $course->add_course($tb_data);
    if($db_response){
        echo json_encode(
          array("message"=>"success")
        );
    }
}

if(isset($_POST['edit_course'])){
    $course_id = $_POST['course_id'];
    $course_code = $_POST['course_code'];
    $course_title = $_POST['course_title'];
    $dept_name = $_POST['dept_name'];
    $dept_id=$department->get_department_by_name($dept_name);
    $dept_id = $dept_id[0]['dept_id'];
    $max_scripts_number = $_POST['max_scripts_number'];
    $tb_data = array("course_title"=>$course_title,
                     "course_code"=>$course_code,
                     "dept_id"=>$dept_id,
                     "max_scripts_number"=>$max_scripts_number
                    );
    $tb_primary_key = array("course_id"=>$course_id);
    $db_response = $course->update_course($tb_primary_key,$tb_data);
    if($db_response){
        echo json_encode(
          array("message"=>"success")
        );
    }
}

if(isset($_GET['del_course'])){
    $course_id = $_GET['del_course'];
    $db_response = $course->delete_course($course_id);
    if($db_response){
        echo json_encode(
        array("message"=>"success")
        );
    }
}