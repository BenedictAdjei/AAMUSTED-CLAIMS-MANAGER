<?php
include_once '../Config/Database.php';
require_once '../Model/Claim_Header.php';
$claim_header = new Claim_Header();

if(isset($_GET['::'])){
    $all_claim_headers = $claim_header->read_all_claim_headers();
    echo json_encode(
        array("data"=>$all_claim_headers)
    );
}

if(isset($_POST['add_claim_header'])){
    $all_claim_headers = $claim_header->read_all_claim_headers();
    $claim_hr = $_POST['claim_header'];
    $isset = false;
    foreach($all_claim_headers as $claim_headers){
        if($claim_hr == $claim_headers['claim_header']){
            $isset = true;
        }
    }
    if(!$isset){
        $tb_data = array("claim_header"=>$claim_hr);
        $db_response = $claim_header->add_claim_header($tb_data);
        if($db_response){
            echo json_encode(
            array("message"=>"success")
            );
        }
    }
    
}

if(isset($_POST['edit_claim_header'])){
    $claim_header_id = $_POST['claim_header_id'];
    $claim_hr = $_POST['claim_header'];
    $tb_data = array("claim_header"=>$claim_hr);
    $tb_primary_key = array("claim_header_id"=>$claim_header_id);
    $db_response = $claim_header->update_claim_header($tb_primary_key,$tb_data);
    if($db_response){
        echo json_encode(
          array("message"=>"success")
        );
    }
}

if(isset($_GET['del_claim_header'])){
    $claim_header_id = $_GET['del_claim_header'];
    $db_response = $claim_header->delete_claim_header($claim_header_id);
    if(is_array($db_response)){
        echo json_encode(
        array("message"=>"success")
        );
    }else if(!$db_response){
        echo json_encode(
            array("message"=>"fail")
            );
    }
    
}