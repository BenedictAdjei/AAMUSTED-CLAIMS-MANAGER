<?php
session_start();
include_once '../Config/Database.php';
require_once '../Model/Certificate.php';
require_once '../Model/Program.php';
require_once '../Model/Student.php';
require_once '../Model/ExcessClaims.php';
require_once '../Model/Payhead.php';
require_once '../Model/Course.php';
require_once '../Model/Semester.php';
require_once '../Model/Degree.php';
require_once '../Model/Claim_Header.php';
require_once '../Model/Claim_Type.php';
require_once '../Model/User.php';
require_once '../Model/Department.php';



$claim_type = new Claim_Type();
$certificate = new Certificate();
$program = new Program();
$student = new Student();
$payhead = new Payhead();
$course = new Course();
$claim = new ExcessClaims();
$semes = new Semester();
$degree = new Degree();
$claim_header = new Claim_Header();
$user = new User();
$department = new Department();



if(isset($_GET['::'])){
    $role=$_SESSION['role_id'];
    if ($role=1) {
         $all_claims = $claim->read_all_excess_marking();
    echo json_encode(
        array("data"=>$all_claims)
    );
     }else{
        $user_id=$_SESSION['dept_id'];
        $all_claims = $claim->read_all_excess_marking_by_user_dept($user_id);
    echo json_encode(
        array("data"=>$all_claims)
    );} 
    
}


if(isset($_GET['get_department_by_name'])){
    $dept_name = $_GET['dept_name'];
    $dept_id = $department->get_department_by_name($dept_name);
    $dept_id = $dept_id[0]['dept_id'];
    $courses_for_department = $course->get_course_by_dept_id($dept_id);
    echo json_encode(
        array("data"=>$courses_for_department)
    );
}

if (isset($_POST['add_claim'])) {
    
    $academic_yr = $_POST['academic_yr'];
    $academic_year_id = $claim->get_academic_year_by_name($academic_yr);
    $academic_year_id = $academic_year_id[0]['academic_year_id'];
    $semester = $_POST['semester'];
    $semester_id = $semes->get_semester_by_name($semester);
    $semester_id = $semester_id[0]['semester_id'];
    $course_title = $_POST['course_title'];
    $course_id = $course->get_course_by_name($course_title);
    $course_id = $course_id[0]['course_id'];
    $max_scripts_number = $course->get_course_by_name($course_title);
    $max_scripts_number = $max_scripts_number[0]['max_scripts_number'];
    $total_scripts_marked = $_POST['total_scripts_marked'];
    $excess_number = $total_scripts_marked-$max_scripts_number;
    $degree_name = $_POST['degree'];
    $degree_id = $degree->get_degree_by_name($degree_name);
    $degree_id = $degree_id[0]['degree_id'];
    $claim_header_name = 'Excess Marking of Script';
    $claim_header_id = $claim_header->get_claim_header_by_name($claim_header_name);
    $claim_header_id = $claim_header_id[0]['claim_header_id'];
    $claim_type_name = 'Examination';
    $claim_type_id = $claim_type->get_claim_type_by_name($claim_type_name);
    $claim_type_id = $claim_type_id[0]['claim_type_id'];
    $rate = $payhead->get_rate_by_claim_header_n_type($claim_header_id);
    $rate = $rate[0]['rate'];
    $status = 1;
    $user_id = $_POST['user_id'];
    $dept_name = $_POST['dept_name'];
    $dept_id=$department->get_department_by_name($dept_name);
    $dept_id = $dept_id[0]['dept_id'];
    $amount = $rate * $excess_number;
    if ($excess_number < 0){
         $amount = 0;
     }
    // echo $amount;
//     $tb_data = array("academic_yr"=>$academic_yr_id,
//                     "sememster_id"=>$semester_id,
//                     // "course_id"=>$course_id,
//                     // "degree_id"=>$degree_id,
//                     // "total_scripts_marked"=>$total_scripts_marked,
//                     // "max_scripts_number"=>$max_script,
//                     // "rate"=>$rate,
//                     // "amount"=>$amount,
//                     // "$status"=>$status,
//                     // "user_id"=>$user_id,
//                     // "dept_id"=>$dept_id,
// );
     $db_response = $claim->add($academic_year_id,$semester_id,$course_id,$max_scripts_number,$total_scripts_marked,$degree_id,$rate,$amount,$status,$dept_id,$user_id);
    if($db_response){
        echo json_encode(
          array("message"=>"success")

        );
    }
}

if (isset($_POST['action']) && $_POST['action'] == "approve" ){
    
    $ex_id = $_POST['ex_id'];
    $status = 2;
    $tb_data = array("ex_id"=>$ex_id,
                     "status"=>$status,
                     );
    $tb_primary_key = array("ex_id"=>$ex_id);
    $db_response = $claim->update_claim($tb_primary_key,$tb_data);
    if($db_response){
        echo json_encode(
          array("message"=>"success")
        );
    }
}



if(isset($_GET['del_certificate'])){
    $cert_id = $_GET['del_certificate'];
    $db_response = $certificate->delete_certificate($cert_id);
    if($db_response){
        echo json_encode(
        array("message"=>"success")
        );
    }
}
