<?php
session_start();
include_once '../Config/Database.php';
require_once '../Model/User.php';
require_once '../Model/Department.php';
require_once '../Model/Faculty.php';

$department = new Department();
$faculty = new Faculty();
$user = new User();

if(isset($_GET['::'])){
    $users = $user->read_all_users();
    echo json_encode(
        array("data"=>$users)
    );
}
if(isset($_GET['r'])){
    $roles = $user->read_all_roles();
    echo json_encode(
        array("data"=>$roles)
    );
}

if(isset($_POST['add_role'])){
    $role_name = $_POST['role_name'];
    $tbData = array("role_name"=>$role_name);
    $dbResponse = $user->add_role($tbData);
    if($dbResponse){
        echo json_encode(
            array("message"=>"success")
        );
    }else{
        echo json_encode(
            array("message"=>"fail")
        );
    }
}

if(isset($_POST['edit_role'])){
    $role_id = $_POST['role_id'];
    $role_name = $_POST['role_name'];
    $tbData = array("role_name"=>$role_name);
    $tb_primary_keys = array("role_id"=>$role_id);
    $dbResponse = $user->update_role($tb_primary_keys,$tbData);
    if($dbResponse){
        echo json_encode(
            array("message"=>"success")
        );
    }else{
        echo json_encode(
            array("message"=>"fail")
        );
    }
}

if(isset($_GET['del_role'])){
    $role_id = $_GET['del_role'];
    $dbResponse = $users = $user->delete_role($role_id);
    if($dbResponse){
        echo json_encode(
            array("message"=>"success")
        );
    }else{
        echo json_encode(
            array("message"=>"fail")
        );
    }
}

if(isset($_POST['add_user'])){
    $user_name = $_POST['user_name'];
    $name = $_POST['name'];
    $user_password = $_POST['user_password'];
    $role_name = $_POST['role_name'];
    $role_name = $user->get_role_by_name($role_name);
    $role_id = $role_name[0]['role_id'];
    $staff_id = $_POST['staff_id'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $dept_name = $_POST['dept_name'];
    $dept_id = $department->get_department_by_name($dept_name);
    $dept_id = $dept_id[0]['dept_id'];
    $faculty_name = $_POST['faculty_name'];
    $faculty_id = $faculty->get_faculty_by_name($faculty_name);
    $faculty_id = $faculty_id[0]['faculty_id'];
    $tbData = array("user_name"=>$user_name,
                    "name"=>$name,
                    "user_password"=>$user_password,
                    "role_id"=>$role_id,
                    "dept_id"=>$dept_id,
                    "faculty_id"=>$faculty_id,
                    "email"=>$email,
                    "phone"=>$phone,
                    "staff_id"=>$staff_id
                );
    $dbResponse = $user->add_user($tbData);
    if($dbResponse){
        echo json_encode(
            array("message"=>"success")
        );
    }else{
        echo json_encode(
            array("message"=>"fail")
        );
    }

}

if(isset($_POST['edit_user'])){
    $user_id = $_POST['user_id'];
    $name = $_POST['name'];
    $user_name = $_POST['user_name'];
    $user_password = $_POST['user_password'];
    $role_name = $_POST['role_name'];
    $role_name = $user->get_role_by_name($role_name);
    $role_id = $role_name[0]['role_id'];  
    $tbData = array("user_name"=>$user_name,
                    "name"=>$name,
                    "user_password"=>$user_password,
                    "role_id"=>$role_id
                );
    $tb_primary_keys = array("user_id"=>$user_id);
    $dbResponse = $user->update_user($tb_primary_keys,$tbData);
    if($dbResponse){
        echo json_encode(
            array("message"=>"success")
        );
    }else{
        echo json_encode(
            array("message"=>"fail")
        );
    }
    
}

if(isset($_GET['del_user'])){
    $user_id = $_GET['del_user'];
    $dbResponse = $users = $user->delete_user($user_id);
    if($dbResponse){
        echo json_encode(
            array("message"=>"success")
        );
    }else{
        echo json_encode(
            array("message"=>"fail")
        );
    }
}

if(isset($_GET['auth'])){
    $user_name = $_GET['user_name'];
    $user_password = $_GET['user_password'];
    $dbResponse = $user->auth($user_name,$user_password);
    if($dbResponse){
        echo json_encode(
            array("message"=>"success")
        );
        $state = 'success';
        $log_state = "Login";
        $tbData = array("state"=>$log_state,
                        "user_id"=>$dbResponse[0]['user_id']);
        $user->set_log($tbData);

        // $tbData2 = array("state"=>$state,
        //                 "user_name"=>$user_name,
        //                 "user_password"=>$user_password);
        // $user->set_attempt_log($tbData2);

        $tbData3 = array("user_id"=>$dbResponse[0]['user_id']);
        $user->delete_user_login($dbResponse[0]['user_id']);
        $user->set_login($tbData3);

        $_SESSION['user_id'] = $dbResponse[0]['user_id'];
        $_SESSION['user_name'] = $dbResponse[0]['user_name'];
        $_SESSION['name'] = $dbResponse[0]['name'];
        $_SESSION['role_name'] = $dbResponse[0]['role_name'];
        $_SESSION['role_id'] = $dbResponse[0]['role_id'];
        $_SESSION['dept_id'] = $dbResponse[0]['dept_id'];
    }else{
        $state = 'fail';
        $tbData = array("state"=>$state,
                        "user_name"=>$user_name,
                        "user_password"=>$user_password);
         $user->set_attempt_log($tbData);
        echo json_encode(
            array("message"=>"fail")
        );
    }
}

if(isset($_GET['logout'])){
    $log_state = "Logout";
        $tbData = array("state"=>$log_state,
                        "user_id"=>$_SESSION['user_id']);
        $user->set_log($tbData);

        $user->delete_user_login($_SESSION['user_id']);
    session_start();
    session_unset();
    session_destroy();

    header("location:../index.php");
}

if(isset($_POST['set_permission'])){
    $role_id = $_POST['role_id'];
    $system_permission_id = $_POST['system_permission_id'];
    $isset = $user->delete_permissions_for_role($role_id);
    $dbResponse = false;
    
        foreach($system_permission_id as $id){
            $tbData = array("role_id"=>$role_id,
                            "system_permission_id"=>$id);
        $dbResponse = $user->set_permission($tbData);
        }
    
    
    
    
    if($dbResponse){
        echo json_encode(
            array("message"=>"success")
        );
    }else{
        echo json_encode(
            array("message"=>"fail")
        );
    }
}