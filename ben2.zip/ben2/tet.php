<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<?php include 'inc/styles_inc.php' ?>
	
		
</head>
<body class="container">
	<div>		
		<h1 class="section-title" style="font-size: 24px; margin-top: 20px; margin-bottom: 10px; font-family: 'Roboto Slab', 'Trebuchet MS', sans-serif; font-weight: 600; line-height: 1.2; color: #018C40; font-style: normal; letter-spacing: -0.1px;">Upcoming &amp; Past Events</h1>
			<div class="events-block mb-36 grid-container lt-3" style="-webkit-box-orient: horizontal; -webkit-box-direction: normal; flex-flow: row wrap; display: flex; margin-right: -24px; color: #ffffff; font-family: Roboto, 'Helvetica Neue', Arial, sans-serif; letter-spacing: -0.1px;  margin-bottom: 36px !important;">
			<article class="card grid-item aos-init aos-animate" style="box-shadow: rgba(0, 0, 0, 0.2) 0px 3px 1px -2px, rgba(0, 0, 0, 0.14) 0px 2px 2px 0px, rgba(0, 0, 0, 0.12) 0px 1px 5px 0px; transform: translate3d(0px, 0px, 0px); -webkit-box-flex: 1; flex: 1 1 calc(25% - 24px); margin-bottom: 24px; margin-right: 24px; -webkit-box-orient: vertical; -webkit-box-direction: normal; opacity: 1; transition: opacity 0.5s cubic-bezier(0.25, 0.1, 0.25, 1) 0.1s, transform 0s ease 0s, -webkit-transform 0s ease 0s, -o-transform 0s ease 0s; max-width: calc(25% - 24px);">
			<div class="ft-event-item past-event">
				<figure class="card-image" style="margin-bottom: 0px; position: relative; z-index: 1; overflow: hidden;">
					<a style="color: #2c2b7c;">
						<img class="image-style-card-534x534" style="border-width: 0px; min-width: 100%; transition-duration: 1s; filter: grayscale(100%);"src="#" alt="pic" width="534" height="534" />
					</a>
				</figure>
				<div class="card-content text-center" style="padding: 24px; position: relative; z-index: 2; color: #3f3f3f !important;">
					<div class="mb-12 event-date px-8 py-4 border-radius-4 flex flex-jc-space-between" style="display: flex; border-radius: 4px; -webkit-box-pack: justify; justify-content: space-between; margin-bottom: 12px !important; padding: 4px 8px !important;">
						<div class="p-12 pt-8 grey-800 border-radius-4 line-height-1 flex flex-column flex-ai-center flex-jc-center elevation-z2" style="display: flex; box-shadow: rgba(0, 0, 0, 0.2) 0px 3px 1px -2px, rgba(0, 0, 0, 0.14) 0px 2px 2px 0px, rgba(0, 0, 0, 0.12) 0px 1px 5px 0px; border-radius: 4px; line-height: 1; -webkit-box-orient: vertical; -webkit-box-direction: normal; -webkit-box-pack: center; justify-content: center; -webkit-box-align: center; align-items: center; padding: 8px 12px 12px !important; background-color: #424242 !important; color: #ffffff !important;"><span class="grey-500-fg mb-4 font-size-12" style="font-size: 12px; margin-bottom: 4px !important; color: #9e9e9e !important;">Past Event</span>
							<div class="text-bold grey-600-fg" style="font-weight: bold; color: #757575 !important;"><time class="datetime" datetime="00Z">Wed, Nov 10</time></div>
						</div>
					</div>
						<h3 class="mb-12" style="font-family: 'Roboto Slab', 'Trebuchet MS', sans-serif; font-weight: 600; margin-bottom: 0px; font-size: 16px; color: #1e1e1e !important; text-transform: initial !important;"><a style="transition-timing-function: ease-in-out; margin: 0px; color: #1e1e1e !important;" href="#">Workshop on Investigation</a></h3>
					<div class="line-height-1" style="line-height: 1;">
						<div class="grey-500-fg" style="color: #9e9e9e !important;">venue</div>
						<div class="event-venue">Conference</div>
					</div>
				</div>
			</div>
		</article>
		<article class="card grid-item aos-init aos-animate" style="background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; box-shadow: rgba(0, 0, 0, 0.2) 0px 3px 1px -2px, rgba(0, 0, 0, 0.14) 0px 2px 2px 0px, rgba(0, 0, 0, 0.12) 0px 1px 5px 0px; transform: translate3d(0px, 0px, 0px); -webkit-box-flex: 1; flex: 1 1 calc(25% - 24px); margin-bottom: 24px; margin-right: 24px; -webkit-box-orient: vertical; -webkit-box-direction: normal; opacity: 1; transition: opacity 0.5s cubic-bezier(0.25, 0.1, 0.25, 1) 0.2s, transform 0s ease 0s, -webkit-transform 0s ease 0s, -o-transform 0s ease 0s; max-width: calc(25% - 24px);" data-aos="fade-up" data-aos-delay="200" data-aos-duration="500">
		<div class="ft-event-item past-event">
				<figure class="card-image" style="margin-bottom: 0px; position: relative; z-index: 1; overflow: hidden;">
					<a style="color: #2c2b7c;" href="#">
						<img class="image-style-card-534x534" style="border-width: 0px; border-style: initial; min-width: 100%; transition-duration: 1s; transition-timing-function: linear; transform: scale(1); filter: grayscale(100%);" src="#" alt="" width="534" height="534" /></a>
				</figure>
			<div class="card-content text-center" style="padding: 24px; position: relative; z-index: 2; color: #3f3f3f !important;">
				<div class="mb-12 event-date px-8 py-4 border-radius-4 flex flex-jc-center" style="display: flex; border-radius: 4px; -webkit-box-pack: center; justify-content: center; margin-bottom: 12px !important; padding: 4px 8px !important;">
					<div class="p-12 pt-8 grey-800 border-radius-4 line-height-1 flex flex-column flex-ai-center flex-jc-center elevation-z2" style="display: flex; box-shadow: rgba(0, 0, 0, 0.2) 0px 3px 1px -2px, rgba(0, 0, 0, 0.14) 0px 2px 2px 0px, rgba(0, 0, 0, 0.12) 0px 1px 5px 0px; border-radius: 4px; line-height: 1; -webkit-box-orient: vertical; -webkit-box-direction: normal; -webkit-box-pack: center; justify-content: center; -webkit-box-align: center; align-items: center; padding: 8px 12px 12px !important; background-color: #424242 !important; color: #ffffff !important;">
						<span class="grey-500-fg mb-4 font-size-12" style="font-size: 12px; margin-bottom: 4px !important; color: #9e9e9e !important;">Past Event</span>
						<div class="text-bold grey-600-fg" style="font-weight: bold; color: #757575 !important;"><time class="datetime" datetime="00Z">Wed, Nov 03</time>
						</div>
					</div>
				</div>
				<h3 class="mb-12" style="font-family: 'Roboto Slab', 'Trebuchet MS', sans-serif; font-weight: 600; margin-bottom: 0px; font-size: 16px; color: #1e1e1e !important; text-transform: initial !important;"><a style="transition-timing-function: ease-in-out; margin: 0px; color: #1e1e1e !important;" href="#">Carrer Fair</a></h3>
				<div class="line-height-1" style="line-height: 1;">
					<div class="grey-500-fg" style="color: #9e9e9e !important;">venue</div>
					<div class="event-venue">Assembly Hall</div>
				</div>
			</div>
		</div>
		</article>
		<article class="card grid-item aos-init aos-animate" style="background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; box-shadow: rgba(0, 0, 0, 0.2) 0px 3px 1px -2px, rgba(0, 0, 0, 0.14) 0px 2px 2px 0px, rgba(0, 0, 0, 0.12) 0px 1px 5px 0px; transform: translate3d(0px, 0px, 0px); -webkit-box-flex: 1; flex: 1 1 calc(25% - 24px); margin-bottom: 24px; margin-right: 24px; -webkit-box-orient: vertical; -webkit-box-direction: normal; opacity: 1; transition: opacity 0.5s cubic-bezier(0.25, 0.1, 0.25, 1) 0.3s, transform 0s ease 0s, -webkit-transform 0s ease 0s, -o-transform 0s ease 0s; max-width: calc(25% - 24px);" data-aos="fade-up" data-aos-delay="300" data-aos-duration="500">
		<div class="ft-event-item past-event">
			<figure class="card-image" style="margin-bottom: 0px; position: relative; z-index: 1; overflow: hidden;">
				<a style="color: #2c2b7c; transition-timing-function: ease-in-out;" href="#">
					<img class="image-style-card-534x534" style="border-width: 0px; border-style: initial; min-width: 100%; transition-duration: 1s; transition-timing-function: linear; transform: scale(1); filter: grayscale(100%);" src="#" alt=" Prof. Ernest Aryeetey" width="534" height="534" />
				</a>
			</figure>
		<div class="card-content text-center" style="padding: 24px; position: relative; z-index: 2; color: #3f3f3f !important;">
			<div class="mb-12 event-date px-8 py-4 border-radius-4 flex flex-jc-center" style="display: flex; border-radius: 4px; -webkit-box-pack: center; justify-content: center; margin-bottom: 12px !important; padding: 4px 8px !important;">
				<div class="p-12 pt-8 grey-800 border-radius-4 line-height-1 flex flex-column flex-ai-center flex-jc-center elevation-z2" style="display: flex; box-shadow: rgba(0, 0, 0, 0.2) 0px 3px 1px -2px, rgba(0, 0, 0, 0.14) 0px 2px 2px 0px, rgba(0, 0, 0, 0.12) 0px 1px 5px 0px; border-radius: 4px; line-height: 1; -webkit-box-orient: vertical; -webkit-box-direction: normal; -webkit-box-pack: center; justify-content: center; -webkit-box-align: center; align-items: center; padding: 8px 12px 12px !important; background-color: #424242 !important; color: #ffffff !important;">
					<span class="grey-500-fg mb-4 font-size-12" style="font-size: 12px; margin-bottom: 4px !important; color: #9e9e9e !important;">Past Event</span>
				<div class="text-bold grey-600-fg" style="font-weight: bold; color: #757575 !important;"><time class="datetime" datetime="00Z">Thu, Aug 19</time></div>
				</div>
			</div>
				<h3 class="mb-12" style="font-family: 'Roboto Slab', 'Trebuchet MS', sans-serif; font-weight: 600; margin-bottom: 0px; font-size: 16px; color: #1e1e1e !important; text-transform: initial !important;"><a style="transition-timing-function: ease-in-out; margin: 0px; color: #1e1e1e !important;" href="#" hreflang="en">Conference on Funded Research and Innovation</a></h3>
					<div class="line-height-1" style="line-height: 1;">
						<div class="grey-500-fg" style="color: #9e9e9e !important;">venue</div>
						<div class="event-venue">KAC Assembly Hall</div>
					</div>
				</div>
			</div>
		</article>
		<article class="card grid-item aos-init aos-animate" style="box-shadow: rgba(0, 0, 0, 0.2) 0px 3px 1px -2px, rgba(0, 0, 0, 0.14) 0px 2px 2px 0px, rgba(0, 0, 0, 0.12) 0px 1px 5px 0px; -webkit-box-flex: 1; flex: 1 1 calc(25% - 24px); margin-bottom: 24px; margin-right: 24px; -webkit-box-orient: vertical; -webkit-box-direction: normal; opacity: 1; transition: opacity 0.5s cubic-bezier(0.25, 0.1, 0.25, 1) 0.4s, transform 0s ease 0s, -webkit-transform 0s ease 0s, -o-transform 0s ease 0s; max-width: calc(25% - 24px);" data-aos="fade-up" data-aos-delay="400" data-aos-duration="500">
				<div class="ft-event-item past-event">
					<figure class="card-image" style="margin-bottom: 0px; position: relative; z-index: 1; overflow: hidden;">
						<a style="color: #2c2b7c; transition-timing-function: ease-in-out;" href="http://pilot.uew.edu.gh/events/second-interdenominational-church-service-first-semester-20202021-academic-year" hreflang="en">
							<img class="image-style-card-534x534" style="border-width: 0px; border-style: initial; min-width: 100%; transition-duration: 1s; transition-timing-function: linear; transform: scale(1); filter: grayscale(100%);" src="#" alt="Second Interdenominational Church Service" width="534" height="534" /></a>
					</figure>
				<div class="card-content text-center" style="padding: 24px; position: relative; z-index: 2; color: #3f3f3f !important;">
					<div class="mb-12 event-date px-8 py-4 border-radius-4 flex flex-jc-center" style="display: flex; border-radius: 4px; -webkit-box-pack: center; justify-content: center; margin-bottom: 12px !important; padding: 4px 8px !important;">
						<div class="p-12 pt-8 grey-800 border-radius-4 line-height-1 flex flex-column flex-ai-center flex-jc-center elevation-z2" style="display: flex; box-shadow: rgba(0, 0, 0, 0.2) 0px 3px 1px -2px, rgba(0, 0, 0, 0.14) 0px 2px 2px 0px, rgba(0, 0, 0, 0.12) 0px 1px 5px 0px; border-radius: 4px; line-height: 1; -webkit-box-orient: vertical; -webkit-box-direction: normal; -webkit-box-pack: center; justify-content: center; -webkit-box-align: center; align-items: center; padding: 8px 12px 12px !important; background-color: #424242 !important; color: #ffffff !important;"><span class="grey-500-fg mb-4 font-size-12" style="font-size: 12px; margin-bottom: 4px !important; color: #9e9e9e !important;">Past Event</span>
						<div class="text-bold grey-600-fg" style="font-weight: bold; color: #757575 !important;"><time class="datetime" datetime="00Z">Sun, Sep 11</time></div>
						</div>
					</div>
					<h3 class="mb-12" style="font-family: 'Roboto Slab', 'Trebuchet MS', sans-serif; font-weight: 600; margin-bottom: 0px; font-size: 16px; color: #1e1e1e !important; text-transform: initial !important;"><a style="margin: 0px; color: #1e1e1e !important;" href="#">Second Interdenominational Church Service | First Semester, 2020/2021 Academic Year</a></h3>
						<div class="line-height-1" style="line-height: 1;">
							<div class="grey-500-fg" style="color: #9e9e9e !important;">venue</div>
							<div class="event-venue">Assembly Hall</div>
						</div>
					</div>
				</div>
			</article>
		</div>
			<div class="action-link-button" style="display: flex; -webkit-box-align: center; align-items: center; -webkit-box-pack: center; justify-content: center; color: #ffffff; font-family: Roboto, 'Helvetica Neue', Arial, sans-serif; letter-spacing: -0.1px; ">
				<div class="more-link" style="text-align: right;">
					<a style="background: #ffffff; color: #018C40; text-decoration-line: underline; transition-timing-function: ease-in-out; outline: none; outline-offset: -2px; margin: 0px 0px 10px; display: block; padding: 12px 36px; font-size: 15px; text-align: left; text-transform: uppercase; font-weight: bold; border-radius: 5px; box-shadow: rgba(0, 0, 0, 0.2) 0px 3px 1px -2px, rgba(0, 0, 0, 0.14) 0px 2px 2px 0px, rgba(0, 0, 0, 0.12) 0px 1px 5px 0px;" href="#">SEE MORE EVENTS</a>
				</div>
			</div>
</body>
</html>	



