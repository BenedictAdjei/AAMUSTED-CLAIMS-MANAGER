<!DOCTYPE html>

<html lang="en">
    
<head>
        <?php include 'controller/php_inc/user_inc_code.php' ?>
        <?php include 'inc/meta_inc.php' ?>
        <!-- base css -->
        <?php include 'inc/styles_inc.php' ?>
        <link rel="stylesheet" media="screen, print" href="css/statistics/chartist/chartist.css">
        <link rel="stylesheet" media="screen, print" href="css/formplugins/bootstrap-datepicker/bootstrap-datepicker.css">
        <link rel="stylesheet" media="screen, print" href="css/statistics/c3/c3.css">
        <style>
.select2-selection__rendered {
    line-height: 32px !important;
}
.select2-container .select2-selection--single {
    height: 39px !important;
}
.select2-selection__arrow {
    height: 35px !important;
}

    


        </style>
</head>
    <body class="mod-bg-1 ">
        <!-- DOC: script to save and load page settings -->
        <script>
    
            /**
             *	This script should be placed right after the body tag for fast execution 
            *	Note: the script is written in pure javascript and does not depend on thirdparty library
            **/
            'use strict';

            var classHolder = document.getElementsByTagName("BODY")[0],
                /** 
                 * Load from localstorage
                 **/
                themeSettings = (localStorage.getItem('themeSettings')) ? JSON.parse(localStorage.getItem('themeSettings')) :
                {},
                themeURL = themeSettings.themeURL || '',
                themeOptions = themeSettings.themeOptions || '';
            /** 
             * Load theme options
             **/
            if (themeSettings.themeOptions)
            {
                classHolder.className = themeSettings.themeOptions;
                console.log("%c✔ Theme settings loaded", "color: #148f32");
            }
            else
            {
                console.log("Heads up! Theme settings is empty or does not exist, loading default settings...");
            }
            if (themeSettings.themeURL && !document.getElementById('mytheme'))
            {
                var cssfile = document.createElement('link');
                cssfile.id = 'mytheme';
                cssfile.rel = 'stylesheet';
                cssfile.href = themeURL;
                document.getElementsByTagName('head')[0].appendChild(cssfile);
            }
            /** 
             * Save to localstorage 
             **/
            var saveSettings = function()
            {
                themeSettings.themeOptions = String(classHolder.className).split(/[^\w-]+/).filter(function(item)
                {
                    return /^(nav|header|mod|display)-/i.test(item);
                }).join(' ');
                if (document.getElementById('mytheme'))
                {
                    themeSettings.themeURL = document.getElementById('mytheme').getAttribute("href");
                };
                localStorage.setItem('themeSettings', JSON.stringify(themeSettings));
            }
            /** 
             * Reset settings
             **/
            var resetSettings = function()
            {
                localStorage.setItem("themeSettings", "");
            }

        </script>
        <!-- BEGIN Page Wrapper -->
        <div class="page-wrapper">
            <div class="page-inner">
                <!-- BEGIN Left Aside -->
                <?php include 'inc/aside_inc.php' ?>
                <!-- END Left Aside -->
                <div class="page-content-wrapper">
                    <!-- BEGIN Page Header -->
                    <?php include 'inc/header_inc.php' ?>    
                    <!-- END Page Header -->
                    <!-- BEGIN Page Content -->
                    <!-- the #js-page-content id is needed for some plugins to initialize -->
                    <main id="js-page-content" role="main" class="page-content">
                        <ol class="breadcrumb page-breadcrumb"> 
                            <li class="breadcrumb-item"><a href="javascript:void(0);">FlairTech Admin</a></li>
                            <li class="breadcrumb-item">Report</li>
                            <li class="position-absolute pos-top pos-right d-none d-sm-block"><span class="js-get-date"></span></li>
                        </ol>
                        

                        <div class="row">
                            <div class="col-xl-4">
                                <div id="panel-1" class="panel">
                                    <div class="panel-hdr">
                                        <h2>
                                        View All Logs Report:
                                        </h2>
                                        
                                    </div>
                                    <div class="panel-container show">
                                        <div class="panel-content">
                                            <div class="form-group"><div class="input-group">
                                                    <select class="custom-select"  aria-label="usertype">
                                                        <option value="" selected="">All</option>
                                                    </select>
                                                    <div class="input-group-append">
                                                        <button type="button" id="generate_all" class="btn btn-success shadow-0" >Search</button>    
                                                    </div>
                                                    

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4">
                                <div id="panel-1" class="panel">
                                    <div class="panel-hdr">
                                        <h2>
                                        View Logs By Date Range:
                                        </h2>
                                        
                                    </div>
                                    <div class="panel-container show">
                                        <div class="panel-content">
                                            <div class="form-group"><div class="input-group">
                                                    <div class="input-daterange input-group" id="datepicker-5">
                                                        <input type="text" class="form-control" id="start" name="start">
                                                        <div class="input-group-append input-group-prepend">
                                                            <span class="input-group-text fs-xl"><i class="fal fa-ellipsis-h"></i></span>
                                                        </div>
                                                        <input type="text" class="form-control" id="end" name="end">
                                                        <div class="input-group-append">
                                                        <button type="button" id="generate_dr" class="btn btn-info shadow-0">Search</button>    
                                                    </div>
                                                    </div>
                                                    
                                                    

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4">
                                <div id="panel-1" class="panel">
                                    <div class="panel-hdr">
                                        <h2>
                                        View Logs By User:
                                        </h2>
                                        
                                    </div>
                                    <div class="panel-container show">
                                        <div class="panel-content">
                                            <div class="form-group">
                                                <div class="input-group">
                                                <select class="custom-select" id="user_search" aria-label="usertype">
                                                        <option value="" selected="">Select User</option>
                                                        <?php foreach($users as $_user): ?>
                                                            <option value="<?php echo $_user['user_id'] ?>"><?php echo $_user['name'] ?> | <?php echo $_user['role_name'] ?></option>
                                                        <?php endforeach ?>
                                                    </select>
                                                    <div class="input-group-append">
                                                        <button type="button" id="generate_u" class="btn btn-info shadow-0">Search</button>    
                                                    </div>
                                                    
                                                    

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php

                        if(isset($_GET['::'])){
                            $generated_history_report = $login_history_report;    
                        }

                        if(isset($_GET['gen_u'])){
                            $user_id = $_GET['gen_u'];
                            $generated_history_report = $user->login_history_report_by_user($user_id);    
                        }

                        if(isset($_GET['gen_s'])&&isset($_GET['gen_e'])){
                            $start = $_GET['gen_s'];
                            $con_start = date("Y-m-d H:i:s", strtotime($start));
                            $start = $con_start;
                            $end = $_GET['gen_e'];
                            $con_end = date("Y-m-d H:i:s", strtotime($end));
                            $end = $con_end;
                           $generated_history_report = $user->login_history_report_by_date($start,$end);
                        }

                        ?>
                        
                        <?php $total_log = 0; ?>
                            <?php $count_Login = 0; ?>
                            <?php $count_Logout = 0; ?>                                   
                        <?php if($generated_history_report): ?>
                            <?php $total_log = 0; ?>
                            <?php $count_Login = 0; ?>
                            <?php $count_Logout = 0; ?>
                            <?php foreach($generated_history_report as $log): ?>
                                <?php
                                    if($log['state'] == "Login"){
                                        $count_Login ++;
                                    }else{
                                        $count_Logout ++;
                                    }
                                ?>
                                <?php $total_log ++; ?>
                            <?php endforeach ?>
                            <div class="row">
                            <div class="col-sm-4">
                                <div class="p-3 bg-primary-300 rounded overflow-hidden position-relative text-white mb-g">
                                    <div class="">
                                        <h3 class="display-4 d-block l-h-n m-0 fw-500">
                                            <?php echo $total_log ?>
                                            <small class="m-0 l-h-n">Total Number Of Logs</small>
                                        </h3>
                                    </div>
                                    <i class="fal fa-book position-absolute pos-right pos-bottom opacity-15 mb-n1 mr-n1" style="font-size:6rem"></i>
                                </div>
                            </div>

                            <div class="col-sm-4">
                                <div class="p-3 bg-success-300 rounded overflow-hidden position-relative text-white mb-g">
                                    <div class="">
                                        <h3 class="display-4 d-block l-h-n m-0 fw-500">
                                        <?php echo $count_Login ?>
                                            <small class="m-0 l-h-n">Total Number Of Log In</small>
                                        </h3>
                                    </div>
                                    <i class="fal fa-book position-absolute pos-right pos-bottom opacity-15 mb-n1 mr-n1" style="font-size:6rem"></i>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="p-3 bg-danger-300 rounded overflow-hidden position-relative text-white mb-g">
                                    <div class="">
                                        <h3 class="display-4 d-block l-h-n m-0 fw-500">
                                        <?php echo $count_Logout ?>
                                            <small class="m-0 l-h-n">Total Number Of Log Out</small>
                                        </h3>
                                    </div>
                                    <i class="fal fa-book position-absolute pos-right pos-bottom opacity-15 mb-n1 mr-n1" style="font-size:6rem"></i>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xl-12">
                                <div id="panel-1" class="panel">
                                    <div class="panel-hdr bg-primary-700 bg-success-gradient">
                                        <h2>
                                        Generated Report
                                        </h2>
                                        
                                    </div>
                                    <div class="panel-container show">
                                        <div class="panel-content">
                                            
                                        <div class="row">
                                                <div class="col-xl-12">
                                                <table id="dt-basic-example" class="table  table-bordered table-hover table-striped w-100">
                                                            <thead>
                                                            <tr>
                                                                    <th>User</th>
                                                                    <th>Role</th>
                                                                    <th>State</th>
                                                                    <th>Date</th>
                                                                    
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                            <?php $i=0; ?>
                                                    <?php foreach($generated_history_report as $log): ?>
                                                        <?php 
                                                           $state = $log['state'];
                                                            if($state=="Login"){
                                                                $state = '<span class="badge badge-success badge-pill">Login</span>';
                                                            }else{
                                                                $state = '<span class="badge badge-danger badge-pill">Logout</span>';
                                                            }
                                                            $role_name = $user->read_role($log['role_id']);
                                                            $date = date_create($log['date_created']);
                                                        ?>
                                                        <?php $i++; ?>
                                                        <tr>
                                                                    <td><?php echo $log['name']; ?></td>
                                                                    <td><?php echo $role_name[0]['role_name']; ?></td>
                                                                    <td><?php echo $state; ?></td>
                                                                    <td><?php echo date_format($date, 'g:ia \o\n l jS F Y') ?></td>    
                                                                </tr>
                                                    <?php endforeach ?>
                                                        
                                                                
                                                                
                                                                </tbody>
                                                    </table>
                                                </div>
                                            
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xl-6">
                                <div id="panel-9" class="panel">
                                    <div class="panel-hdr bg-primary-700 bg-success-gradient">
                                        <h2>
                                        Login <span class="fw-300"><i>History</i></span>
                                        </h2>
                                        <div class="panel-toolbar">
                                            <button class="btn btn-panel" data-action="panel-collapse" data-toggle="tooltip" data-offset="0,10" data-original-title="Collapse"></button>
                                            <button class="btn btn-panel" data-action="panel-fullscreen" data-toggle="tooltip" data-offset="0,10" data-original-title="Fullscreen"></button>
                                            <button class="btn btn-panel" data-action="panel-close" data-toggle="tooltip" data-offset="0,10" data-original-title="Close"></button>
                                        </div>
                                    </div>
                                    <div class="panel-container show">
                                        <div class="panel-content">
                                            
                                            <div id="pieChart" style="width:100%; height:300px;"></div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php if($online_users): ?>
                            
                            <?php endif ?>
                        </div>
                        <?php else: ?>
                            <div class="alert border-danger bg-transparent text-secondary fade show" role="alert">
                                <div class="d-flex align-items-center">
                                    <div class="alert-icon">
                                        <span class="icon-stack icon-stack-md">
                                            <i class="base-7 icon-stack-3x color-danger-900"></i>
                                            <i class="fal fa-times icon-stack-1x text-white"></i>
                                        </span>
                                    </div>
                                    <div class="flex-1">
                                        <span class="h5 color-danger-900">No Log Records Available </span>
                                    </div>
                                    
                                </div>
                            </div>
                        <?php endif ?>                            
                        <div id="panel-2" class="panel panel-collapsed">
                            <div class="panel-hdr text-success">
                                
                                
                            </div>
                            <div class="panel-container collapse">
                                <div class="panel-content">
                                   
                                </div>
                            </div>
                        </div>   
                        <?php if($login_attempts_report): ?>
                        <div class="row">
                            <div class="col-xl-12">
                                <div id="panel-1" class="panel">
                                    <div class="panel-hdr bg-primary-700 bg-success-gradient">
                                        <h2>
                                        Probable Hack Attempts
                                        </h2>
                                        
                                    </div>
                                    <div class="panel-container show">
                                        <div class="panel-content">
                                            
                                        <div class="row">
                                                <div class="col-xl-12">
                                                <table id="dt-basic-example2" class="table  table-bordered table-hover table-striped w-100">
                                                            <thead>
                                                            <tr>
                                                                    <th>Attempted Username</th>
                                                                    <th>Attempted Password</th>
                                                                    <th>State</th>
                                                                    <th>Date</th>
                                                                    
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                            <?php $i=0; ?>
                                                    <?php foreach($login_attempts_report as $log): ?>
                                                        <?php 
                                                           $state = $log['state'];
                                                            if($state=="success"){
                                                                $state = '<span class="badge badge-success badge-pill">Successful</span>';
                                                            }else{
                                                                $state = '<span class="badge badge-danger badge-pill">Failed</span>';
                                                            }
                                                            $date = date_create($log['date_created']);
                                                        ?>
                                                        <?php $i++; ?>
                                                        <tr>
                                                                    <td><?php echo $log['user_name']; ?></td>
                                                                    <td><?php echo $log['user_password']; ?></td>
                                                                    <td><?php echo $state; ?></td>
                                                                    <td><?php echo date_format($date, 'g:ia \o\n l jS F Y') ?></td>    
                                                                </tr>
                                                    <?php endforeach ?>
                                                        
                                                                
                                                                
                                                                </tbody>
                                                    </table>
                                                </div>
                                            
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endif ?>
                    </main>
                    <!-- this overlay is activated only when mobile menu is triggered -->
                    <div class="page-content-overlay" data-action="toggle" data-class="mobile-nav-on"></div> <!-- END Page Content -->
                    <!-- BEGIN Page Footer -->
                <?php include 'inc/footer_inc.php' ?>
        <script src="js/vendors.bundle.js"></script>
        <script src="js/app.bundle.js"></script>
        <script src="js/statistics/d3/d3.js"></script>
        <script src="js/statistics/c3/c3.js"></script>
        <script src="js/statistics/demo-data/demo-c3.js"></script>
        <script src="js/select2.bundle.js"></script>
        
        <script src="js/datagrid/datatables/datatables2.bundle.js"></script>
        <script src="js/notifications/sweetalert2/sweetalert2.bundle.js"></script>
        <script src="js/datagrid/datatables/datatables.export.js"></script>
        <script src="js/formplugins/bootstrap-datepicker/bootstrap-datepicker.js"></script>
        <script>
             var controls = {
                leftArrow: '<i class="fal fa-angle-left" style="font-size: 1.25rem"></i>',
                rightArrow: '<i class="fal fa-angle-right" style="font-size: 1.25rem"></i>'
            }

             var runDatePicker = function()
            {

                // minimum setup
                $('#datepicker-1').datepicker(
                {
                    todayHighlight: true,
                    orientation: "bottom left",
                    templates: controls
                });


                // input group layout 
                $('#datepicker-2').datepicker(
                {
                    todayHighlight: true,
                    orientation: "bottom left",
                    templates: controls
                });

                // input group layout for modal demo
                $('#datepicker-modal-2').datepicker(
                {
                    todayHighlight: true,
                    orientation: "bottom left",
                    templates: controls
                });

                // enable clear button 
                $('#datepicker-3').datepicker(
                {
                    todayBtn: "linked",
                    clearBtn: true,
                    todayHighlight: true,
                    templates: controls
                });

                // enable clear button for modal demo
                $('#datepicker-modal-3').datepicker(
                {
                    todayBtn: "linked",
                    clearBtn: true,
                    todayHighlight: true,
                    templates: controls
                });

                // orientation 
                $('#datepicker-4-1').datepicker(
                {
                    orientation: "top left",
                    todayHighlight: true,
                    templates: controls
                });

                $('#datepicker-4-2').datepicker(
                {
                    orientation: "top right",
                    todayHighlight: true,
                    templates: controls
                });

                $('#datepicker-4-3').datepicker(
                {
                    orientation: "bottom left",
                    todayHighlight: true,
                    templates: controls
                });

                $('#datepicker-4-4').datepicker(
                {
                    orientation: "bottom right",
                    todayHighlight: true,
                    templates: controls
                });

                // range picker
                $('#datepicker-5').datepicker(
                {
                    todayHighlight: true,
                    templates: controls
                });

                // inline picker
                $('#datepicker-6').datepicker(
                {
                    todayHighlight: true,
                    templates: controls
                });
            }
            
        

           

            $(document).ready(function(){
            $('#academic_year_search').select2({});
            $('#faculty_search').select2({});
            $('#dept_search').select2({});
            $('#user_search').select2({});

            $('#dt-basic-example').dataTable(
                {
                    dom: "<'row mb-3'<'col-sm-12 col-md-6 d-flex align-items-center justify-content-start'f><'col-sm-12 col-md-6 d-flex align-items-center justify-content-end'B>>" +
                        "<'row'<'col-sm-12'tr>>" +
                        "<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
                    responsive: true,
                    pageLength: 10,
                    order: [
                        [0, 'dsc']
                    ],
                    rowGroup:
                    {
                        dataSrc: 0
                    },
                    buttons: [
                    
                        {
                            extend: 'pdfHtml5',
                            text: 'PDF',
                            titleAttr: 'Generate PDF',
                            className: 'btn-success btn-sm mr-1'
                        },
                        
                        {
                            extend: 'csvHtml5',
                            text: 'CSV',
                            titleAttr: 'Generate CSV',
                            className: 'btn-primary btn-sm mr-1'
                        },
                        {
                            extend: 'copyHtml5',
                            text: 'Copy',
                            titleAttr: 'Copy to clipboard',
                            className: 'btn-primary btn-sm mr-1'
                        },
                        {
                            extend: 'print',
                            text: 'Print',
                            titleAttr: 'Print Table',
                            className: 'btn-outline-primary btn-sm'
                        }
                ]
                });

            $('#dt-basic-example2').dataTable(
                {
                    dom: "<'row mb-3'<'col-sm-12 col-md-6 d-flex align-items-center justify-content-start'f><'col-sm-12 col-md-6 d-flex align-items-center justify-content-end'B>>" +
                        "<'row'<'col-sm-12'tr>>" +
                        "<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
                    responsive: true,
                    pageLength: 10,
                    order: [
                        [2, 'asc']
                    ],
                    rowGroup:
                    {
                        dataSrc: 2
                    },
                    buttons: [
                    
                        {
                            extend: 'pdfHtml5',
                            text: 'PDF',
                            titleAttr: 'Generate PDF',
                            className: 'btn-success btn-sm mr-1'
                        },
                        
                        {
                            extend: 'csvHtml5',
                            text: 'CSV',
                            titleAttr: 'Generate CSV',
                            className: 'btn-primary btn-sm mr-1'
                        },
                        {
                            extend: 'copyHtml5',
                            text: 'Copy',
                            titleAttr: 'Copy to clipboard',
                            className: 'btn-primary btn-sm mr-1'
                        },
                        {
                            extend: 'print',
                            text: 'Print',
                            titleAttr: 'Print Table',
                            className: 'btn-outline-primary btn-sm'
                        }
                ]
                });

                runDatePicker();

                $('#generate_all').click(function(){
                   window.location.replace('user_logs.php?::=');
                });

             
                $('#generate_u').click(function(){
                   var user_id = $('#user_search').val();
                   window.location.replace('user_logs.php?gen_u='+user_id);
                });

                $('#generate_dr').click(function(){
                   var start = $('#start').val();
                   var end = $('#end').val();
                   window.location.replace('user_logs.php?gen_s='+start+'&&gen_e='+end);
                });
            });
           
            var colors = ["#886AB5","#37E2D0","#FE6BB0"];
            var total = '<?php echo $total_log ?>';
            var logins = '<?php echo $count_Login ?>';
            var logouts = '<?php echo $count_Logout ?>';
            var pieChart = c3.generate(
            {
                bindto: "#pieChart",
                data:
                {
                    // iris data from R
                    columns: [
                        ['Logins', logins],
                        ["Logouts", logouts]
                    ],
                    type: 'pie' //,
                    /*onclick: function (d, i) { console.log("onclick", d, i); },
                    onmouseover: function (d, i) { console.log("onmouseover", d, i); },
                    onmouseout: function (d, i) { console.log("onmouseout", d, i); }*/
                },
                color:
                {
                    pattern: colors
                }
            });

        </script>
    </body>

</html>
