<?php 
/**
 * Model for payheads
 *
 * @author Akwasi Acheampong 0248200431
 */
class Payhead
{
	
	public $conn;
	
	function __construct()
	{
		$this->conn = Database::connect();
	}

    public function add_payhead(array $data){
		$sql = "INSERT INTO payhead ";
		$fields = array_keys($data);
		$vals = array_values($data);

		$sql .= "(".implode(",", $fields).")";
		$arr = array();
		foreach ($fields as $f) {
			$arr[] = "?";
		}
		$sql .= " VALUES(".implode(",", $arr).")";

		$statement = $this->conn->prepare($sql);

		foreach ($vals as $i => $v) {
			$statement->bindValue($i + 1, $v);
		}

		return $statement->execute();

	}
    
	
	public function update_payhead(array $key_col_vals, array $values) {
        
        $sql = "UPDATE payhead SET ";
        $fields = array_keys($values);
        $vals = array_values($values);
        $key_cols = array_keys($key_col_vals);
        $key_vals = array_values($key_col_vals);
        foreach ($fields as $i=>$f) {
            $fields[$i] .= " = ? ";
        }

        $sql .= implode(",", $fields);
        $sql .= " WHERE " ;
        
        foreach ($key_cols as $i=>$f) {
            $key_cols[$i] .= " = ? ";
        }
        
        $sql .= implode(" AND ", $key_cols);

        $statement = $this->conn->prepare($sql);
        foreach ($vals as $i=>$v) {
            $statement->bindValue($i+1, $v);
        }
        
        foreach ($key_vals as $i=>$v) {
           if($i==0){
               $statement->bindValue((count($fields)+$i+1), $v);
            }else{
               $statement->bindValue((count($fields)+$i), $v);
            }
        }
        
       return  $statement->execute();

    }
	
	public function read_all_payheads(){
		$sql = "SELECT a.*,b.*,c.*,d.* FROM payhead a JOIN claim_header b ON a.claim_header_id=b.claim_header_id JOIN claim_type_table c ON a.claim_type_id=c.claim_type_id JOIN degree_type_table d ON a.degree_type_id=d.degree_id";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function get_rate_by_claim_header_n_type($claim_header_id){
		$sql = 'SELECT * FROM payhead WHERE claim_header_id=:claim_header_id';
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":claim_header_id",$claim_header_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
    }

    public function get_rate_by_claim_h_n_d($claim_header_id,$degree_id){
		$sql = 'SELECT * FROM payhead WHERE claim_header_id=:claim_header_id AND degree_type_id=:degree_id';
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":claim_header_id",$claim_header_id);
		$statement->bindParam(":degree_id",$degree_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
    }
	
	// public function get_payhead_by_faculty_id($faculty_id){
	// 	$sql = "SELECT * FROM payhead WHERE faculty_id=:faculty_id";
	// 	$statement = $this->conn->prepare($sql);
	// 	$statement->bindParam(":faculty_id",$faculty_id);
	// 	$statement->execute();
	// 	if ($statement->rowCount() > 0) {
	// 		return $statement->fetchAll(PDO::FETCH_ASSOC);
	// 	}
	// 	return false;
    // }

    public function read_payhead($payhead_id){
		$sql = "SELECT * FROM payhead WHERE payhead_id=:payhead_id";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":payhead_id",$payhead_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
    }

    public function delete_payhead($payhead_id){
		$sql = "DELETE FROM payhead WHERE payhead_id=:payhead_id";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":payhead_id",$payhead_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
    }
    
    
}