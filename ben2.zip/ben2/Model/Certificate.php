<?php 
/**
 * Model for Certificates
 *
 * @author Akwasi Acheampong 0248200431
 */
class Certificate
{
	
	public $conn;
	
	function __construct()
	{
		$this->conn = Database::connect();
	}

    public function add_certificate(array $data){
		$sql = "INSERT INTO certificate ";
		$fields = array_keys($data);
		$vals = array_values($data);

		$sql .= "(".implode(",", $fields).")";
		$arr = array();
		foreach ($fields as $f) {
			$arr[] = "?";
		}
		$sql .= " VALUES(".implode(",", $arr).")";

		$statement = $this->conn->prepare($sql);

		foreach ($vals as $i => $v) {
			$statement->bindValue($i + 1, $v);
		}

		return $statement->execute();

	}
    
	
	public function update_certificate(array $key_col_vals, array $values) {
        
        $sql = "UPDATE certificate SET ";
        $fields = array_keys($values);
        $vals = array_values($values);
        $key_cols = array_keys($key_col_vals);
        $key_vals = array_values($key_col_vals);
        foreach ($fields as $i=>$f) {
            $fields[$i] .= " = ? ";
        }

        $sql .= implode(",", $fields);
        $sql .= " WHERE " ;
        
        foreach ($key_cols as $i=>$f) {
            $key_cols[$i] .= " = ? ";
        }
        
        $sql .= implode(" AND ", $key_cols);

        $statement = $this->conn->prepare($sql);
        foreach ($vals as $i=>$v) {
            $statement->bindValue($i+1, $v);
        }
        
        foreach ($key_vals as $i=>$v) {
           if($i==0){
               $statement->bindValue((count($fields)+$i+1), $v);
            }else{
               $statement->bindValue((count($fields)+$i), $v);
            }
        }
        
       return  $statement->execute();

    }
	
	public function read_all_certificates(){
		$sql = "SELECT a.*,b.*,d.*,c.stud_id,c.index_number,CONCAT(c.last_name,' ',c.middle_name,' ',c.first_name) as stud_name FROM certificate a JOIN program b ON a.prog_id=b.prog_id JOIN student c ON a.stud_id=c.stud_id
		JOIN academic_year d ON a.academic_yr=d.academic_year_id";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function read_mega_certificates(){
		$sql = "SELECT a.*,b.*,d.*,e.*,f.*,g.*,c.stud_id,c.index_number,CONCAT(c.last_name,' ',c.middle_name,' ',c.first_name) as stud_name FROM certificate a JOIN program b ON a.prog_id=b.prog_id JOIN student c ON a.stud_id=c.stud_id
		JOIN academic_year d ON a.academic_yr=d.academic_year_id JOIN faculty e ON b.faculty_id=e.faculty_id JOIN department f ON f.dept_id=b.dept_id JOIN user g ON a.user_id=g.user_id";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	

	public function get_academic_year_by_name($academic_year){
		$sql = "SELECT * FROM academic_year WHERE academic_year LIKE '%".$academic_year."%'";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
    }
	

    public function read_certificate($cert_id){
		$sql = "SELECT * FROM certificate WHERE cert_id=:cert_id";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":cert_id",$cert_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function read_certificate_academic_yr($academic_yr){
		$sql = "SELECT * FROM certificate WHERE academic_yr=:academic_yr";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":academic_yr",$academic_yr);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function read_pending($academic_yr){
		$sql = "SELECT * FROM certificate WHERE academic_yr=:academic_yr AND collected=0";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":academic_yr",$academic_yr);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function read_total($academic_yr){
		$sql = "SELECT * FROM certificate WHERE academic_yr=:academic_yr ";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":academic_yr",$academic_yr);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function cert_academic_year(){
		$sql = "SELECT a.*,b.* FROM certificate a JOIN academic_year b ON b.academic_year_id=a.academic_yr GROUP BY a.academic_yr ";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}


	public function read_collected($academic_yr){
		$sql = "SELECT * FROM certificate WHERE academic_yr=:academic_yr AND collected=1";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":academic_yr",$academic_yr);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}
	//End of Academic Year Chart
	//Start Of Faculty Chart
	public function read_certificate_faculty($faculty_id){
		$sql = "SELECT a.*,b.* FROM certificate a JOIN program b ON a.prog_id=b.prog_id WHERE b.faculty_id=:faculty_id";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":faculty_id",$faculty_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function f_read_pending($faculty_id){
		$sql = "SELECT a.*,b.* FROM certificate a JOIN program b ON a.prog_id=b.prog_id WHERE b.faculty_id=:faculty_id AND collected=0";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":faculty_id",$faculty_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function f_read_total($faculty_id){
		$sql = "SELECT a.*,b.* FROM certificate a JOIN program b ON a.prog_id=b.prog_id WHERE b.faculty_id=:faculty_id";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":faculty_id",$faculty_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function f_cert_faculty(){
		$sql = "SELECT a.*,b.*,c.* FROM certificate a JOIN program b ON a.prog_id=b.prog_id JOIN faculty c ON b.faculty_id=c.faculty_id GROUP BY b.faculty_id ";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}


	public function f_read_collected($faculty_id){
		$sql = "SELECT a.*,b.* FROM certificate a JOIN program b ON a.prog_id=b.prog_id WHERE b.faculty_id=:faculty_id AND collected=1";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":faculty_id",$faculty_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}


	//End of Faculty Chart

	//Start Department Chart
		public function read_certificate_dept($dept_id){
			$sql = "SELECT a.*,b.* FROM certificate a JOIN program b ON a.prog_id=b.prog_id WHERE b.dept_id=:dept_id";
			$statement = $this->conn->prepare($sql);
			$statement->bindParam(":dept_id",$dept_id);
			$statement->execute();
			if ($statement->rowCount() > 0) {
				return $statement->fetchAll(PDO::FETCH_ASSOC);
			}
			return false;
		}
	
		public function d_read_pending($dept_id){
			$sql = "SELECT a.*,b.* FROM certificate a JOIN program b ON a.prog_id=b.prog_id WHERE b.dept_id=:dept_id AND collected=0";
			$statement = $this->conn->prepare($sql);
			$statement->bindParam(":dept_id",$dept_id);
			$statement->execute();
			if ($statement->rowCount() > 0) {
				return $statement->fetchAll(PDO::FETCH_ASSOC);
			}
			return false;
		}
	
		public function d_read_total($dept_id){
			$sql = "SELECT a.*,b.* FROM certificate a JOIN program b ON a.prog_id=b.prog_id WHERE b.dept_id=:dept_id";
			$statement = $this->conn->prepare($sql);
			$statement->bindParam(":dept_id",$dept_id);
			$statement->execute();
			if ($statement->rowCount() > 0) {
				return $statement->fetchAll(PDO::FETCH_ASSOC);
			}
			return false;
		}
	
		public function d_cert_dept(){
			$sql = "SELECT a.*,b.*,c.* FROM certificate a JOIN program b ON a.prog_id=b.prog_id JOIN department c ON b.dept_id=c.dept_id GROUP BY b.dept_id ";
			$statement = $this->conn->prepare($sql);
			$statement->execute();
			if ($statement->rowCount() > 0) {
				return $statement->fetchAll(PDO::FETCH_ASSOC);
			}
			return false;
		}
	
	
		public function d_read_collected($dept_id){
			$sql = "SELECT a.*,b.* FROM certificate a JOIN program b ON a.prog_id=b.prog_id WHERE b.dept_id=:dept_id AND collected=1";
			$statement = $this->conn->prepare($sql);
			$statement->bindParam(":dept_id",$dept_id);
			$statement->execute();
			if ($statement->rowCount() > 0) {
				return $statement->fetchAll(PDO::FETCH_ASSOC);
			}
			return false;
		}
	
	
		//End of Dept Chart

	//End Department Chart


	
	//Start of Serach
	public function search_certificate_by_3($stud_id,$academic_year_id,$prog_id){
		$sql = "SELECT a.*,b.*,c.*,d.*,e.* FROM certificate a JOIN academic_year b ON a.academic_yr=b.academic_year_id JOIN program c ON a.prog_id=c.prog_id JOIN student d ON d.stud_id=a.stud_id LEFT JOIN collection e ON a.stud_id=e.received_by WHERE a.stud_id=:stud_id AND a.academic_yr=:academic_year_id AND a.prog_id=:prog_id";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":stud_id",$stud_id);
		$statement->bindParam(":academic_year_id",$academic_year_id);
		$statement->bindParam(":prog_id",$prog_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}
	
	public function search_certificate_by_s_n_a($stud_id,$academic_year_id){
		$sql = "SELECT a.*,b.*,c.*,d.*,e.* FROM certificate a JOIN academic_year b ON a.academic_yr=b.academic_year_id JOIN program c ON a.prog_id=c.prog_id JOIN student d ON d.stud_id=a.stud_id LEFT JOIN collection e ON a.stud_id=e.received_by WHERE a.stud_id=:stud_id AND a.academic_yr=:academic_year_id ";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":stud_id",$stud_id);
		$statement->bindParam(":academic_year_id",$academic_year_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}
	
	public function search_certificate_by_s_n_p($stud_id,$prog_id){
		$sql = "SELECT a.*,b.*,c.*,d.*,e.* FROM certificate a JOIN academic_year b ON a.academic_yr=b.academic_year_id JOIN program c ON a.prog_id=c.prog_id JOIN student d ON d.stud_id=a.stud_id LEFT JOIN collection e ON a.stud_id=e.received_by WHERE a.stud_id=:stud_id AND a.prog_id=:prog_id ";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":stud_id",$stud_id);
		$statement->bindParam(":prog_id",$prog_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}
	
	public function search_certificate_by_a_n_p($academic_year_id,$prog_id){
		$sql = "SELECT a.*,b.*,c.*,d.*,e.* FROM certificate a JOIN academic_year b ON a.academic_yr=b.academic_year_id JOIN program c ON a.prog_id=c.prog_id JOIN student d ON d.stud_id=a.stud_id LEFT JOIN collection e ON a.stud_id=e.received_by WHERE a.academic_yr=:academic_year_id AND a.prog_id=:prog_id ";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":academic_year_id",$academic_year_id);
		$statement->bindParam(":prog_id",$prog_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
    }

    public function delete_certificate($cert_id){
		$sql = "DELETE FROM certificate WHERE cert_id=:cert_id";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":cert_id",$cert_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}
	
	public function count_all_certificates(){
		$sql = "SELECT * FROM certificate";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		return $statement->rowCount();
	}

	public function count_collected_certificates(){
		$sql = "SELECT * FROM certificate WHERE collected = 1";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		return $statement->rowCount();
	}

	public function count_pending_certificates(){
		$sql = "SELECT * FROM certificate WHERE collected = 0";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		return $statement->rowCount();
	}

	//Reports
	//All
	public function generate_certificates_by_academic_year($academic_year){
		$sql = "SELECT a.*,b.*,d.*,e.*,f.*,g.*,c.stud_id,c.index_number,CONCAT(c.last_name,' ',c.middle_name,' ',c.first_name) as stud_name FROM certificate a JOIN program b ON a.prog_id=b.prog_id JOIN student c ON a.stud_id=c.stud_id
		JOIN academic_year d ON a.academic_yr=d.academic_year_id JOIN faculty e ON b.faculty_id=e.faculty_id JOIN department f ON f.dept_id=b.dept_id JOIN user g ON a.user_id=g.user_id WHERE a.academic_yr=:academic_year";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":academic_year",$academic_year);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function generate_certificates_by_faculty($faculty_id){
		$sql = "SELECT a.*,b.*,d.*,e.*,f.*,g.*,c.stud_id,c.index_number,CONCAT(c.last_name,' ',c.middle_name,' ',c.first_name) as stud_name FROM certificate a JOIN program b ON a.prog_id=b.prog_id JOIN student c ON a.stud_id=c.stud_id
		JOIN academic_year d ON a.academic_yr=d.academic_year_id JOIN faculty e ON b.faculty_id=e.faculty_id JOIN department f ON f.dept_id=b.dept_id JOIN user g ON a.user_id=g.user_id WHERE e.faculty_id=:faculty_id";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":faculty_id",$faculty_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function generate_certificates_by_department($dept_id){
		$sql = "SELECT a.*,b.*,d.*,e.*,f.*,g.*,c.stud_id,c.index_number,CONCAT(c.last_name,' ',c.middle_name,' ',c.first_name) as stud_name FROM certificate a JOIN program b ON a.prog_id=b.prog_id JOIN student c ON a.stud_id=c.stud_id
		JOIN academic_year d ON a.academic_yr=d.academic_year_id JOIN faculty e ON b.faculty_id=e.faculty_id JOIN department f ON f.dept_id=b.dept_id JOIN user g ON a.user_id=g.user_id WHERE b.dept_id=:dept_id";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":dept_id",$dept_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function generate_certificates_by_program($prog_id){
		$sql = "SELECT a.*,b.*,d.*,e.*,f.*,g.*,c.stud_id,c.index_number,CONCAT(c.last_name,' ',c.middle_name,' ',c.first_name) as stud_name FROM certificate a JOIN program b ON a.prog_id=b.prog_id JOIN student c ON a.stud_id=c.stud_id
		JOIN academic_year d ON a.academic_yr=d.academic_year_id JOIN faculty e ON b.faculty_id=e.faculty_id JOIN department f ON f.dept_id=b.dept_id JOIN user g ON a.user_id=g.user_id WHERE a.prog_id=:prog_id";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":prog_id",$prog_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function generate_certificates_by_dates($start,$end){
		$sql = "SELECT a.*,b.*,d.*,e.*,f.*,g.*,c.stud_id,c.index_number,CONCAT(c.last_name,' ',c.middle_name,' ',c.first_name) as stud_name FROM certificate a JOIN program b ON a.prog_id=b.prog_id JOIN student c ON a.stud_id=c.stud_id
		JOIN academic_year d ON a.academic_yr=d.academic_year_id JOIN faculty e ON b.faculty_id=e.faculty_id JOIN department f ON f.dept_id=b.dept_id JOIN user g ON a.user_id=g.user_id WHERE a.date_created BETWEEN :start AND :end";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":start",$start);
		$statement->bindParam(":end",$end);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function generate_certificates_by_user($user_id){
		$sql = "SELECT a.*,b.*,d.*,e.*,f.*,g.*,c.stud_id,c.index_number,CONCAT(c.last_name,' ',c.middle_name,' ',c.first_name) as stud_name FROM certificate a JOIN program b ON a.prog_id=b.prog_id JOIN student c ON a.stud_id=c.stud_id
		JOIN academic_year d ON a.academic_yr=d.academic_year_id JOIN faculty e ON b.faculty_id=e.faculty_id JOIN department f ON f.dept_id=b.dept_id JOIN user g ON a.user_id=g.user_id WHERE g.user_id=:user_id";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":user_id",$user_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	//End All

	//Collected
	public function read_mega_collected_certificates(){
		$sql = "SELECT a.*,b.*,d.*,e.*,f.*,g.*,c.stud_id,c.index_number,CONCAT(c.last_name,' ',c.middle_name,' ',c.first_name) as stud_name FROM certificate a JOIN program b ON a.prog_id=b.prog_id JOIN student c ON a.stud_id=c.stud_id
		JOIN academic_year d ON a.academic_yr=d.academic_year_id JOIN faculty e ON b.faculty_id=e.faculty_id JOIN department f ON f.dept_id=b.dept_id JOIN user g ON a.user_id=g.user_id WHERE collected=1";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}


	public function generate_collected_certificates_by_academic_year($academic_year){
		$sql = "SELECT a.*,b.*,d.*,e.*,f.*,g.*,c.stud_id,c.index_number,CONCAT(c.last_name,' ',c.middle_name,' ',c.first_name) as stud_name FROM certificate a JOIN program b ON a.prog_id=b.prog_id JOIN student c ON a.stud_id=c.stud_id
		JOIN academic_year d ON a.academic_yr=d.academic_year_id JOIN faculty e ON b.faculty_id=e.faculty_id JOIN department f ON f.dept_id=b.dept_id JOIN user g ON a.user_id=g.user_id WHERE a.academic_yr=:academic_year AND a.collected=1";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":academic_year",$academic_year);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function generate_collected_certificates_by_faculty($faculty_id){
		$sql = "SELECT a.*,b.*,d.*,e.*,f.*,g.*,c.stud_id,c.index_number,CONCAT(c.last_name,' ',c.middle_name,' ',c.first_name) as stud_name FROM certificate a JOIN program b ON a.prog_id=b.prog_id JOIN student c ON a.stud_id=c.stud_id
		JOIN academic_year d ON a.academic_yr=d.academic_year_id JOIN faculty e ON b.faculty_id=e.faculty_id JOIN department f ON f.dept_id=b.dept_id JOIN user g ON a.user_id=g.user_id WHERE e.faculty_id=:faculty_id AND a.collected=1";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":faculty_id",$faculty_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function generate_collected_certificates_by_department($dept_id){
		$sql = "SELECT a.*,b.*,d.*,e.*,f.*,g.*,c.stud_id,c.index_number,CONCAT(c.last_name,' ',c.middle_name,' ',c.first_name) as stud_name FROM certificate a JOIN program b ON a.prog_id=b.prog_id JOIN student c ON a.stud_id=c.stud_id
		JOIN academic_year d ON a.academic_yr=d.academic_year_id JOIN faculty e ON b.faculty_id=e.faculty_id JOIN department f ON f.dept_id=b.dept_id JOIN user g ON a.user_id=g.user_id WHERE b.dept_id=:dept_id AND a.collected=1";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":dept_id",$dept_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function generate_collected_certificates_by_program($prog_id){
		$sql = "SELECT a.*,b.*,d.*,e.*,f.*,g.*,c.stud_id,c.index_number,CONCAT(c.last_name,' ',c.middle_name,' ',c.first_name) as stud_name FROM certificate a JOIN program b ON a.prog_id=b.prog_id JOIN student c ON a.stud_id=c.stud_id
		JOIN academic_year d ON a.academic_yr=d.academic_year_id JOIN faculty e ON b.faculty_id=e.faculty_id JOIN department f ON f.dept_id=b.dept_id JOIN user g ON a.user_id=g.user_id WHERE a.prog_id=:prog_id AND a.collected=1";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":prog_id",$prog_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}
	public function generate_collected_certificates_by_user($user_id){
		$sql = "SELECT a.*,b.*,d.*,e.*,f.*,g.*,c.stud_id,c.index_number,CONCAT(c.last_name,' ',c.middle_name,' ',c.first_name) as stud_name FROM certificate a JOIN program b ON a.prog_id=b.prog_id JOIN student c ON a.stud_id=c.stud_id
		JOIN academic_year d ON a.academic_yr=d.academic_year_id JOIN faculty e ON b.faculty_id=e.faculty_id JOIN department f ON f.dept_id=b.dept_id JOIN user g ON a.user_id=g.user_id WHERE a.user_id=:user_id AND a.collected=1";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":user_id",$user_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function generate_collected_certificates_by_dates($start,$end){
		$sql = "SELECT a.*,b.*,d.*,e.*,f.*,g.*,c.stud_id,c.index_number,CONCAT(c.last_name,' ',c.middle_name,' ',c.first_name) as stud_name FROM certificate a JOIN program b ON a.prog_id=b.prog_id JOIN student c ON a.stud_id=c.stud_id
		JOIN academic_year d ON a.academic_yr=d.academic_year_id JOIN faculty e ON b.faculty_id=e.faculty_id JOIN department f ON f.dept_id=b.dept_id JOIN user g ON a.user_id=g.user_id WHERE a.collected=1 AND a.date_created BETWEEN :start AND :end  ";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":start",$start);
		$statement->bindParam(":end",$end);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	//End Collected

	//Pending
	public function read_mega_pending_certificates(){
		$sql = "SELECT a.*,b.*,d.*,e.*,f.*,g.*,c.stud_id,c.index_number,CONCAT(c.last_name,' ',c.middle_name,' ',c.first_name) as stud_name FROM certificate a JOIN program b ON a.prog_id=b.prog_id JOIN student c ON a.stud_id=c.stud_id
		JOIN academic_year d ON a.academic_yr=d.academic_year_id JOIN faculty e ON b.faculty_id=e.faculty_id JOIN department f ON f.dept_id=b.dept_id JOIN user g ON a.user_id=g.user_id WHERE collected=0";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}


	public function generate_pending_certificates_by_academic_year($academic_year){
		$sql = "SELECT a.*,b.*,d.*,e.*,f.*,g.*,c.stud_id,c.index_number,CONCAT(c.last_name,' ',c.middle_name,' ',c.first_name) as stud_name FROM certificate a JOIN program b ON a.prog_id=b.prog_id JOIN student c ON a.stud_id=c.stud_id
		JOIN academic_year d ON a.academic_yr=d.academic_year_id JOIN faculty e ON b.faculty_id=e.faculty_id JOIN department f ON f.dept_id=b.dept_id JOIN user g ON a.user_id=g.user_id WHERE a.academic_yr=:academic_year AND a.collected=0";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":academic_year",$academic_year);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function generate_pending_certificates_by_faculty($faculty_id){
		$sql = "SELECT a.*,b.*,d.*,e.*,f.*,g.*,c.stud_id,c.index_number,CONCAT(c.last_name,' ',c.middle_name,' ',c.first_name) as stud_name FROM certificate a JOIN program b ON a.prog_id=b.prog_id JOIN student c ON a.stud_id=c.stud_id
		JOIN academic_year d ON a.academic_yr=d.academic_year_id JOIN faculty e ON b.faculty_id=e.faculty_id JOIN department f ON f.dept_id=b.dept_id JOIN user g ON a.user_id=g.user_id WHERE e.faculty_id=:faculty_id AND a.collected=0";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":faculty_id",$faculty_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function generate_pending_certificates_by_department($dept_id){
		$sql = "SELECT a.*,b.*,d.*,e.*,f.*,g.*,c.stud_id,c.index_number,CONCAT(c.last_name,' ',c.middle_name,' ',c.first_name) as stud_name FROM certificate a JOIN program b ON a.prog_id=b.prog_id JOIN student c ON a.stud_id=c.stud_id
		JOIN academic_year d ON a.academic_yr=d.academic_year_id JOIN faculty e ON b.faculty_id=e.faculty_id JOIN department f ON f.dept_id=b.dept_id JOIN user g ON a.user_id=g.user_id WHERE b.dept_id=:dept_id AND a.collected=0";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":dept_id",$dept_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function generate_pending_certificates_by_program($prog_id){
		$sql = "SELECT a.*,b.*,d.*,e.*,f.*,g.*,c.stud_id,c.index_number,CONCAT(c.last_name,' ',c.middle_name,' ',c.first_name) as stud_name FROM certificate a JOIN program b ON a.prog_id=b.prog_id JOIN student c ON a.stud_id=c.stud_id
		JOIN academic_year d ON a.academic_yr=d.academic_year_id JOIN faculty e ON b.faculty_id=e.faculty_id JOIN department f ON f.dept_id=b.dept_id JOIN user g ON a.user_id=g.user_id WHERE a.prog_id=:prog_id AND a.collected=0";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":prog_id",$prog_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function generate_pending_certificates_by_user($user_id){
		$sql = "SELECT a.*,b.*,d.*,e.*,f.*,g.*,c.stud_id,c.index_number,CONCAT(c.last_name,' ',c.middle_name,' ',c.first_name) as stud_name FROM certificate a JOIN program b ON a.prog_id=b.prog_id JOIN student c ON a.stud_id=c.stud_id
		JOIN academic_year d ON a.academic_yr=d.academic_year_id JOIN faculty e ON b.faculty_id=e.faculty_id JOIN department f ON f.dept_id=b.dept_id JOIN user g ON a.user_id=g.user_id WHERE a.user_id=:user_id AND a.collected=0";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":user_id",$user_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function generate_pending_certificates_by_dates($start,$end){
		$sql = "SELECT a.*,b.*,d.*,e.*,f.*,g.*,c.stud_id,c.index_number,CONCAT(c.last_name,' ',c.middle_name,' ',c.first_name) as stud_name FROM certificate a JOIN program b ON a.prog_id=b.prog_id JOIN student c ON a.stud_id=c.stud_id
		JOIN academic_year d ON a.academic_yr=d.academic_year_id JOIN faculty e ON b.faculty_id=e.faculty_id JOIN department f ON f.dept_id=b.dept_id JOIN user g ON a.user_id=g.user_id WHERE a.collected=0 AND a.date_created BETWEEN :start AND :end  ";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":start",$start);
		$statement->bindParam(":end",$end);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}
	
	//End Report

	//Start Verification
	public function verify_certificate_by_index_number($index_number){
		$sql = "SELECT a.*,b.*,d.*,e.*,f.*,g.*,c.stud_id,c.index_number,CONCAT(c.last_name,' ',c.middle_name,' ',c.first_name) as stud_name FROM certificate a JOIN program b ON a.prog_id=b.prog_id JOIN student c ON a.stud_id=c.stud_id
		JOIN academic_year d ON a.academic_yr=d.academic_year_id JOIN faculty e ON b.faculty_id=e.faculty_id JOIN department f ON f.dept_id=b.dept_id JOIN user g ON a.user_id=g.user_id WHERE c.index_number=:index_number";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":index_number",$index_number);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function verify_certificate_by_name($name){
		$sql = "SELECT a.*,b.*,d.*,e.*,f.*,g.*,c.stud_id,c.index_number,CONCAT(c.last_name,' ',c.middle_name,' ',c.first_name) as stud_name FROM certificate a JOIN program b ON a.prog_id=b.prog_id JOIN student c ON a.stud_id=c.stud_id
		JOIN academic_year d ON a.academic_yr=d.academic_year_id JOIN faculty e ON b.faculty_id=e.faculty_id JOIN department f ON f.dept_id=b.dept_id JOIN user g ON a.user_id=g.user_id HAVING stud_name LIKE '%".$name."%' ";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function verify_certificate_by_serial($serial_no){
		$sql = "SELECT a.*,b.*,d.*,e.*,f.*,g.*,c.stud_id,c.index_number,CONCAT(c.last_name,' ',c.middle_name,' ',c.first_name) as stud_name FROM certificate a JOIN program b ON a.prog_id=b.prog_id JOIN student c ON a.stud_id=c.stud_id
		JOIN academic_year d ON a.academic_yr=d.academic_year_id JOIN faculty e ON b.faculty_id=e.faculty_id JOIN department f ON f.dept_id=b.dept_id JOIN user g ON a.user_id=g.user_id WHERE a.serial=:serial_no ";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":serial_no",$serial_no);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}
//Report
	public function verify_certificate_report(){
		$sql = "SELECT a.*,a.date_created as date,b.*,c.*,d.* FROM verification_history a JOIN certificate b ON a.cert_id=b.cert_id JOIN user c ON a.user_id=c.user_id JOIN student d ON b.stud_id=d.stud_id";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function verify_certificate_report_by_user($user_id){
		$sql = "SELECT a.*,a.date_created as date,b.*,c.*,d.* FROM verification_history a JOIN certificate b ON a.cert_id=b.cert_id JOIN user c ON a.user_id=c.user_id JOIN student d ON b.stud_id=d.stud_id WHERE a.user_id=:user_id";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":user_id",$user_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function verify_certificate_report_by_dates($start,$end){
		$sql = "SELECT a.*,a.date_created as date,b.*,c.*,d.* FROM verification_history a JOIN certificate b ON a.cert_id=b.cert_id JOIN user c ON a.user_id=c.user_id JOIN student d ON b.stud_id=d.stud_id WHERE a.date_created BETWEEN :start AND :end";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":start",$start);
		$statement->bindParam(":end",$end);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}



	public function set_verification(array $data){
		$sql = "INSERT INTO verification_history ";
		$fields = array_keys($data);
		$vals = array_values($data);

		$sql .= "(".implode(",", $fields).")";
		$arr = array();
		foreach ($fields as $f) {
			$arr[] = "?";
		}
		$sql .= " VALUES(".implode(",", $arr).")";

		$statement = $this->conn->prepare($sql);

		foreach ($vals as $i => $v) {
			$statement->bindValue($i + 1, $v);
		}

		return $statement->execute();

	}
    
    
}