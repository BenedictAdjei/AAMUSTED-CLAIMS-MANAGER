<?php 
/**
 * Model for Users
 *
 * @author Akwasi Acheampong 0248200431
 */
class User
{
	
	public $conn;
	
	function __construct()
	{
		$this->conn = Database::connect();
	}

    public function add_user(array $data){
		$sql = "INSERT INTO user ";
		$fields = array_keys($data);
		$vals = array_values($data);

		$sql .= "(".implode(",", $fields).")";
		$arr = array();
		foreach ($fields as $f) {
			$arr[] = "?";
		}
		$sql .= " VALUES(".implode(",", $arr).")";

		$statement = $this->conn->prepare($sql);

		foreach ($vals as $i => $v) {
			$statement->bindValue($i + 1, $v);
		}

		return $statement->execute();

	}

	public function set_log(array $data){
		$sql = "INSERT INTO login_history ";
		$fields = array_keys($data);
		$vals = array_values($data);

		$sql .= "(".implode(",", $fields).")";
		$arr = array();
		foreach ($fields as $f) {
			$arr[] = "?";
		}
		$sql .= " VALUES(".implode(",", $arr).")";

		$statement = $this->conn->prepare($sql);

		foreach ($vals as $i => $v) {
			$statement->bindValue($i + 1, $v);
		}

		return $statement->execute();

	}

	public function set_login(array $data){
		$sql = "INSERT INTO logged_in_user ";
		$fields = array_keys($data);
		$vals = array_values($data);

		$sql .= "(".implode(",", $fields).")";
		$arr = array();
		foreach ($fields as $f) {
			$arr[] = "?";
		}
		$sql .= " VALUES(".implode(",", $arr).")";

		$statement = $this->conn->prepare($sql);

		foreach ($vals as $i => $v) {
			$statement->bindValue($i + 1, $v);
		}

		return $statement->execute();

	}

	public function set_attempt_log(array $data){
		$sql = "INSERT INTO login_attempts_history ";
		$fields = array_keys($data);
		$vals = array_values($data);

		$sql .= "(".implode(",", $fields).")";
		$arr = array();
		foreach ($fields as $f) {
			$arr[] = "?";
		}
		$sql .= " VALUES(".implode(",", $arr).")";

		$statement = $this->conn->prepare($sql);

		foreach ($vals as $i => $v) {
			$statement->bindValue($i + 1, $v);
		}

		return $statement->execute();

	}

	public function add_role(array $data){
		$sql = "INSERT INTO role ";
		$fields = array_keys($data);
		$vals = array_values($data);

		$sql .= "(".implode(",", $fields).")";
		$arr = array();
		foreach ($fields as $f) {
			$arr[] = "?";
		}
		$sql .= " VALUES(".implode(",", $arr).")";

		$statement = $this->conn->prepare($sql);

		foreach ($vals as $i => $v) {
			$statement->bindValue($i + 1, $v);
		}

		return $statement->execute();

	}

	public function set_permission(array $data){
		$sql = "INSERT INTO user_permission ";
		$fields = array_keys($data);
		$vals = array_values($data);

		$sql .= "(".implode(",", $fields).")";
		$arr = array();
		foreach ($fields as $f) {
			$arr[] = "?";
		}
		$sql .= " VALUES(".implode(",", $arr).")";

		$statement = $this->conn->prepare($sql);

		foreach ($vals as $i => $v) {
			$statement->bindValue($i + 1, $v);
		}

		return $statement->execute();

	}
    
	
	public function update_user(array $key_col_vals, array $values) {
        
        $sql = "UPDATE user SET ";
        $fields = array_keys($values);
        $vals = array_values($values);
        $key_cols = array_keys($key_col_vals);
        $key_vals = array_values($key_col_vals);
        foreach ($fields as $i=>$f) {
            $fields[$i] .= " = ? ";
        }

        $sql .= implode(",", $fields);
        $sql .= " WHERE " ;
        
        foreach ($key_cols as $i=>$f) {
            $key_cols[$i] .= " = ? ";
        }
        
        $sql .= implode(" AND ", $key_cols);

        $statement = $this->conn->prepare($sql);
        foreach ($vals as $i=>$v) {
            $statement->bindValue($i+1, $v);
        }
        
        foreach ($key_vals as $i=>$v) {
           if($i==0){
               $statement->bindValue((count($fields)+$i+1), $v);
            }else{
               $statement->bindValue((count($fields)+$i), $v);
            }
        }
        
       return  $statement->execute();

	}
	
	public function update_role(array $key_col_vals, array $values) {
        
        $sql = "UPDATE role SET ";
        $fields = array_keys($values);
        $vals = array_values($values);
        $key_cols = array_keys($key_col_vals);
        $key_vals = array_values($key_col_vals);
        foreach ($fields as $i=>$f) {
            $fields[$i] .= " = ? ";
        }

        $sql .= implode(",", $fields);
        $sql .= " WHERE " ;
        
        foreach ($key_cols as $i=>$f) {
            $key_cols[$i] .= " = ? ";
        }
        
        $sql .= implode(" AND ", $key_cols);

        $statement = $this->conn->prepare($sql);
        foreach ($vals as $i=>$v) {
            $statement->bindValue($i+1, $v);
        }
        
        foreach ($key_vals as $i=>$v) {
           if($i==0){
               $statement->bindValue((count($fields)+$i+1), $v);
            }else{
               $statement->bindValue((count($fields)+$i), $v);
            }
        }
        
       return  $statement->execute();

    }
	
	public function read_all_users(){
		$sql = "SELECT a.*,b.*,c.*,d.* FROM user a JOIN role b ON a.role_id=b.role_id JOIN faculty c ON a.faculty_id=c.faculty_id JOIN department d ON a.dept_id=d.dept_id";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function get_dept_id_by_user_id($user_id){
		$sql = "SELECT dept_id FROM user WHERE user_id=:user_id";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":user_id",$user_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function get_role_by_name($role_name){
		$sql = "SELECT * FROM role WHERE role_name LIKE '%".$role_name."%'";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
    }

	
	
	public function read_all_roles(){
		$sql = "SELECT * FROM role";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
    }

    public function read_user($user_id){
		$sql = "SELECT * FROM user WHERE user_id=:user_id";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":user_id",$user_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function read_role($role_id){
		$sql = "SELECT * FROM role WHERE role_id=:role_id";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":role_id",$role_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}
	
	public function auth($user_name,$user_password){
		$sql = "SELECT a.*,b.* FROM user a JOIN role b ON a.role_id=b.role_id WHERE user_name=:user_name AND user_password=:user_password";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":user_name",$user_name);
		$statement->bindParam(":user_password",$user_password);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
    }

    public function delete_user($user_id){
		$sql = "DELETE FROM user WHERE user_id=:user_id";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":user_id",$user_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function delete_user_login($user_id){
		$sql = "DELETE FROM logged_in_user WHERE user_id=:user_id";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":user_id",$user_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function delete_role($role_id){
		$sql = "DELETE FROM role WHERE role_id=:role_id";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":role_id",$role_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function delete_permissions_for_role($role_id){
		$sql = "DELETE FROM user_permission WHERE role_id=:role_id";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":role_id",$role_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}
	
	public function read_all_system_permissions(){
		$sql = "SELECT * FROM system_permission";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function read_all_selected_user_permissions(){
		$sql = "SELECT a.*,b.display_name,b.system_permission_id as s_id FROM user_permission a LEFT JOIN system_permission b ON a.system_permission_id=b.system_permission_id";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function read_user_permissions($role_id){
		$sql = "SELECT a.*,b.* FROM user_permission a JOIN system_permission b ON a.system_permission_id=b.system_permission_id  WHERE a.role_id=:role_id";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":role_id",$role_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function get_system_permission($system_permission_id){
		$sql = "SELECT * FROM system_permission WHERE system_permission_id=:system_permission_id";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":system_permission_id",$system_permission_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function check_user_permission($system_permission_id,$role_id){
		$sql = "SELECT * FROM user_permission WHERE system_permission_id=:system_permission_id AND role_id=:role_id";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":system_permission_id",$system_permission_id);
		$statement->bindParam(":role_id",$role_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	//Reports
	public function login_history_report(){
		$sql = "SELECT a.*,b.* FROM login_history a JOIN user b ON a.user_id=b.user_id ";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function login_history_report_by_user($user_id){
		$sql = "SELECT a.*,b.* FROM login_history a JOIN user b ON a.user_id=b.user_id WHERE a.user_id=:user_id ";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":user_id",$user_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function login_history_report_by_date($start,$end){
		$sql = "SELECT a.*,b.* FROM login_history a JOIN user b ON a.user_id=b.user_id WHERE a.date_created BETWEEN :start AND :end ";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":start",$start);
		$statement->bindParam(":end",$end);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	//End of Login History
	//Start of Login attempts
	public function login_attempts_report(){
		$sql = "SELECT * FROM login_attempts_history";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}
	//End of Login attempts

	public function online_users_report(){
		$sql = "SELECT a.*,b.* FROM logged_in_user a JOIN user b ON a.user_id=b.user_id ";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

//DBBackup
public function read_all_backups(){
	$sql = "SELECT * FROM backup";
	$statement = $this->conn->prepare($sql);
	$statement->execute();
	if ($statement->rowCount() > 0) {
		return $statement->fetchAll(PDO::FETCH_ASSOC);
	}
	return false;
}
    
    
}