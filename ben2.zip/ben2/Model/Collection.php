<?php 
/**
 * Model for Collections
 *
 * @author Akwasi Acheampong 0248200431
 */
class Collection
{
	
	public $conn;
	
	function __construct()
	{
		$this->conn = Database::connect();
	}

    public function add_collection(array $data){
		$sql = "INSERT INTO collection ";
		$fields = array_keys($data);
		$vals = array_values($data);

		$sql .= "(".implode(",", $fields).")";
		$arr = array();
		foreach ($fields as $f) {
			$arr[] = "?";
		}
		$sql .= " VALUES(".implode(",", $arr).")";

		$statement = $this->conn->prepare($sql);

		foreach ($vals as $i => $v) {
			$statement->bindValue($i + 1, $v);
		}

		return $statement->execute();

	}
    
	
	public function update_collection(array $key_col_vals, array $values) {
        
        $sql = "UPDATE collection SET ";
        $fields = array_keys($values);
        $vals = array_values($values);
        $key_cols = array_keys($key_col_vals);
        $key_vals = array_values($key_col_vals);
        foreach ($fields as $i=>$f) {
            $fields[$i] .= " = ? ";
        }

        $sql .= implode(",", $fields);
        $sql .= " WHERE " ;
        
        foreach ($key_cols as $i=>$f) {
            $key_cols[$i] .= " = ? ";
        }
        
        $sql .= implode(" AND ", $key_cols);

        $statement = $this->conn->prepare($sql);
        foreach ($vals as $i=>$v) {
            $statement->bindValue($i+1, $v);
        }
        
        foreach ($key_vals as $i=>$v) {
           if($i==0){
               $statement->bindValue((count($fields)+$i+1), $v);
            }else{
               $statement->bindValue((count($fields)+$i), $v);
            }
        }
        
       return  $statement->execute();

    }
	
	public function read_all_collections(){
		$sql = "SELECT a.*,c.*,e.*,f.*,g.*,b.stud_id,b.index_number,CONCAT(b.last_name,' ',b.middle_name,' ',b.first_name) as stud_name FROM collection a JOIN student b ON a.received_by=b.stud_id JOIN certificate c on a.certificate_serial=c.serial JOIN academic_year e ON c.academic_yr=e.academic_year_id JOIN program f ON c.prog_id=f.prog_id JOIN department g ON f.dept_id=g.dept_id WHERE c.collected=1 ORDER BY a.date";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}
	

    public function read_collection($collection_id){
		$sql = "SELECT * FROM collection WHERE collection_id=:collection_id";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":collection_id",$collection_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function read_collection_by_stud_id($stud_id){
		$sql = "SELECT * FROM collection WHERE received_by=:stud_id";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":stud_id",$stud_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}
	

    public function delete_collection($collection_id){
		$sql = "DELETE FROM collection WHERE collection_id=:collection_id";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":collection_id",$collection_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
    }
    
    
}