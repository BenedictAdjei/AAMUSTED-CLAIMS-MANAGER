<?php 
/**
 * Model for Claims
 *
 * @author Akwasi Acheampong 0248200431
 */
class ExcessClaims
{
	
	public $conn;
	
	function __construct()
	{
		$this->conn = Database::connect();
	}

    public function add_excess_claim(array $data){
		$sql = "INSERT INTO excess_marking ";
		$fields = array_keys($data);
		$vals = array_values($data);

		$sql .= "(".implode(",", $fields).")";
		$arr = array();
		foreach ($fields as $f) {
			$arr[] = "?";
		}
		$sql .= " VALUES(".implode(",", $arr).")";

		$statement = $this->conn->prepare($sql);

		foreach ($vals as $i => $v) {
			$statement->bindValue($i + 1, $v);
		}

		return $statement->execute();

	}
	public function add($academic_year_id,$semester_id,$course_id,$max_scripts_number,$total_scripts_marked,$degree_id,$rate,$amount,$dept_id,$user_id){
        $sql="INSERT INTO  excess_marking (academic_year_id,semester_id,course_id,max_scripts_number,total_scripts_marked,degree_id,rate,amount,dept_id,user_id) VALUES(:academic_year_id,:semester_id,:course_id,:max_scripts_number,:total_scripts_marked,:degree_id,:rate,:amount,:dept_id,:user_id)";
        $statement = $this->conn->prepare($sql);
        $statement->execute([
            		"academic_year_id"=>$academic_year_id,
                    "semester_id"=>$semester_id,
                    "course_id"=>$course_id,
                    "max_scripts_number"=>$max_scripts_number,
                    "total_scripts_marked"=>$total_scripts_marked,
                    "degree_id"=>$degree_id,
                    "rate"=>$rate,
                    "amount"=>$amount,
                    
                    "dept_id"=>$dept_id,
               		"user_id" => $user_id
        ]);
        return true;

    }
    
    
	
	public function update_claim(array $key_col_vals, array $values) {
        
        $sql = "UPDATE excess_marking SET ";
        $fields = array_keys($values);
        $vals = array_values($values);
        $key_cols = array_keys($key_col_vals);
        $key_vals = array_values($key_col_vals);
        foreach ($fields as $i=>$f) {
            $fields[$i] .= " = ? ";
        }

        $sql .= implode(",", $fields);
        $sql .= " WHERE " ;
        
        foreach ($key_cols as $i=>$f) {
            $key_cols[$i] .= " = ? ";
        }
        
        $sql .= implode(" AND ", $key_cols);

        $statement = $this->conn->prepare($sql);
        foreach ($vals as $i=>$v) {
            $statement->bindValue($i+1, $v);
        }
        
        foreach ($key_vals as $i=>$v) {
           if($i==0){
               $statement->bindValue((count($fields)+$i+1), $v);
            }else{
               $statement->bindValue((count($fields)+$i), $v);
            }
        }
        
       return  $statement->execute();

    }
	
	public function read_all_excess_marking(){
		$sql = "SELECT a.*,b.*,c.*,d.*,e.*,f.*,g.* FROM excess_marking a JOIN user b ON a.user_id=b.user_id JOIN academic_year c ON a.academic_year_id=c.academic_year_id JOIN semester d ON a.semester_id=d.semester_id JOIN course e ON a.course_id=e.course_id JOIN degree_type_table f ON a.degree_id=f.degree_id JOIN department g ON a.dept_id=g.dept_id";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function read_all_excess_marking_by_user_dept($dept_id){
		$sql = "SELECT a.*,b.*,c.*,d.*,e.*,f.*,g.* FROM excess_marking a JOIN user b ON a.user_id=b.user_id JOIN academic_year c ON a.academic_year_id=c.academic_year_id JOIN semester d ON a.semester_id=d.semester_id JOIN course e ON a.course_id=e.course_id JOIN degree_type_table f ON a.degree_id=f.degree_id JOIN department g ON a.dept_id=g.dept_id WHERE a.dept_id = :dept_id";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":dept_id",$dept_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function approve_claim($ex_id, $status){
        $sql = "UPDATE excess_claim SET status = :status WHERE ex_id=:ex_id";
        $statement = $this->conn->prepare($sql);
        $statement->execute([
            'ex_id' => $ex_id,
            'status' => $status,
            
        ]);
        return true;
    }

	

	public function get_academic_year_by_name($academic_year){
		$sql = "SELECT * FROM academic_year WHERE academic_year LIKE '%".$academic_year."%'";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
    }
	

    public function read_excess_marking($ex_id){
		$sql = "SELECT * FROM excess_marking WHERE ex_id=:ex_id";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":ex_id",$ex_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function read_claim_academic_year($academic_year){
		$sql = "SELECT * FROM excess_marking WHERE academic_year_id=:academic_year";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":academic_year",$academic_year);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function read_pending($academic_yr){
		$sql = "SELECT * FROM certificate WHERE academic_yr=:academic_yr AND collected=0";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":academic_yr",$academic_yr);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function read_total($academic_yr){
		$sql = "SELECT * FROM certificate WHERE academic_yr=:academic_yr ";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":academic_yr",$academic_yr);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}
	

	
	//Start of Serach
	public function search_certificate_by_3($stud_id,$academic_year_id,$prog_id){
		$sql = "SELECT a.*,b.*,c.*,d.*,e.* FROM certificate a JOIN academic_year b ON a.academic_yr=b.academic_year_id JOIN program c ON a.prog_id=c.prog_id JOIN student d ON d.stud_id=a.stud_id LEFT JOIN collection e ON a.stud_id=e.received_by WHERE a.stud_id=:stud_id AND a.academic_yr=:academic_year_id AND a.prog_id=:prog_id";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":stud_id",$stud_id);
		$statement->bindParam(":academic_year_id",$academic_year_id);
		$statement->bindParam(":prog_id",$prog_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}
	
	public function search_certificate_by_s_n_a($stud_id,$academic_year_id){
		$sql = "SELECT a.*,b.*,c.*,d.*,e.* FROM certificate a JOIN academic_year b ON a.academic_yr=b.academic_year_id JOIN program c ON a.prog_id=c.prog_id JOIN student d ON d.stud_id=a.stud_id LEFT JOIN collection e ON a.stud_id=e.received_by WHERE a.stud_id=:stud_id AND a.academic_yr=:academic_year_id ";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":stud_id",$stud_id);
		$statement->bindParam(":academic_year_id",$academic_year_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}
	
	public function search_certificate_by_s_n_p($stud_id,$prog_id){
		$sql = "SELECT a.*,b.*,c.*,d.*,e.* FROM certificate a JOIN academic_year b ON a.academic_yr=b.academic_year_id JOIN program c ON a.prog_id=c.prog_id JOIN student d ON d.stud_id=a.stud_id LEFT JOIN collection e ON a.stud_id=e.received_by WHERE a.stud_id=:stud_id AND a.prog_id=:prog_id ";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":stud_id",$stud_id);
		$statement->bindParam(":prog_id",$prog_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}
	
	public function search_certificate_by_a_n_p($academic_year_id,$prog_id){
		$sql = "SELECT a.*,b.*,c.*,d.*,e.* FROM certificate a JOIN academic_year b ON a.academic_yr=b.academic_year_id JOIN program c ON a.prog_id=c.prog_id JOIN student d ON d.stud_id=a.stud_id LEFT JOIN collection e ON a.stud_id=e.received_by WHERE a.academic_yr=:academic_year_id AND a.prog_id=:prog_id ";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":academic_year_id",$academic_year_id);
		$statement->bindParam(":prog_id",$prog_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
    }

    public function delete_certificate($cert_id){
		$sql = "DELETE FROM excess_marking WHERE ex_id=:ex_id";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":cert_id",$cert_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}
	
	//dashboard
	public function count_all_excess_marking_claim(){
		$sql = "SELECT * FROM excess_marking";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		return $statement->rowCount();
	}

	public function count_approved_excess_marking_claim(){
		$sql = "SELECT * FROM excess_marking WHERE status = 3";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		return $statement->rowCount();
	}

	public function count_pending_excess_marking_claim(){
		$sql = "SELECT * FROM excess_marking WHERE status = 1";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		return $statement->rowCount();
	}
	public function count_denied_excess_marking_claim(){
		$sql = "SELECT * FROM excess_marking WHERE status = 0";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		return $statement->rowCount();
	}
	//end of dashboard

	//Reports
	//All
	public function generate_certificates_by_academic_year($academic_year){
		$sql = "SELECT a.*,b.*,d.*,e.*,f.*,g.*,c.stud_id,c.index_number,CONCAT(c.last_name,' ',c.middle_name,' ',c.first_name) as stud_name FROM certificate a JOIN program b ON a.prog_id=b.prog_id JOIN student c ON a.stud_id=c.stud_id
		JOIN academic_year d ON a.academic_yr=d.academic_year_id JOIN faculty e ON b.faculty_id=e.faculty_id JOIN department f ON f.dept_id=b.dept_id JOIN user g ON a.user_id=g.user_id WHERE a.academic_yr=:academic_year";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":academic_year",$academic_year);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function generate_claims_by_academic_year($academic_year){
		$sql = "SELECT a.*,b.*,c.*,d.*,e.*,f.*,g.* FROM excess_marking a JOIN user b ON a.user_id=b.user_id JOIN academic_year c ON a.academic_year_id=c.academic_year_id JOIN semester d ON a.semester_id=d.semester_id JOIN course e ON a.course_id=e.course_id JOIN degree_type_table f ON a.degree_id=f.degree_id JOIN department g ON a.dept_id=g.dept_id WHERE a.academic_year_id = :academic_year";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":academic_year",$academic_year);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function generate_claims_by_department($dept_id){
		$sql = "SELECT a.*,b.*,c.*,d.*,e.*,f.*,g.* FROM excess_marking a JOIN user b ON a.user_id=b.user_id JOIN academic_year c ON a.academic_year_id=c.academic_year_id JOIN semester d ON a.semester_id=d.semester_id JOIN course e ON a.course_id=e.course_id JOIN degree_type_table f ON a.degree_id=f.degree_id JOIN department g ON a.dept_id=g.dept_id WHERE a.dept_id=:dept_id";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":dept_id",$dept_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function generate_claims_by_user($user_id){
		$sql = "SELECT a.*,b.*,c.*,d.*,e.*,f.*,g.* FROM excess_marking a JOIN user b ON a.user_id=b.user_id JOIN academic_year c ON a.academic_year_id=c.academic_year_id JOIN semester d ON a.semester_id=d.semester_id JOIN course e ON a.course_id=e.course_id JOIN degree_type_table f ON a.degree_id=f.degree_id JOIN department g ON a.dept_id=g.dept_id WHERE a.user_id=:user_id";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":user_id",$user_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}
	public function generate_claims_by_course($course_id){
		$sql = "SELECT a.*,b.*,c.*,d.*,e.*,f.*,g.* FROM excess_marking a JOIN user b ON a.user_id=b.user_id JOIN academic_year c ON a.academic_year_id=c.academic_year_id JOIN semester d ON a.semester_id=d.semester_id JOIN course e ON a.course_id=e.course_id JOIN degree_type_table f ON a.degree_id=f.degree_id JOIN department g ON a.dept_id=g.dept_id WHERE a.course_id=:course_id";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":course_id",$course_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function generate_claims_by_dates($start,$end){
		$sql = "SELECT a.*,b.*,c.*,d.*,e.*,f.*,g.* FROM excess_marking a JOIN user b ON a.user_id=b.user_id JOIN academic_year c ON a.academic_year_id=c.academic_year_id JOIN semester d ON a.semester_id=d.semester_id JOIN course e ON a.course_id=e.course_id JOIN degree_type_table f ON a.degree_id=f.degree_id JOIN department g ON a.dept_id=g.dept_id WHERE a.date_created BETWEEN :start AND :end";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":start",$start);
		$statement->bindParam(":end",$end);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	   
    
}