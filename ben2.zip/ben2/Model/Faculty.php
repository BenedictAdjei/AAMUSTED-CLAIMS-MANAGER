<?php 
/**
 * Model for Faculties
 *
 * @author Akwasi Acheampong 0248200431
 */
class Faculty
{
	
	public $conn;
	
	function __construct()
	{
		$this->conn = Database::connect();
	}

    public function add_faculty(array $data){
		$sql = "INSERT INTO faculty ";
		$fields = array_keys($data);
		$vals = array_values($data);

		$sql .= "(".implode(",", $fields).")";
		$arr = array();
		foreach ($fields as $f) {
			$arr[] = "?";
		}
		$sql .= " VALUES(".implode(",", $arr).")";

		$statement = $this->conn->prepare($sql);

		foreach ($vals as $i => $v) {
			$statement->bindValue($i + 1, $v);
		}

		return $statement->execute();

	}
    
	
	public function update_faculty(array $key_col_vals, array $values) {
        
        $sql = "UPDATE faculty SET ";
        $fields = array_keys($values);
        $vals = array_values($values);
        $key_cols = array_keys($key_col_vals);
        $key_vals = array_values($key_col_vals);
        foreach ($fields as $i=>$f) {
            $fields[$i] .= " = ? ";
        }

        $sql .= implode(",", $fields);
        $sql .= " WHERE " ;
        
        foreach ($key_cols as $i=>$f) {
            $key_cols[$i] .= " = ? ";
        }
        
        $sql .= implode(" AND ", $key_cols);

        $statement = $this->conn->prepare($sql);
        foreach ($vals as $i=>$v) {
            $statement->bindValue($i+1, $v);
        }
        
        foreach ($key_vals as $i=>$v) {
           if($i==0){
               $statement->bindValue((count($fields)+$i+1), $v);
            }else{
               $statement->bindValue((count($fields)+$i), $v);
            }
        }
        
       return  $statement->execute();

    }
	
	public function read_all_faculties(){
		$sql = "SELECT * FROM faculty";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function get_faculty_by_name($faculty_name){
		$sql = "SELECT * FROM faculty WHERE faculty_name LIKE '%".$faculty_name."%'";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
    }
	

    public function read_faculty($faculty_id){
		$sql = "SELECT * FROM faculty WHERE faculty_id=:faculty_id";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":faculty_id",$faculty_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
    }

    public function delete_faculty($faculty_id){
		$sql = "DELETE FROM faculty WHERE faculty_id=:faculty_id";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":faculty_id",$faculty_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
    }
    
    
}