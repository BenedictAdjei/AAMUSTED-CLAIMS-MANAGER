<?php 
/**
 * Model for Departments
 *
 * @author Akwasi Acheampong 0248200431
 */
class Department
{
	
	public $conn;
	
	function __construct()
	{
		$this->conn = Database::connect();
	}

    public function add_department(array $data){
		$sql = "INSERT INTO department ";
		$fields = array_keys($data);
		$vals = array_values($data);

		$sql .= "(".implode(",", $fields).")";
		$arr = array();
		foreach ($fields as $f) {
			$arr[] = "?";
		}
		$sql .= " VALUES(".implode(",", $arr).")";

		$statement = $this->conn->prepare($sql);

		foreach ($vals as $i => $v) {
			$statement->bindValue($i + 1, $v);
		}

		return $statement->execute();

	}
    
	
	public function update_department(array $key_col_vals, array $values) {
        
        $sql = "UPDATE department SET ";
        $fields = array_keys($values);
        $vals = array_values($values);
        $key_cols = array_keys($key_col_vals);
        $key_vals = array_values($key_col_vals);
        foreach ($fields as $i=>$f) {
            $fields[$i] .= " = ? ";
        }

        $sql .= implode(",", $fields);
        $sql .= " WHERE " ;
        
        foreach ($key_cols as $i=>$f) {
            $key_cols[$i] .= " = ? ";
        }
        
        $sql .= implode(" AND ", $key_cols);

        $statement = $this->conn->prepare($sql);
        foreach ($vals as $i=>$v) {
            $statement->bindValue($i+1, $v);
        }
        
        foreach ($key_vals as $i=>$v) {
           if($i==0){
               $statement->bindValue((count($fields)+$i+1), $v);
            }else{
               $statement->bindValue((count($fields)+$i), $v);
            }
        }
        
       return  $statement->execute();

    }
	
	public function read_all_departments(){
		$sql = "SELECT a.*,b.* FROM department a JOIN faculty b ON a.faculty_id = b.faculty_id";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function get_department_by_name($dept_name){
		$sql = "SELECT * FROM department WHERE dept_name LIKE '%".$dept_name."%'";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
    }
	
	public function get_department_by_faculty_id($faculty_id){
		$sql = "SELECT * FROM department WHERE faculty_id=:faculty_id";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":faculty_id",$faculty_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
    }

    public function read_department($dept_id){
		$sql = "SELECT * FROM department WHERE dept_id=:dept_id";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":dept_id",$dept_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
    }

    public function delete_department($dept_id){
		$sql = "DELETE FROM department WHERE dept_id=:dept_id";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":dept_id",$dept_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
    }
    
    
}