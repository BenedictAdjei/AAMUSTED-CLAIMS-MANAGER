<?php 
/**
 * Model for Students
 *
 * @author Akwasi Acheampong 0248200431
 */
class Student
{
	
	public $conn;
	
	function __construct()
	{
		$this->conn = Database::connect();
	}

    public function add_student(array $data){
		$sql = "INSERT INTO student ";
		$fields = array_keys($data);
		$vals = array_values($data);

		$sql .= "(".implode(",", $fields).")";
		$arr = array();
		foreach ($fields as $f) {
			$arr[] = "?";
		}
		$sql .= " VALUES(".implode(",", $arr).")";

		$statement = $this->conn->prepare($sql);

		foreach ($vals as $i => $v) {
			$statement->bindValue($i + 1, $v);
		}

		return $statement->execute();

	}
    
	
	public function update_student(array $key_col_vals, array $values) {
        
        $sql = "UPDATE student SET ";
        $fields = array_keys($values);
        $vals = array_values($values);
        $key_cols = array_keys($key_col_vals);
        $key_vals = array_values($key_col_vals);
        foreach ($fields as $i=>$f) {
            $fields[$i] .= " = ? ";
        }

        $sql .= implode(",", $fields);
        $sql .= " WHERE " ;
        
        foreach ($key_cols as $i=>$f) {
            $key_cols[$i] .= " = ? ";
        }
        
        $sql .= implode(" AND ", $key_cols);

        $statement = $this->conn->prepare($sql);
        foreach ($vals as $i=>$v) {
            $statement->bindValue($i+1, $v);
        }
        
        foreach ($key_vals as $i=>$v) {
           if($i==0){
               $statement->bindValue((count($fields)+$i+1), $v);
            }else{
               $statement->bindValue((count($fields)+$i), $v);
            }
        }
        
       return  $statement->execute();

    }
	
	public function read_all_students(){
		$sql = "SELECT a.*,b.*,c.*,d.*,e.*, FROM student a JOIN department b ON a.dept_id=b.dept_id JOIN faculty c ON c.faculty_id=a.faculty_id JOIN role d ON a.role_id=d.role_id JOIN academic_year e ON a.academic_year_id=e.academic_year_id ORDER BY a.date_created ASC";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function get_student_by_name($student_name){
		$sql = "SELECT stud_id,CONCAT(last_name,' ',middle_name,' ',first_name) as stud_name FROM student HAVING stud_name LIKE '%".$student_name."%'";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
    }
	

    public function read_student($stud_id){
		$sql = "SELECT * FROM student WHERE stud_id=:stud_id";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":stud_id",$stud_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
    }

    public function delete_student($stud_id){
		$sql = "DELETE FROM student WHERE stud_id=:stud_id";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":stud_id",$stud_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
    }
    
    
}