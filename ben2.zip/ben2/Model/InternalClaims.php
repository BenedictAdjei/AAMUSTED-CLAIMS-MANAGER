<?php 
/**
 * Model for Claims
 *
 * @author Akwasi Acheampong 0248200431
 */
class InternalSupClaim
{
	
	public $conn;
	
	function __construct()
	{
		$this->conn = Database::connect();
	}

    public function add_claim(array $data){
		$sql = "INSERT INTO internal_claim ";
		$fields = array_keys($data);
		$vals = array_values($data);

		$sql .= "(".implode(",", $fields).")";
		$arr = array();
		foreach ($fields as $f) {
			$arr[] = "?";
		}
		$sql .= " VALUES(".implode(",", $arr).")";

		$statement = $this->conn->prepare($sql);

		foreach ($vals as $i => $v) {
			$statement->bindValue($i + 1, $v);
		}

		return $statement->execute();

	}
    
	
	public function update_excess_claim(array $key_col_vals, array $values) {
        
        $sql = "UPDATE excess_marking SET ";
        $fields = array_keys($values);
        $vals = array_values($values);
        $key_cols = array_keys($key_col_vals);
        $key_vals = array_values($key_col_vals);
        foreach ($fields as $i=>$f) {
            $fields[$i] .= " = ? ";
        }

        $sql .= implode(",", $fields);
        $sql .= " WHERE " ;
        
        foreach ($key_cols as $i=>$f) {
            $key_cols[$i] .= " = ? ";
        }
        
        $sql .= implode(" AND ", $key_cols);

        $statement = $this->conn->prepare($sql);
        foreach ($vals as $i=>$v) {
            $statement->bindValue($i+1, $v);
        }
        
        foreach ($key_vals as $i=>$v) {
           if($i==0){
               $statement->bindValue((count($fields)+$i+1), $v);
            }else{
               $statement->bindValue((count($fields)+$i), $v);
            }
        }
        
       return  $statement->execute();

    }

    public function add($academic_year_id,$claim_type_id,$stud_id,$degree_id,$project_title,$rate,$amount,$status,$dept_id,$user_id){
        $sql="INSERT INTO  internal_claim (academic_year_id,claim_type_id,degree_id,project_title,stud_id,rate,amount,status,dept_id,user_id) VALUES(:academic_year_id,:claim_type_id,:degree_id,:project_title,:stud_id,:rate,:amount,:status,:dept_id,:user_id)";
        $statement = $this->conn->prepare($sql);
        $statement->execute([
            		"academic_year_id"=>$academic_year_id,
                    "stud_id"=>$stud_id,
                    "claim_type_id"=>$claim_type_id,
                    "project_title"=>$project_title,
                    "degree_id"=>$degree_id,
                    "rate"=>$rate,
                    "amount"=>$amount,
                    "status"=>$status,
                    "dept_id"=>$dept_id,
               		"user_id" => $user_id
        ]);
        return true;

    }
	
	public function read_all_internal_sup_claim(){
		$sql = "SELECT a.*,b.*,c.*,e.*,f.* FROM internal_claim a JOIN user b ON a.user_id=b.user_id JOIN academic_year c ON a.academic_year_id=c.academic_year_id JOIN claim_type_table e ON a.claim_type_id=e.claim_type_id JOIN degree_type_table f ON a.degree_id=f.degree_id";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function read_all_internal_sup_claim_by_userdept($dept_id){
		$sql = "SELECT a.*,b.*,c.*,e.*,f.* FROM internal_claim a JOIN user b ON a.user_id=b.user_id JOIN academic_year c ON a.academic_year_id=c.academic_year_id JOIN claim_type_table e ON a.claim_type_id=e.claim_type_id JOIN degree_type_table f ON a.degree_id=f.degree_id WHERE a.dept=:dept_id";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":dept_id",$dept_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}


	public function read_all_internal_sup_claim_by_userdept_n_hod($dept_id){
		$sql = "SELECT a.*,b.*,c.*,e.*,f.* FROM internal_claim a JOIN user b ON a.user_id=b.user_id JOIN academic_year c ON a.academic_year_id=c.academic_year_id JOIN claim_type_table e ON a.claim_type_id=e.claim_type_id JOIN degree_type_table f ON a.degree_id=f.degree_id WHERE a.dept=:dept_id";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":dept_id",$dept_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function read_all_internal_sup_claim_accounts(){
		$sql = "SELECT a.*,b.*,c.*,d.*,e.*,f.* FROM internal_claim a JOIN user b ON a.user_id=b.user_id JOIN academic_year c ON a.academic_year_id=c.academic_year_id JOIN payhead d ON a.rate_id=d.payhead_id JOIN claim_type_table e ON a.claim_type_id=e.claim_type_id JOIN degree_type_table f ON a.degree_id=f.degree_id";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	

	public function get_academic_year_by_name($academic_year){
		$sql = "SELECT * FROM academic_year WHERE academic_year LIKE '%".$academic_year."%'";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
    }
	

    public function read_excess_marking($ex_id){
		$sql = "SELECT * FROM internal_claim WHERE ex_id=:ex_id";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":ex_id",$ex_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function read_claim_academic_year($academic_year){
		$sql = "SELECT * FROM internal_claim WHERE academic_year_id=:academic_year";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":academic_year",$academic_year);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function read_pending($academic_yr){
		$sql = "SELECT * FRinternal_claim WHERE academic_yr=:academic_yr AND collected=0";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":academic_yr",$academic_yr);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function read_total($academic_yr){
		$sql = "SELECT * FRinternal_claim WHERE academic_yr=:academic_yr ";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":academic_yr",$academic_yr);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}
	

	
	//Start of Serach
	public function search_claim_by_4($user_id,$academic_year_id,$degree_id,$claim_type){
		$sql = "SELECT a.*,b.*,c.*,e.*,f.* FROM internal_claim a JOIN user b ON a.user_id=b.user_id JOIN academic_year c ON a.academic_year_id=c.academic_year_id JOIN claim_type_table e ON a.claim_type_id=e.claim_type_id JOIN degree_type_table f ON a.degree_id=f.degree_id WHERE a.user_id=:user_id AND a.academic_year_id=:academic_year_id AND a.degree_id=:degree_id AND a.claim_type_id=:claim_type AND a.status=1";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":user_id",$user_id);
		$statement->bindParam(":academic_year_id",$academic_year_id);
		$statement->bindParam(":degree_id",$degree_id);
		$statement->bindParam(":claim_type",$claim_type);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

    public function delete_claim($claim_id){
		$sql = "DELETE FROM claim WHERE internal_claim_id=:claim_id";
		$statement = $this->conn->prepare($sql);
        $statement->bindParam(":claim_id",$claim_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}
	
	public function count_all_internal_sup_claim(){
		$sql = "SELECT * FROM internal_claim";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		return $statement->rowCount();
	}

	public function count_approved_internal_sup_claim(){
		$sql = "SELECT * FROM internal_claim WHERE status = 3";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		return $statement->rowCount();
	}

	public function count_pending_internal_sup_claim(){
		$sql = "SELECT * FROM internal_claim WHERE status = 1";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		return $statement->rowCount();
	}
	public function count_denied_internal_sup_claim(){
		$sql = "SELECT * FROM internal_claim WHERE status = 0";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		return $statement->rowCount();
	}
	   
	
	   

	   //report
	public function read_mega_claims(){
		$sql = "SELECT a.*,b.*,d.*,e.*,f.*,g.*,c.stud_id,c.index_number,CONCAT(c.last_name,' ',c.middle_name,' ',c.first_name) as stud_name FROM certificate a JOIN program b ON a.prog_id=b.prog_id JOIN student c ON a.stud_id=c.stud_id
		JOIN academic_year d ON a.academic_yr=d.academic_year_id JOIN faculty e ON b.faculty_id=e.faculty_id JOIN department f ON f.dept_id=b.dept_id JOIN user g ON a.user_id=g.user_id";
		$statement = $this->conn->prepare($sql);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function generate_claims_by_academic_year($academic_year){
		$sql = "SELECT a.*,b.*,c.*,e.*,f.*,g.* FROM internal_claim a JOIN user b ON a.user_id=b.user_id JOIN academic_year c ON a.academic_year_id=c.academic_year_id JOIN claim_type_table e ON a.claim_type_id=e.claim_type_id JOIN degree_type_table f ON a.degree_id=f.degree_id JOIN department g ON a.dept_id=g.dept_id WHERE a.academic_year_id=:academic_year";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":academic_year",$academic_year);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function generate_claims_by_department($dept_id){
		$sql = "SELECT a.*,b.*,c.*,e.*,f.*,g.* FROM internal_claim a JOIN user b ON a.user_id=b.user_id JOIN academic_year c ON a.academic_year_id=c.academic_year_id JOIN claim_type_table e ON a.claim_type_id=e.claim_type_id JOIN degree_type_table f ON a.degree_id=f.degree_id JOIN department g ON a.dept_id=g.dept_id WHERE a.dept_id=:dept_id";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":dept_id",$dept_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function generate_claims_by_user($user_id){
		$sql = "SELECT a.*,b.*,c.*,e.*,f.*,g.* FROM internal_claim a JOIN user b ON a.user_id=b.user_id JOIN academic_year c ON a.academic_year_id=c.academic_year_id JOIN claim_type_table e ON a.claim_type_id=e.claim_type_id JOIN degree_type_table f ON a.degree_id=f.degree_id JOIN department g ON a.dept_id=g.dept_id WHERE a.user_id=:user_id";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":user_id",$user_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}
	public function generate_claims_by_claim_type($claim_type_id){
		$sql = "SELECT a.*,b.*,c.*,e.*,f.*,g.* FROM internal_claim a JOIN user b ON a.user_id=b.user_id JOIN academic_year c ON a.academic_year_id=c.academic_year_id JOIN claim_type_table e ON a.claim_type_id=e.claim_type_id JOIN degree_type_table f ON a.degree_id=f.degree_id JOIN department g ON a.dept_id=g.dept_id WHERE a.claim_type_id=:claim_type_id";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":claim_type_id",$claim_type_id);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

	public function generate_claims_by_dates($start,$end){
		$sql = "SELECT a.*,b.*,c.*,e.*,f.*,g.* FROM internal_claim a JOIN user b ON a.user_id=b.user_id JOIN academic_year c ON a.academic_year_id=c.academic_year_id JOIN claim_type_table e ON a.claim_type_id=e.claim_type_id JOIN degree_type_table f ON a.degree_id=f.degree_id JOIN department g ON a.dept_id=g.dept_id WHERE a.date_created BETWEEN :start AND :end";
		$statement = $this->conn->prepare($sql);
		$statement->bindParam(":start",$start);
		$statement->bindParam(":end",$end);
		$statement->execute();
		if ($statement->rowCount() > 0) {
			return $statement->fetchAll(PDO::FETCH_ASSOC);
		}
		return false;
	}

    
}