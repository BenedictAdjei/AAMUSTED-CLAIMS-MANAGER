<!DOCTYPE html>

<html lang="en">
    
<head>
        <?php include 'controller/php_inc/setup_inc_code.php' ?>
        <?php include 'inc/meta_inc.php' ?>
        <!-- base css -->
        <?php include 'inc/styles_inc.php' ?>
        <link rel="stylesheet" media="screen, print" href="css/statistics/chartist/chartist.css">
        <link rel="stylesheet" media="screen, print" href="css/formplugins/bootstrap-datepicker/bootstrap-datepicker.css">
        <link rel="stylesheet" media="screen, print" href="css/statistics/c3/c3.css">
        <style>
.select2-selection__rendered {
    line-height: 32px !important;
}
.select2-container .select2-selection--single {
    height: 39px !important;
}
.select2-selection__arrow {
    height: 35px !important;
}

    


        </style>
</head>
    <body class="mod-bg-1 ">
        <!-- DOC: script to save and load page settings -->
        <script>
    
            /**
             *	This script should be placed right after the body tag for fast execution 
            *	Note: the script is written in pure javascript and does not depend on thirdparty library
            **/
            'use strict';

            var classHolder = document.getElementsByTagName("BODY")[0],
                /** 
                 * Load from localstorage
                 **/
                themeSettings = (localStorage.getItem('themeSettings')) ? JSON.parse(localStorage.getItem('themeSettings')) :
                {},
                themeURL = themeSettings.themeURL || '',
                themeOptions = themeSettings.themeOptions || '';
            /** 
             * Load theme options
             **/
            if (themeSettings.themeOptions)
            {
                classHolder.className = themeSettings.themeOptions;
                console.log("%c✔ Theme settings loaded", "color: #148f32");
            }
            else
            {
                console.log("Heads up! Theme settings is empty or does not exist, loading default settings...");
            }
            if (themeSettings.themeURL && !document.getElementById('mytheme'))
            {
                var cssfile = document.createElement('link');
                cssfile.id = 'mytheme';
                cssfile.rel = 'stylesheet';
                cssfile.href = themeURL;
                document.getElementsByTagName('head')[0].appendChild(cssfile);
            }
            /** 
             * Save to localstorage 
             **/
            var saveSettings = function()
            {
                themeSettings.themeOptions = String(classHolder.className).split(/[^\w-]+/).filter(function(item)
                {
                    return /^(nav|header|mod|display)-/i.test(item);
                }).join(' ');
                if (document.getElementById('mytheme'))
                {
                    themeSettings.themeURL = document.getElementById('mytheme').getAttribute("href");
                };
                localStorage.setItem('themeSettings', JSON.stringify(themeSettings));
            }
            /** 
             * Reset settings
             **/
            var resetSettings = function()
            {
                localStorage.setItem("themeSettings", "");
            }

        </script>
        <!-- BEGIN Page Wrapper -->
        <div class="page-wrapper">
            <div class="page-inner">
                <!-- BEGIN Left Aside -->
                <?php include 'inc/aside_inc.php' ?>
                <!-- END Left Aside -->
                <div class="page-content-wrapper">
                    <!-- BEGIN Page Header -->
                    <?php include 'inc/header_inc.php' ?>    
                    <!-- END Page Header -->
                    <!-- BEGIN Page Content -->
                    <!-- the #js-page-content id is needed for some plugins to initialize -->
                    <main id="js-page-content" role="main" class="page-content">
                        <ol class="breadcrumb page-breadcrumb"> 
                            <li class="breadcrumb-item"><a href="javascript:void(0);">FlairTech Admin</a></li>
                            <li class="breadcrumb-item">Report</li>
                            <li class="position-absolute pos-top pos-right d-none d-sm-block"><span class="js-get-date"></span></li>
                        </ol>
                        <div class="subheader">
                            <h1 class="subheader-title">
                                <i class='subheader-icon fal fa-table'></i> Report <span class='fw-300'></span> 
                                
                            </h1>
                        </div>

                        <div class="row">
                        <div class="col-xl-4">
                                <div id="panel-1" class="panel">
                                    <div class="panel-hdr bg-primary-700 bg-success-gradient">
                                        <h2>
                                        View All Claims Report:
                                        </h2>
                                        
                                    </div>
                                    <div class="panel-container show">
                                        <div class="panel-content">
                                            <div class="form-group"><div class="input-group">
                                                    <select class="custom-select"  aria-label="usertype">
                                                        <option value="" selected="">All</option>
                                                    </select>
                                                    <div class="input-group-append">
                                                        <button type="button" id="generate_all" class="btn btn-success shadow-0" >Search</button>    
                                                    </div>
                                                    

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4">
                                <div id="panel-1" class="panel">
                                    <div class="panel-hdr ">
                                        <h2>
                                        View Report By Academic Year:
                                        </h2>
                                        
                                    </div>
                                    <div class="panel-container show">
                                        <div class="panel-content">
                                            <div class="form-group"><div class="input-group">
                                                    <select class="custom-select" id="academic_year_search" aria-label="usertype">
                                                        <option value="" selected="">Select Academic Year</option>
                                                        <?php foreach($academic_years as $a_year): ?>
                                                            <option value="<?php echo $a_year['academic_year_id'] ?>"><?php echo $a_year['academic_year'] ?></option>
                                                        <?php endforeach ?>
                                                    </select>
                                                    <div class="input-group-append">
                                                        <button type="button" id="generate_ac" class="btn btn-info shadow-0" >Search</button>    
                                                    </div>
                                                    

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4">
                                <div id="panel-1" class="panel">
                                    <div class="panel-hdr ">
                                        <h2>
                                        View Report By Faculty:
                                        </h2>
                                        
                                    </div>
                                    <div class="panel-container show">
                                        <div class="panel-content">
                                            <div class="form-group"><div class="input-group">
                                                    <select class="custom-select" id="faculty_search" aria-label="usertype">
                                                        <option value="" selected="">Select Faculty</option>
                                                        <?php foreach($faculties as $faculty): ?>
                                                            <option value="<?php echo $faculty['faculty_id'] ?>"><?php echo $faculty['faculty_name'] ?></option>
                                                        <?php endforeach ?>
                                                    </select>
                                                    <div class="input-group-append">
                                                        <button type="button" id="generate_f" class="btn btn-info shadow-0">Search</button>    
                                                    </div>
                                                    

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4">
                                <div id="panel-1" class="panel">
                                    <div class="panel-hdr ">
                                        <h2>
                                        View Report By Department:
                                        </h2>
                                        
                                    </div>
                                    <div class="panel-container show">
                                        <div class="panel-content">
                                            <div class="form-group"><div class="input-group">
                                                    <select class="custom-select" id="dept_search" aria-label="usertype">
                                                        <option value="" selected="">Select Department</option>
                                                        <?php foreach($departments as $dept): ?>
                                                            <option value="<?php echo $dept['dept_id'] ?>"><?php echo $dept['dept_name'] ?></option>
                                                        <?php endforeach ?>
                                                    </select>
                                                    <div class="input-group-append">
                                                        <button type="button" id="generate_d" class="btn btn-info shadow-0">Search</button>    
                                                    </div>
                                                    

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4">
                                <div id="panel-1" class="panel">
                                    <div class="panel-hdr ">
                                        <h2>
                                        View Report By Program:
                                        </h2>
                                        
                                    </div>
                                    <div class="panel-container show">
                                        <div class="panel-content">
                                            <div class="form-group"><div class="input-group">
                                                    <select class="custom-select" id="prog_search" aria-label="usertype">
                                                        <option value="" selected="">Select Program</option>
                                                        <?php foreach($programs as $prog): ?>
                                                            <option value="<?php echo $prog['prog_id'] ?>"><?php echo $prog['prog_name'] ?></option>
                                                        <?php endforeach ?>
                                                    </select>
                                                    <div class="input-group-append">
                                                        <button type="button" id="generate_p" class="btn btn-info shadow-0"> Search</button>    
                                                    </div>
                                                    

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-4">
                                <div id="panel-1" class="panel">
                                    <div class="panel-hdr ">
                                        <h2>
                                        View Report By User:
                                        </h2>
                                        
                                    </div>
                                    <div class="panel-container show">
                                        <div class="panel-content">
                                            <div class="form-group"><div class="input-group">
                                                    <select class="custom-select" id="user_search" aria-label="usertype">
                                                        <option value="" selected="">Select User</option>
                                                        <?php foreach($all_users as $sys_user): ?>
                                                            <option value="<?php echo $sys_user['user_id'] ?>"><?php echo $sys_user['name'] ?></option>
                                                        <?php endforeach ?>
                                                    </select>
                                                    <div class="input-group-append">
                                                        <button type="button" id="generate_u" class="btn btn-info shadow-0"> Search</button>    
                                                    </div>
                                                    

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4">
                                <div id="panel-1" class="panel">
                                    <div class="panel-hdr ">
                                        <h2>
                                        View Report By Date Range:
                                        </h2>
                                        
                                    </div>
                                    <div class="panel-container show">
                                        <div class="panel-content">
                                            <div class="form-group"><div class="input-group">
                                                    <div class="input-daterange input-group" id="datepicker-5">
                                                        <input type="text" class="form-control" id="start" name="start">
                                                        <div class="input-group-append input-group-prepend">
                                                            <span class="input-group-text fs-xl"><i class="fal fa-ellipsis-h"></i></span>
                                                        </div>
                                                        <input type="text" class="form-control" id="end" name="end">
                                                        <div class="input-group-append">
                                                        <button type="button" id="generate_dr" class="btn btn-info shadow-0">Search</button>    
                                                    </div>
                                                    </div>
                                                    
                                                    

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php
                        $count_certs = 0;
                        $count_collected = 0;
                        $count_pending = 0;

                        if(isset($_GET['::'])){
                            $generate_certificates = $mega_certificates;    
                            $generate_pending_certificates = $mega_pending_certificates;
                        }

                        if(isset($_GET['gen_ac'])){
                            $academic_year = $_GET['gen_ac'];
                           $generate_certificates = $certificate->generate_certificates_by_academic_year($academic_year);
                           $generate_pending_certificates = $certificate->generate_pending_certificates_by_academic_year($academic_year);
                          
                        }
                        
                        ?>
                         <?php
                        //  $generate_certificates = array();
                        if(isset($_GET['gen_f'])){
                            $faculty_id = $_GET['gen_f'];
                           $generate_certificates = $certificate->generate_certificates_by_faculty($faculty_id);
                           $generate_pending_certificates = $certificate->generate_pending_certificates_by_faculty($faculty_id);
                        }
                        
                        ?>

<?php
                        //  $generate_certificates = array();
                        if(isset($_GET['gen_d'])){
                            $dept_id = $_GET['gen_d'];
                           $generate_certificates = $certificate->generate_certificates_by_department($dept_id);
                           $generate_pending_certificates = $certificate->generate_pending_certificates_by_department($dept_id);
                        }

                        if(isset($_GET['gen_p'])){
                            $prog_id = $_GET['gen_p'];
                           $generate_certificates = $certificate->generate_certificates_by_department($prog_id);
                           $generate_pending_certificates = $certificate->generate_pending_certificates_by_department($prog_id);
                        }

                        if(isset($_GET['gen_u'])){
                            $user_id = $_GET['gen_u'];
                           $generate_certificates = $certificate->generate_certificates_by_user($user_id);
                           $generate_pending_certificates = $certificate->generate_pending_certificates_by_user($user_id);
                        }

                        if(isset($_GET['gen_s'])&&isset($_GET['gen_e'])){
                            $start = $_GET['gen_s'];
                            $con_start = date("Y-m-d", strtotime($start));
                            $start = $con_start;
                            $end = $_GET['gen_e'];
                            $con_end = date("Y-m-d", strtotime($end));
                            $end = $con_end;
                           $generate_certificates = $certificate->generate_certificates_by_dates($start,$end);
                           $generate_pending_certificates = $certificate->generate_pending_certificates_by_dates($start,$end);
                        }
                        
                        ?>

                        <?php if($generate_certificates): ?>
                            <?php $count_certs = 0; ?>
                            <?php $count_collected = 0; ?>
                            <?php $count_pending = 0; ?>
                            <?php foreach($generate_certificates as $certs): ?>
                                <?php
                                    if($certs['collected'] != 0){
                                        $count_collected ++;
                                    }else{
                                        $count_pending ++;
                                    }
                                ?>
                                <?php $count_certs ++; ?>
                            <?php endforeach ?>
                            <div class="row">
                            <div class="col-sm-4">
                                <div class="p-3 bg-primary-300 rounded overflow-hidden position-relative text-white mb-g">
                                    <div class="">
                                        <h3 class="display-4 d-block l-h-n m-0 fw-500">
                                            <?php echo $count_certs ?>
                                            <small class="m-0 l-h-n">Total Number Of Claims Added</small>
                                        </h3>
                                    </div>
                                    <i class="fal fa-book position-absolute pos-right pos-bottom opacity-15 mb-n1 mr-n1" style="font-size:6rem"></i>
                                </div>
                            </div>

                            <div class="col-sm-4">
                                <div class="p-3 bg-danger-300 rounded overflow-hidden position-relative text-white mb-g">
                                    <div class="">
                                        <h3 class="display-4 d-block l-h-n m-0 fw-500">
                                        <?php echo $count_collected ?>
                                            <small class="m-0 l-h-n">Total Number Of Approved Claims</small>
                                        </h3>
                                    </div>
                                    <i class="fal fa-book position-absolute pos-right pos-bottom opacity-15 mb-n1 mr-n1" style="font-size:6rem"></i>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="p-3 bg-warning-300 rounded overflow-hidden position-relative text-white mb-g">
                                    <div class="">
                                        <h3 class="display-4 d-block l-h-n m-0 fw-500">
                                        <?php echo $count_pending ?>
                                            <small class="m-0 l-h-n">Total Number Of Claims Pending Approval</small>
                                        </h3>
                                    </div>
                                    <i class="fal fa-book position-absolute pos-right pos-bottom opacity-15 mb-n1 mr-n1" style="font-size:6rem"></i>
                                </div>
                            </div>
                        </div>
                        <div class="row academic_year">
                            <div class="col-xl-12">
                                <div id="panel-1" class="panel">
                                    <div class="panel-hdr bg-primary-700 bg-success-gradient">
                                        <h2>
                                        Generated Report
                                        </h2>
                                        
                                    </div>
                                    <div class="panel-container show">
                                        <div class="panel-content">
                                            
                                        <div class="row">
                                                <div class="col-xl-12">
                                                <table id="dt-basic-example" class="table table-bordered table-hover table-striped w-100">
                                                            <thead>
                                                            <tr>
                                                                    <th >Academic Year</th>
                                                                    <th >Index Number</th>
                                                                    <th >Student Name</th>
                                                                    <th >Faculty</th>
                                                                    <th >Program</th>
                                                                    <th >Department</th>
                                                                    <th >Added By</th>
                                                                    <th >Qualification Level</th>
                                                                    <th >Colection Status</th>
                                                                    
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                            <?php $i=0; ?>
                                                            <?php if($generate_pending_certificates): ?>
                                                    <?php foreach($generate_pending_certificates as $certs): ?>
                                                        <?php 
                                                           $collected = $certs['collected'];
                                                            if($collected!=0){
                                                                $collected = '<span class="badge badge-success badge-pill">Collected</span>';
                                                            }else{
                                                                $collected = '<span class="badge badge-warning badge-pill">Pending</span>';
                                                            }
                                                        ?>
                                                        <?php $i++; ?>
                                                        <tr>
                                                                    <td><?php echo $certs['academic_year']; ?></td>
                                                                    <td><?php echo $certs['index_number']; ?></td>
                                                                    <td><?php echo $certs['stud_name']; ?></td>
                                                                    <td><?php echo $certs['faculty_name']; ?></td>
                                                                    <td><?php echo $certs['prog_name']; ?></td>
                                                                    <td><?php echo $certs['dept_name']; ?></td>
                                                                    <td><?php echo $certs['name']; ?></td>
                                                                    <td><?php echo $certs['qual_level']; ?></td>
                                                                    <td><?php echo $collected; ?></td>
                                                                </tr>
                                                    <?php endforeach ?>
                                                    <?php endif ?>
                                                                
                                                                
                                                                </tbody>
                                                    </table>
                                                </div>
                                            
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xl-6">
                                <div id="panel-9" class="panel">
                                    <div class="panel-hdr bg-primary-700 bg-success-gradient">
                                        <h2>
                                        Claim <span class="fw-300"><i>Statistics</i></span>
                                        </h2>
                                        <div class="panel-toolbar">
                                            
                                        </div>
                                    </div>
                                    <div class="panel-container show">
                                        <div class="panel-content">
                                            <div id="pieChart" style="width:100%; height:300px;"></div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php else: ?>
                            <div class="alert border-danger bg-transparent text-secondary fade show" role="alert">
                                <div class="d-flex align-items-center">
                                    <div class="alert-icon">
                                        <span class="icon-stack icon-stack-md">
                                            <i class="base-7 icon-stack-3x color-danger-900"></i>
                                            <i class="fal fa-times icon-stack-1x text-white"></i>
                                        </span>
                                    </div>
                                    <div class="flex-1">
                                        <span class="h5 color-danger-900">No Claim Records Available </span>
                                    </div>
                                    
                                </div>
                            </div>
                        <?php endif ?>                               
                    </main>
                    <!-- this overlay is activated only when mobile menu is triggered -->
                    <div class="page-content-overlay" data-action="toggle" data-class="mobile-nav-on"></div> <!-- END Page Content -->
                    <!-- BEGIN Page Footer -->
                <?php include 'inc/footer_inc.php' ?>
        <script src="js/vendors.bundle.js"></script>
        <script src="js/app.bundle.js"></script>
        <script src="js/statistics/d3/d3.js"></script>
        <script src="js/statistics/c3/c3.js"></script>
        <script src="js/statistics/demo-data/demo-c3.js"></script>
        <script src="js/select2.bundle.js"></script>
        
        <script src="js/datagrid/datatables/datatables2.bundle.js"></script>
        <script src="js/notifications/sweetalert2/sweetalert2.bundle.js"></script>
        <script src="js/datagrid/datatables/datatables.export.js"></script>
        <script src="js/formplugins/bootstrap-datepicker/bootstrap-datepicker.js"></script>
        <script>
             var controls = {
                leftArrow: '<i class="fal fa-angle-left" style="font-size: 1.25rem"></i>',
                rightArrow: '<i class="fal fa-angle-right" style="font-size: 1.25rem"></i>'
            }

             var runDatePicker = function()
            {

                // minimum setup
                $('#datepicker-1').datepicker(
                {
                    todayHighlight: true,
                    orientation: "bottom left",
                    templates: controls
                });


                // input group layout 
                $('#datepicker-2').datepicker(
                {
                    todayHighlight: true,
                    orientation: "bottom left",
                    templates: controls
                });

                // input group layout for modal demo
                $('#datepicker-modal-2').datepicker(
                {
                    todayHighlight: true,
                    orientation: "bottom left",
                    templates: controls
                });

                // enable clear button 
                $('#datepicker-3').datepicker(
                {
                    todayBtn: "linked",
                    clearBtn: true,
                    todayHighlight: true,
                    templates: controls
                });

                // enable clear button for modal demo
                $('#datepicker-modal-3').datepicker(
                {
                    todayBtn: "linked",
                    clearBtn: true,
                    todayHighlight: true,
                    templates: controls
                });

                // orientation 
                $('#datepicker-4-1').datepicker(
                {
                    orientation: "top left",
                    todayHighlight: true,
                    templates: controls
                });

                $('#datepicker-4-2').datepicker(
                {
                    orientation: "top right",
                    todayHighlight: true,
                    templates: controls
                });

                $('#datepicker-4-3').datepicker(
                {
                    orientation: "bottom left",
                    todayHighlight: true,
                    templates: controls
                });

                $('#datepicker-4-4').datepicker(
                {
                    orientation: "bottom right",
                    todayHighlight: true,
                    templates: controls
                });

                // range picker
                $('#datepicker-5').datepicker(
                {
                    todayHighlight: true,
                    templates: controls
                });

                // inline picker
                $('#datepicker-6').datepicker(
                {
                    todayHighlight: true,
                    templates: controls
                });
            }
            
        

           

            $(document).ready(function(){
            $('#academic_year_search').select2({});
            $('#faculty_search').select2({});
            $('#dept_search').select2({});
            $('#prog_search').select2({});
            $('#user_search').select2({});
          

            $('#dt-basic-example').dataTable(
                {
                    dom: "<'row mb-3'<'col-sm-12 col-md-6 d-flex align-items-center justify-content-start'f><'col-sm-12 col-md-6 d-flex align-items-center justify-content-end'B>>" +
                        "<'row'<'col-sm-12'tr>>" +
                        "<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
                    responsive: true,
                    pageLength: 10,
                    order: [
                        [0, 'asc']
                    ],
                    rowGroup:
                    {
                        dataSrc: 0
                    },
                    buttons: [
                    
                        {
                            extend: 'pdfHtml5',
                            text: 'PDF',
                            titleAttr: 'Generate PDF',
                            className: 'btn-success btn-sm mr-1'
                        },
                        
                        {
                            extend: 'csvHtml5',
                            text: 'CSV',
                            titleAttr: 'Generate CSV',
                            className: 'btn-primary btn-sm mr-1'
                        },
                        {
                            extend: 'copyHtml5',
                            text: 'Copy',
                            titleAttr: 'Copy to clipboard',
                            className: 'btn-primary btn-sm mr-1'
                        },
                        {
                            extend: 'print',
                            text: 'Print',
                            titleAttr: 'Print Table',
                            className: 'btn-outline-primary btn-sm'
                        }
                ]
                });

                runDatePicker();

                $('#generate_all').click(function(){
                   window.location.replace('claim_pending_report.php?::=');
                });

                $('#generate_ac').click(function(){
                   var academic_year_id = $('#academic_year_search').val();
                   window.location.replace('claim_pending_report.php?gen_ac='+academic_year_id);
                });

                $('#generate_f').click(function(){
                   var faculty_id = $('#faculty_search').val();
                   window.location.replace('claim_pending_report.php?gen_f='+faculty_id);
                });

                $('#generate_d').click(function(){
                   var dept_id = $('#dept_search').val();
                   window.location.replace('claim_pending_report.php?gen_d='+dept_id);
                });
                
                $('#generate_p').click(function(){
                   var prog_id = $('#prog_search').val();
                   window.location.replace('claim_pending_report.php?gen_p='+prog_id);
                });

                $('#generate_dr').click(function(){
                   var start = $('#start').val();
                   var end = $('#end').val();
                   window.location.replace('claim_pending_report.php?gen_s='+start+'&&gen_e='+end);
                });
                $('#generate_u').click(function(){
                    var user_id = $('#user_search').val();
                   window.location.replace('claim_pending_report.php?gen_u='+user_id);
                });
            });
            var colors = ["#886AB5","#FD3995","#FFC241"];
            var added = '<?php echo $count_certs ?>';
            var collected = '<?php echo $count_collected ?>';
            var pending = '<?php echo $count_pending ?>';
            var pieChart = c3.generate(
            {
                bindto: "#pieChart",
                data:
                {
                    // iris data from R
                    columns: [
                        ['Collected', collected],
                        ["Pending", pending]
                    ],
                    type: 'pie' //,
                    /*onclick: function (d, i) { console.log("onclick", d, i); },
                    onmouseover: function (d, i) { console.log("onmouseover", d, i); },
                    onmouseout: function (d, i) { console.log("onmouseout", d, i); }*/
                },
                color:
                {
                    pattern: colors
                }
            });


        </script>
    </body>

</html>
